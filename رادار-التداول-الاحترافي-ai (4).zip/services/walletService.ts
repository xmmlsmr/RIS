
import { SmartWallet, SmartWalletAlert } from '../types';
import { GoogleGenAI } from "@google/genai";

const MOCK_ALERTS: SmartWalletAlert[] = [
  {
    id: '1',
    walletLabel: 'Whale Master Alpha',
    type: 'Accumulation',
    message: 'بدأ في تجميع كميات كبيرة من ETH عند مستويات الدعم.',
    timestamp: 'منذ 5 دقائق',
    severity: 'high'
  },
  {
    id: '2',
    walletLabel: 'Degen Ape Sniper',
    type: 'New Entry',
    message: 'دخول مفاجئ في عملة ميم جديدة (PEPE2.0).',
    timestamp: 'منذ 15 دقيقة',
    severity: 'medium'
  },
  {
    id: '3',
    walletLabel: 'Smart Money Accumulator',
    type: 'Dump',
    message: 'تخارج جزئي من مراكز SOL بعد تحقيق أرباح 20%.',
    timestamp: 'منذ 45 دقيقة',
    severity: 'low'
  }
];

const MOCK_WALLETS: SmartWallet[] = [
  {
    address: '0x71C765...d897',
    label: 'Whale Master Alpha',
    balance: '$84,500,000',
    pnlTotal: '+$18.4M',
    winRate: '88%',
    lastActivity: 'منذ دقيقة',
    riskProfile: 'Aggressive',
    recentTrades: [
      { type: 'Buy', asset: 'ETH', amount: '800', time: '1m ago', price: '$2450' },
      { type: 'Buy', asset: 'SOL', amount: '5,000', time: '12m ago', price: '$145.2' }
    ]
  },
  {
    address: '0x1A2B3C...4E5F',
    label: 'Smart Money Accumulator',
    balance: '$124,200,000',
    pnlTotal: '+$92.1M',
    winRate: '94%',
    lastActivity: 'منذ 10 دقائق',
    riskProfile: 'Conservative',
    recentTrades: [
      { type: 'Buy', asset: 'WBTC', amount: '25', time: '10m ago', price: '$68,200' }
    ]
  },
  {
    address: '0x9D8E7F...6G5H',
    label: 'Degen Ape Sniper',
    balance: '$2,400,000',
    pnlTotal: '+$1.2M',
    winRate: '45%',
    lastActivity: 'منذ 30 ثانية',
    riskProfile: 'Degen',
    recentTrades: [
      { type: 'Buy', asset: 'PEPE', amount: '10B', time: '30s ago', price: '$0.0000012' },
      { type: 'Sell', asset: 'DOGE', amount: '1M', time: '5m ago', price: '$0.12' }
    ]
  },
  {
    address: '0xB5A4C3...2D1E',
    label: 'Yield Farmer Pro',
    balance: '$15,800,000',
    pnlTotal: '+$3.5M',
    winRate: '72%',
    lastActivity: 'منذ 5 ساعات',
    riskProfile: 'Conservative',
    recentTrades: [
      { type: 'Buy', asset: 'USDC', amount: '500k', time: '5h ago', price: '$1.00' }
    ]
  },
  {
    address: '0xF1E2D3...C4B5',
    label: 'Memecoin Hunter',
    balance: '$850,000',
    pnlTotal: '-$120k',
    winRate: '30%',
    lastActivity: 'منذ 2 دقيقة',
    riskProfile: 'Degen',
    recentTrades: [
      { type: 'Buy', asset: 'SHIB', amount: '1B', time: '2m ago', price: '$0.000025' }
    ]
  }
];

async function retryWithBackoff<T>(fn: () => Promise<T>, maxRetries = 3): Promise<T> {
  let delay = 4000;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (e: any) {
      if (e?.message?.includes('429') && i < maxRetries - 1) {
        console.warn(`[Whale Tracker] 429 Error. Retrying in ${delay}ms...`);
        await new Promise(r => setTimeout(r, delay));
        delay *= 2;
        continue;
      }
      throw e;
    }
  }
  return await fn();
}

export const getSmartWallets = async (): Promise<SmartWallet[]> => {
  await new Promise(r => setTimeout(r, 800));
  return MOCK_WALLETS;
};

export const getSmartWalletAlerts = async (): Promise<SmartWalletAlert[]> => {
  await new Promise(r => setTimeout(r, 500));
  return MOCK_ALERTS;
};

export const getWhaleInsights = async (): Promise<string> => {
  // Moved inside to ensure fresh API key usage
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const callAi = async () => {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Summarize the top 3 crypto assets being accumulated by institutional whales right now based on latest news. Provide the response in clear Arabic.",
      config: { tools: [{ googleSearch: {} }] }
    });
    return response.text || "لا تتوفر بيانات حية حالياً.";
  };

  try {
    return await retryWithBackoff(callAi);
  } catch (e: any) {
    if (e?.message?.includes('429')) return "عذراً، الخدمة تحت ضغط عالٍ الآن. يرجى العودة لاحقاً.";
    return "تعذر جلب رؤى الحيتان حالياً.";
  }
};
