
import { CryptoTicker, KlineData } from '../types';

// Mock Data Generators
const generateMockTickers = (count: number, type: 'spot' | 'futures'): CryptoTicker[] => {
  const symbols = ['BTC', 'ETH', 'SOL', 'XRP', 'ADA', 'AVAX', 'DOT', 'MATIC', 'LINK', 'UNI', 'DOGE', 'SHIB', 'LTC', 'ATOM', 'ETC'];
  return symbols.map(sym => {
    const price = Math.random() * 1000 + 10;
    const change = (Math.random() * 20) - 10;
    return {
      symbol: `${sym}USDT`,
      lastPrice: price.toFixed(2),
      priceChangePercent: change.toFixed(2),
      quoteVolume: (Math.random() * 1000000000).toFixed(2),
      highPrice: (price * 1.05).toFixed(2),
      lowPrice: (price * 0.95).toFixed(2),
      volume: (Math.random() * 10000).toFixed(2),
    } as CryptoTicker;
  });
};

const generateMockKlines = (limit: number): KlineData[] => {
  const klines: KlineData[] = [];
  let price = 50000;
  const now = Date.now();
  for (let i = limit; i > 0; i--) {
    const time = now - i * 3600000;
    const open = price;
    const close = price * (1 + (Math.random() * 0.02 - 0.01));
    const high = Math.max(open, close) * (1 + Math.random() * 0.01);
    const low = Math.min(open, close) * (1 - Math.random() * 0.01);
    const volume = Math.random() * 1000;
    klines.push({ time, open, high, low, close, volume });
    price = close;
  }
  return klines;
};

export const fetchTickers = async (): Promise<CryptoTicker[]> => {
  try {
    const response = await fetch('https://api.binance.com/api/v3/ticker/24hr');
    if (!response.ok) throw new Error('Network response was not ok');
    const data = await response.json();
    return data.filter((item: CryptoTicker) => item.symbol.endsWith('USDT'));
  } catch (error) {
    console.warn('Error fetching crypto data, using mock data:', error);
    return generateMockTickers(15, 'spot');
  }
};

export const fetchFuturesTickers = async (): Promise<CryptoTicker[]> => {
  try {
    const response = await fetch('https://fapi.binance.com/fapi/v1/ticker/24hr');
    if (!response.ok) throw new Error('Network response was not ok');
    const data = await response.json();
    return data.filter((item: CryptoTicker) => item.symbol.endsWith('USDT'));
  } catch (error) {
    console.warn('Error fetching futures data, using mock data:', error);
    return generateMockTickers(15, 'futures');
  }
};

export const fetchKlines = async (symbol: string, interval: string = '1h'): Promise<KlineData[]> => {
  try {
    const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=168`);
    if (!response.ok) throw new Error('Network response was not ok');
    const data = await response.json();
    return data.map((d: any) => ({
      time: d[0],
      open: parseFloat(d[1]),
      high: parseFloat(d[2]),
      low: parseFloat(d[3]),
      close: parseFloat(d[4]),
      volume: parseFloat(d[5]),
    }));
  } catch (error) {
    console.warn('Error fetching kline data, using mock data:', error);
    return generateMockKlines(168);
  }
};

export const fetchFuturesKlines = async (symbol: string, interval: string = '1h'): Promise<KlineData[]> => {
  try {
    const response = await fetch(`https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=168`);
    if (!response.ok) throw new Error('Network response was not ok');
    const data = await response.json();
    return data.map((d: any) => ({
      time: d[0],
      open: parseFloat(d[1]),
      high: parseFloat(d[2]),
      low: parseFloat(d[3]),
      close: parseFloat(d[4]),
      volume: parseFloat(d[5]),
    }));
  } catch (error) {
    console.warn('Error fetching futures kline data, using mock data:', error);
    return generateMockKlines(168);
  }
};
