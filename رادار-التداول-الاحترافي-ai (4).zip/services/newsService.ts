import { NewsItem } from '../types';

const MOCK_NEWS: NewsItem[] = [
  {
    id: '1',
    title: 'Bitcoin Surges Past $65,000 as Institutional Interest Grows',
    summary: 'Major financial institutions are increasing their exposure to Bitcoin, driving the price to new highs.',
    source: 'CoinDesk',
    url: 'https://coindesk.com',
    publishedAt: new Date(Date.now() - 1000 * 60 * 30).toISOString(), // 30 mins ago
    sentiment: 'Positive',
    category: 'Crypto',
    imageUrl: 'https://images.unsplash.com/photo-1518546305927-5a555bb7020d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: '2',
    title: 'SEC Delays Decision on Ethereum ETF',
    summary: 'The Securities and Exchange Commission has postponed its ruling on the proposed Ethereum ETF applications.',
    source: 'Bloomberg',
    url: 'https://bloomberg.com',
    publishedAt: new Date(Date.now() - 1000 * 60 * 120).toISOString(), // 2 hours ago
    sentiment: 'Negative',
    category: 'Regulation',
    imageUrl: 'https://images.unsplash.com/photo-1622630998477-20aa696fa4a5?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: '3',
    title: 'Solana Network Upgrades to Improve Scalability',
    summary: 'Developers have released a new patch that promises to significantly reduce transaction fees and increase throughput.',
    source: 'CryptoSlate',
    url: 'https://cryptoslate.com',
    publishedAt: new Date(Date.now() - 1000 * 60 * 240).toISOString(), // 4 hours ago
    sentiment: 'Positive',
    category: 'Tech',
    imageUrl: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: '4',
    title: 'Global Markets React to Inflation Data',
    summary: 'Stock and crypto markets are showing volatility following the release of the latest US CPI report.',
    source: 'Reuters',
    url: 'https://reuters.com',
    publishedAt: new Date(Date.now() - 1000 * 60 * 300).toISOString(), // 5 hours ago
    sentiment: 'Neutral',
    category: 'Market',
    imageUrl: 'https://images.unsplash.com/photo-1611974765270-ca1258634369?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  },
  {
    id: '5',
    title: 'New DeFi Protocol Offers High Yields on Stablecoins',
    summary: 'A new decentralized finance platform is attracting liquidity with competitive APYs on USDT and USDC.',
    source: 'The Block',
    url: 'https://theblock.co',
    publishedAt: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    sentiment: 'Positive',
    category: 'Crypto',
    imageUrl: 'https://images.unsplash.com/photo-1605792657660-596af9009e82?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
  }
];

export const fetchNews = async (): Promise<NewsItem[]> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 800));
  return MOCK_NEWS;
};

export const fetchLatestNews = async (): Promise<NewsItem | null> => {
    // Simulate fetching a new item occasionally
    const random = Math.random();
    if (random > 0.7) {
        return {
            id: Date.now().toString(),
            title: 'Breaking: Major Exchange Announces New Listing',
            summary: 'Top tier exchange has just revealed its latest asset addition, sparking a price rally.',
            source: 'CoinTelegraph',
            url: 'https://cointelegraph.com',
            publishedAt: new Date().toISOString(),
            sentiment: 'Positive',
            category: 'Crypto',
            imageUrl: 'https://images.unsplash.com/photo-1620321023374-d1a68fbc720d?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3'
        };
    }
    return null;
}
