import initialData from '../db.json';
import { User, Strategy, TradingBot, SmartWallet, SmartWalletAlert } from '../types';

// Database Schema Interface
interface DatabaseSchema {
  users: User[];
  strategies: Strategy[];
  bots: TradingBot[];
  wallets: SmartWallet[];
  alerts: SmartWalletAlert[];
}

const DB_KEY = 'alpha_radar_db';

class DatabaseService {
  private db: DatabaseSchema;

  constructor() {
    const storedData = localStorage.getItem(DB_KEY);
    if (storedData) {
      this.db = JSON.parse(storedData);
    } else {
      // Initialize with default data from db.json
      this.db = initialData as any;
      
      // Migration: Check for legacy users in localStorage
      const legacyUsers = localStorage.getItem('users');
      if (legacyUsers) {
        try {
          const users = JSON.parse(legacyUsers);
          if (Array.isArray(users)) {
            // Merge legacy users, avoiding duplicates by ID or Email
            users.forEach((u: any) => {
              if (!this.db.users.find(existing => existing.email === u.email)) {
                this.db.users.push(u);
              }
            });
          }
        } catch (e) {
          console.error('Failed to migrate legacy users', e);
        }
      }
      
      this.save();
    }
  }

  private save() {
    localStorage.setItem(DB_KEY, JSON.stringify(this.db));
  }

  // User Operations
  getUser(id: string): User | undefined {
    return this.db.users.find(u => u.id === id);
  }

  findUserByEmail(email: string): User | undefined {
    return this.db.users.find(u => u.email === email);
  }

  addUser(user: User): User {
    this.db.users.push(user);
    this.save();
    return user;
  }

  updateUser(id: string, updates: Partial<User>): User | undefined {
    const index = this.db.users.findIndex(u => u.id === id);
    if (index !== -1) {
      this.db.users[index] = { ...this.db.users[index], ...updates };
      this.save();
      return this.db.users[index];
    }
    return undefined;
  }

  // Strategy Operations
  getStrategies(): Strategy[] {
    return this.db.strategies;
  }

  addStrategy(strategy: Strategy): Strategy {
    this.db.strategies.push(strategy);
    this.save();
    return strategy;
  }

  // Bot Operations
  getBots(): TradingBot[] {
    return this.db.bots;
  }

  updateBot(id: string, updates: Partial<TradingBot>): TradingBot | undefined {
    const index = this.db.bots.findIndex(b => b.id === id);
    if (index !== -1) {
      this.db.bots[index] = { ...this.db.bots[index], ...updates };
      this.save();
      return this.db.bots[index];
    }
    return undefined;
  }

  addBot(bot: TradingBot): TradingBot {
    this.db.bots.push(bot);
    this.save();
    return bot;
  }

  deleteBot(id: string): boolean {
    const initialLength = this.db.bots.length;
    this.db.bots = this.db.bots.filter(b => b.id !== id);
    this.save();
    return this.db.bots.length < initialLength;
  }

  // Wallet Operations
  getWallets(): SmartWallet[] {
    return this.db.wallets;
  }

  // Alert Operations
  getAlerts(): SmartWalletAlert[] {
    return this.db.alerts;
  }

  addAlert(alert: SmartWalletAlert): SmartWalletAlert {
    this.db.alerts.unshift(alert);
    // Keep only last 100 alerts
    if (this.db.alerts.length > 100) {
      this.db.alerts = this.db.alerts.slice(0, 100);
    }
    this.save();
    return alert;
  }

  // Reset Database
  reset() {
    this.db = initialData as any;
    this.save();
  }
}

export const db = new DatabaseService();
