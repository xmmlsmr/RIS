
import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult, Strategy, GroundingLink } from "../types";

/**
 * دالة متطورة لإعادة المحاولة في حال تجاوز حد الطلبات (429) 
 * تستخدم نظام تراجع أسي (Exponential Backoff) أكثر مرونة
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 5,
  initialDelay: number = 5000 // البدء بـ 5 ثوانٍ
): Promise<T> {
  let delay = initialDelay;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: any) {
      const isQuotaError = 
        error?.message?.includes('429') || 
        error?.status === 429 || 
        error?.message?.includes('RESOURCE_EXHAUSTED') ||
        (error?.error?.code === 429);
      
      if (isQuotaError && i < maxRetries - 1) {
        console.warn(`[AI System] Quota reached. Attempt ${i + 1}/${maxRetries}. Waiting ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
        delay *= 2; // مضاعفة وقت الانتظار في كل محاولة
        continue;
      }
      throw error;
    }
  }
  return await fn(); 
}

export const analyzeSymbol = async (
  symbol: string, 
  priceData: any, 
  isDeep: boolean = false, 
  strategy?: Strategy
): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const callAi = async () => {
    const modelName = isDeep ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
    
    const depthPrompt = isDeep 
      ? "قم بإجراء تحليل فني ومالي معمق وشامل (Deep Technical & Fundamental Analysis). يجب أن يتضمن التحليل: 1. تحديد مستويات الدعم والمقاومة الرئيسية (Support & Resistance Levels). 2. رصد النماذج الفنية المتكونة (Chart Patterns) مثل الرأس والكتفين، الأعلام، المثلثات، إلخ. 3. تحليل السيولة (Liquidity Analysis) وتمركز الحيتان (Whale Activity). 4. سيناريوهات الحركة المتوقعة (Bullish & Bearish Scenarios). 5. تحليل المشاعر العامة للسوق (Market Sentiment) وتأثير الأخبار الأخيرة." 
      : "قم بإجراء تحليل فني سريع ودقيق يركز على الزخم الحالي والاتجاه القصير.";

    const strategyContext = strategy 
      ? `هام: طبق استراتيجية "${strategy.name}" (المنطق: ${strategy.indicatorLogic}).` 
      : "";

    return await ai.models.generateContent({
      model: modelName,
      contents: `حلل العملة ${symbol} (السعر الحالي: ${priceData.lastPrice}, تغير 24س: ${priceData.priceChangePercent}%). 
      ${depthPrompt}
      ${strategyContext}
      المتطلبات الصارمة:
      1. ابحث باستخدام googleSearch عن أحدث أخبار ${symbol} وتحركات الحيتان.
      2. حدد 3 أهداف (Targets) ووقف خسارة (Stop-Loss).
      3. إذا كانت التوصية "Sell" (بيع)، يجب أن تكون الأهداف الثلاثة أقل من السعر الحالي (${priceData.lastPrice}) ووقف الخسارة أعلى منه.
      4. إذا كانت التوصية "Buy" (شراء)، يجب أن تكون الأهداف الثلاثة أعلى من السعر الحالي ووقف الخسارة أدنى منه.
      5. قدم تحليلاً مفصلاً باللغة العربية يشرح الأسباب الفنية بدقة، مع ذكر مستويات الدعم والمقاومة، النماذج الفنية، والسيناريوهات المحتملة.
      6. قم بتضمين المؤشرات التالية في قائمة indicators: RSI (14), MACD, MACD Hist, MA (50), MA (200), Volume Flow, Volatility, Bollinger Bands, Stoch RSI, ATR, OBV, Ichimoku, EMA (9), EMA (21), EMA (50), EMA (200), VWAP.
      7. لكل مؤشر في indicatorHistory، قم بتقدير نسبة نجاح تاريخية (winRate) ودقة الإشارة (accuracy) بناءً على أداء المؤشر مع هذه العملة.`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: { type: Type.STRING },
            sentimentScore: { type: Type.NUMBER },
            recommendation: { type: Type.STRING, enum: ['Buy', 'Sell', 'Hold'] },
            reasoning: { type: Type.STRING },
            targets: { type: Type.ARRAY, items: { type: Type.STRING } },
            stopLoss: { type: Type.STRING },
            indicators: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.STRING },
                  status: { type: Type.STRING, enum: ['bullish', 'bearish', 'neutral'] }
                },
                required: ["name", "value", "status"]
              }
            },
            indicatorHistory: { 
              type: Type.ARRAY, 
              items: { 
                type: Type.OBJECT, 
                properties: { 
                  name: { type: Type.STRING }, 
                  values: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                  winRate: { type: Type.NUMBER },
                  accuracy: { type: Type.NUMBER }
                },
                required: ["name", "values"]
              } 
            },
            macd: { 
              type: Type.OBJECT, 
              properties: { 
                line: { type: Type.STRING }, 
                signal: { type: Type.STRING }, 
                histogram: { type: Type.STRING }, 
                lineStatus: { type: Type.STRING, enum: ['bullish', 'bearish', 'neutral'] }, 
                signalStatus: { type: Type.STRING, enum: ['bullish', 'bearish', 'neutral'] }, 
                histogramStatus: { type: Type.STRING, enum: ['bullish', 'bearish', 'neutral'] } 
              },
              required: ["line", "signal", "histogram", "lineStatus", "signalStatus", "histogramStatus"]
            },
            liquidity: { 
              type: Type.OBJECT, 
              properties: { 
                strength: { type: Type.NUMBER }, 
                description: { type: Type.STRING }, 
                status: { type: Type.STRING, enum: ['high', 'medium', 'low'] }, 
                trend: { type: Type.STRING, enum: ['rising', 'falling', 'stable'] },
                history: { type: Type.ARRAY, items: { type: Type.NUMBER } }
              },
              required: ["strength", "description", "status", "trend", "history"]
            },
            openInterest: { 
              type: Type.OBJECT, 
              properties: { 
                trend: { type: Type.STRING, enum: ['rising', 'falling', 'stable'] }, 
                sentiment: { type: Type.STRING }, 
                estimatedValue: { type: Type.STRING },
                history: { type: Type.ARRAY, items: { type: Type.NUMBER } }
              },
              required: ["trend", "sentiment", "estimatedValue", "history"]
            },
            smartMoney: { 
              type: Type.OBJECT, 
              properties: { 
                flow: { type: Type.STRING, enum: ['inflow', 'outflow', 'neutral'] }, 
                whaleConcentration: { type: Type.NUMBER }, 
                recentInsight: { type: Type.STRING } 
              },
              required: ["flow", "whaleConcentration", "recentInsight"]
            }
          },
          required: ["sentiment", "sentimentScore", "recommendation", "reasoning", "targets", "stopLoss", "indicators", "macd", "liquidity", "openInterest", "indicatorHistory", "smartMoney"]
        }
      }
    });
  };

  try {
    const response = await retryWithBackoff(callAi);
    const text = response.text;
    if (!text) throw new Error("لم يتم استلام استجابة من المحرك الذكي.");
    const result: AnalysisResult = JSON.parse(text);

    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    if (groundingMetadata && groundingMetadata.groundingChunks) {
      const links: GroundingLink[] = groundingMetadata.groundingChunks
        .filter((chunk: any) => chunk.web && chunk.web.uri)
        .map((chunk: any) => ({
          title: chunk.web.title || "خبر من مصدر Alpha",
          uri: chunk.web.uri,
        }));
      result.groundingLinks = Array.from(new Set(links.map(l => l.uri)))
        .map(uri => links.find(l => l.uri === uri)!);
    }

    return result;
  } catch (e: any) {
    console.error("Analysis Pipeline Error:", e);
    const isQuota = e?.message?.includes('429') || e?.status === 429;
    if (isQuota) {
      throw new Error("عذراً، المحرك الذكي وصل للحد الأقصى للطلبات حالياً. يرجى الانتظار دقيقة أو استخدام 'التحليل المحلي' السريع.");
    }
    throw new Error("فشل في معالجة التحليل الفني العميق. تأكد من جودة اتصالك وحاول مجدداً.");
  }
};
