import React, { useState, useEffect } from 'react';
import { X, Save, RotateCcw, Settings } from 'lucide-react';
import { IndicatorSettings, IndicatorConfig } from '../types';

interface IndicatorSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSettings: IndicatorSettings;
  onSave: (newSettings: IndicatorSettings) => void;
  availableIndicators: string[];
}

const DEFAULT_CONFIGS: IndicatorSettings = {
  'RSI (14)': { period: 14 },
  'MACD': { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
  'MACD Hist': { fastPeriod: 12, slowPeriod: 26, signalPeriod: 9 },
  'MA (50)': { period: 50, source: 'close' },
  'MA (200)': { period: 200, source: 'close' },
  'EMA (9)': { period: 9, source: 'close' },
  'EMA (21)': { period: 21, source: 'close' },
  'EMA (50)': { period: 50, source: 'close' },
  'EMA (200)': { period: 200, source: 'close' },
  'Bollinger Bands': { period: 20, stdDev: 2 },
  'Stoch RSI': { period: 14, fastPeriod: 3, slowPeriod: 3 },
  'ATR': { period: 14 },
  'VWAP': { source: 'close' },
  'Volume Flow': { period: 14 },
  'Volatility': { period: 10 },
  'OBV': { source: 'close' },
  'Ichimoku': { fastPeriod: 9, slowPeriod: 26, signalPeriod: 52 }
};

export const IndicatorSettingsModal: React.FC<IndicatorSettingsModalProps> = ({
  isOpen,
  onClose,
  currentSettings,
  onSave,
  availableIndicators
}) => {
  const [settings, setSettings] = useState<IndicatorSettings>(currentSettings);
  const [selectedIndicator, setSelectedIndicator] = useState<string>(availableIndicators[0]);

  useEffect(() => {
    setSettings(currentSettings);
  }, [currentSettings, isOpen]);

  if (!isOpen) return null;

  const handleChange = (indicator: string, field: keyof IndicatorConfig, value: any) => {
    setSettings(prev => ({
      ...prev,
      [indicator]: {
        ...(prev[indicator] || DEFAULT_CONFIGS[indicator] || {}),
        [field]: value
      }
    }));
  };

  const handleReset = () => {
    setSettings(DEFAULT_CONFIGS);
  };

  const handleSave = () => {
    onSave(settings);
    onClose();
  };

  const renderInputs = (indicator: string) => {
    const config = settings[indicator] || DEFAULT_CONFIGS[indicator] || {};
    const defaultConfig = DEFAULT_CONFIGS[indicator] || {};

    // Determine which fields to show based on default config keys
    const fields = Object.keys(defaultConfig) as (keyof IndicatorConfig)[];

    if (fields.length === 0) {
      return <div className="text-gray-500 text-sm italic">لا توجد إعدادات قابلة للتخصيص لهذا المؤشر.</div>;
    }

    return (
      <div className="space-y-4">
        {fields.map(field => (
          <div key={field} className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase block">
              {field === 'period' ? 'الفترة (Period)' :
               field === 'stdDev' ? 'الانحراف المعياري (StdDev)' :
               field === 'fastPeriod' ? 'الفترة السريعة (Fast)' :
               field === 'slowPeriod' ? 'الفترة البطيئة (Slow)' :
               field === 'signalPeriod' ? 'فترة الإشارة (Signal)' :
               field === 'source' ? 'المصدر (Source)' : field}
            </label>
            {field === 'source' ? (
              <select
                value={config.source || 'close'}
                onChange={(e) => handleChange(indicator, field, e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white focus:border-indigo-500 focus:outline-none text-sm"
              >
                <option value="close">Close</option>
                <option value="open">Open</option>
                <option value="high">High</option>
                <option value="low">Low</option>
              </select>
            ) : (
              <input
                type="number"
                value={config[field] !== undefined ? config[field] : ''}
                onChange={(e) => handleChange(indicator, field, Number(e.target.value))}
                className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white focus:border-indigo-500 focus:outline-none font-mono text-sm"
              />
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0e1116] w-full max-w-2xl rounded-2xl border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[80vh]" dir="rtl">
        {/* Header */}
        <div className="p-4 border-b border-white/10 flex justify-between items-center bg-white/5">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Settings size={18} className="text-indigo-400" />
            إعدادات المؤشرات الفنية
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar */}
          <div className="w-1/3 border-l border-white/10 overflow-y-auto bg-black/20">
            {availableIndicators.map(ind => (
              <button
                key={ind}
                onClick={() => setSelectedIndicator(ind)}
                className={`w-full text-right px-4 py-3 text-sm font-medium border-b border-white/5 transition-colors ${
                  selectedIndicator === ind 
                    ? 'bg-indigo-500/10 text-indigo-400 border-r-2 border-r-indigo-500' 
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                {ind}
              </button>
            ))}
          </div>

          {/* Settings Panel */}
          <div className="flex-1 p-6 overflow-y-auto bg-[#0e1116]">
            <h4 className="text-xl font-black text-white mb-6 border-b border-white/10 pb-4">
              {selectedIndicator}
            </h4>
            {renderInputs(selectedIndicator)}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 bg-white/5 flex justify-between items-center">
          <button 
            onClick={handleReset}
            className="px-4 py-2 text-xs font-bold text-gray-400 hover:text-white flex items-center gap-2 transition-colors"
          >
            <RotateCcw size={14} />
            استعادة الافتراضي
          </button>
          <div className="flex gap-3">
            <button 
              onClick={onClose}
              className="px-6 py-2 rounded-lg text-sm font-bold text-gray-400 hover:text-white hover:bg-white/5 transition-all"
            >
              إلغاء
            </button>
            <button 
              onClick={handleSave}
              className="px-6 py-2 rounded-lg text-sm font-bold bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2"
            >
              <Save size={16} />
              حفظ التغييرات
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
