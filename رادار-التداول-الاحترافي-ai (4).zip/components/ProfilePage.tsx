import React, { useState, useEffect } from 'react';
import { User, Mail, Crown, Calendar, Shield, Edit2, Camera, LogOut, X, Check, Bell, Moon, Sun, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface ProfilePageProps {
  onClose: () => void;
  onLogout: () => void;
  isVip: boolean;
  theme: 'dark' | 'light';
  toggleTheme: () => void;
  onOpenReferral: () => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onClose, onLogout, isVip, theme, toggleTheme, onOpenReferral }) => {
  const { user, updateUser } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [joinDate, setJoinDate] = useState(user?.joinedDate || '');
  const [vipExpiry, setVipExpiry] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [tempName, setTempName] = useState(user?.name || '');

  useEffect(() => {
    // Load VIP expiry from localStorage
    const savedVipExpiry = localStorage.getItem('vipExpiry');
    setVipExpiry(savedVipExpiry);
    
    if (user) {
      setName(user.name);
      setEmail(user.email);
      setJoinDate(user.joinedDate);
      setTempName(user.name);
    }
  }, [user]);

  const handleSave = () => {
    if (user) {
      updateUser({ name: tempName });
      setName(tempName);
      setIsEditing(false);
    }
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' });
    } catch (e) {
      return dateString;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-white dark:bg-[#161b22] w-full max-w-4xl rounded-[2.5rem] border border-gray-200 dark:border-white/10 shadow-2xl overflow-hidden flex flex-col md:flex-row h-[80vh] md:h-auto">
        
        {/* Sidebar */}
        <div className="w-full md:w-80 bg-gray-50 dark:bg-[#0d1117] p-8 border-l border-gray-200 dark:border-white/5 flex flex-col items-center text-center relative">
          <button 
            onClick={onClose}
            className="absolute top-6 right-6 p-2 hover:bg-gray-200 dark:hover:bg-white/10 rounded-full transition-colors text-gray-500 md:hidden"
          >
            <X size={20} />
          </button>

          <div className="relative mb-6 group">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 p-1 shadow-xl">
              <div className="w-full h-full rounded-full bg-white dark:bg-[#161b22] flex items-center justify-center overflow-hidden">
                <User size={64} className="text-gray-300" />
              </div>
            </div>
            <button className="absolute bottom-0 right-0 p-2 bg-cyan-500 text-white rounded-full shadow-lg hover:bg-cyan-400 transition-colors">
              <Camera size={16} />
            </button>
          </div>

          <h2 className="text-xl font-black text-gray-900 dark:text-white mb-1">{name}</h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{email}</p>

          <div className={`px-4 py-2 rounded-xl text-xs font-black flex items-center gap-2 mb-8 ${
            isVip 
              ? 'bg-amber-500/10 text-amber-500 border border-amber-500/20' 
              : 'bg-gray-200 dark:bg-white/5 text-gray-500 dark:text-gray-400 border border-gray-300 dark:border-white/10'
          }`}>
            <Crown size={14} fill={isVip ? "currentColor" : "none"} />
            {isVip ? 'عضوية VIP نشطة' : 'عضوية مجانية'}
          </div>

          <div className="mt-auto w-full space-y-2">
            <button 
              onClick={onLogout}
              className="w-full py-3 px-4 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 font-bold flex items-center justify-center gap-2 transition-all"
            >
              <LogOut size={18} />
              تسجيل خروج
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-8 overflow-y-auto custom-scrollbar">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-black text-gray-900 dark:text-white">إعدادات الحساب</h1>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-white/10 rounded-xl transition-colors text-gray-500 hidden md:block"
            >
              <X size={24} />
            </button>
          </div>

          <div className="space-y-8">
            {/* Personal Info Section */}
            <section>
              <h3 className="text-sm font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <User size={16} />
                المعلومات الشخصية
              </h3>
              <div className="bg-gray-50 dark:bg-black/20 rounded-2xl border border-gray-200 dark:border-white/5 p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">الاسم الكامل</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        value={isEditing ? tempName : name}
                        onChange={(e) => setTempName(e.target.value)}
                        disabled={!isEditing}
                        className={`w-full bg-white dark:bg-[#161b22] border rounded-xl py-3 px-4 text-gray-900 dark:text-white font-bold focus:outline-none transition-all ${
                          isEditing 
                            ? 'border-cyan-500 ring-1 ring-cyan-500/20' 
                            : 'border-gray-200 dark:border-white/10 opacity-70'
                        }`}
                      />
                      {!isEditing && (
                        <button 
                          onClick={() => setIsEditing(true)}
                          className="absolute left-3 top-1/2 -translate-y-1/2 text-cyan-500 hover:text-cyan-400"
                        >
                          <Edit2 size={16} />
                        </button>
                      )}
                      {isEditing && (
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 flex gap-2">
                          <button onClick={handleSave} className="text-green-500 hover:text-green-400"><Check size={16} /></button>
                          <button onClick={() => setIsEditing(false)} className="text-rose-500 hover:text-rose-400"><X size={16} /></button>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">البريد الإلكتروني</label>
                    <div className="relative">
                      <input 
                        type="email" 
                        value={email}
                        disabled
                        className="w-full bg-white dark:bg-[#161b22] border border-gray-200 dark:border-white/10 rounded-xl py-3 px-4 text-gray-500 dark:text-gray-400 font-bold opacity-70 cursor-not-allowed"
                      />
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Subscription Section */}
            <section>
              <h3 className="text-sm font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Crown size={16} />
                تفاصيل الاشتراك
              </h3>
              <div className="bg-gray-50 dark:bg-black/20 rounded-2xl border border-gray-200 dark:border-white/5 p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">الخطة الحالية</p>
                    <h4 className={`text-xl font-black ${isVip ? 'text-amber-500' : 'text-gray-700 dark:text-gray-300'}`}>
                      {isVip ? 'باقة المحترفين (VIP)' : 'الباقة المجانية'}
                    </h4>
                  </div>
                  {isVip && (
                    <div className="text-left">
                      <p className="text-xs text-gray-500 mb-1">تاريخ الانتهاء</p>
                      <p className="text-sm font-bold text-gray-900 dark:text-white font-mono">
                        {vipExpiry ? formatDate(vipExpiry) : '-'}
                      </p>
                    </div>
                  )}
                </div>
                
                {isVip ? (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4">
                    <h5 className="font-bold text-amber-500 mb-3 flex items-center gap-2">
                      <Crown size={16} />
                      مميزات باقتك الحالية
                    </h5>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                        <Check size={14} className="text-emerald-500" />
                        وصول غير محدود للتحليل بالذكاء الاصطناعي
                      </li>
                      <li className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                        <Check size={14} className="text-emerald-500" />
                        إشارات تداول فورية وتوصيات دقيقة
                      </li>
                      <li className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                        <Check size={14} className="text-emerald-500" />
                        مراقبة المحافظ الذكية (Smart Wallets)
                      </li>
                      <li className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-300">
                        <Check size={14} className="text-emerald-500" />
                        أولوية الدعم الفني
                      </li>
                    </ul>
                  </div>
                ) : (
                  <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                        <Crown size={20} className="text-amber-500" />
                      </div>
                      <div>
                        <h5 className="font-bold text-gray-900 dark:text-white">رقِ عضويتك الآن</h5>
                        <p className="text-xs text-gray-500">احصل على ميزات حصرية وتحليلات غير محدودة</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-xs transition-colors">
                      ترقية
                    </button>
                  </div>
                )}
              </div>
            </section>

            {/* Referral Section */}
            <section>
              <h3 className="text-sm font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <User size={16} />
                برنامج الإحالة
              </h3>
              <div 
                onClick={onOpenReferral}
                className="bg-gradient-to-r from-cyan-500/10 to-blue-600/10 rounded-2xl border border-cyan-500/20 p-6 cursor-pointer hover:border-cyan-500/40 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-cyan-500/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <User size={24} className="text-cyan-500" />
                    </div>
                    <div>
                      <h4 className="text-lg font-black text-gray-900 dark:text-white mb-1">ادعُ أصدقاءك واربح</h4>
                      <p className="text-sm text-gray-500 dark:text-gray-400">احصل على مكافآت مالية مقابل كل صديق تقوم بدعوته.</p>
                    </div>
                  </div>
                  <div className="w-10 h-10 rounded-full bg-white dark:bg-white/10 flex items-center justify-center text-gray-400 group-hover:text-cyan-500 group-hover:bg-white dark:group-hover:bg-white/20 transition-all">
                    <ArrowLeft size={20} />
                  </div>
                </div>
              </div>
            </section>

            {/* Preferences Section */}
            <section>
              <h3 className="text-sm font-black text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Shield size={16} />
                التفضيلات والأمان
              </h3>
              <div className="bg-gray-50 dark:bg-black/20 rounded-2xl border border-gray-200 dark:border-white/5 p-6 space-y-4">
                <div className="flex items-center justify-between p-3 hover:bg-white dark:hover:bg-white/5 rounded-xl transition-colors cursor-pointer" onClick={toggleTheme}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-white/10 flex items-center justify-center text-gray-600 dark:text-gray-300">
                      {theme === 'dark' ? <Moon size={20} /> : <Sun size={20} />}
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-900 dark:text-white">مظهر التطبيق</h5>
                      <p className="text-xs text-gray-500">{theme === 'dark' ? 'الوضع الليلي' : 'الوضع النهاري'}</p>
                    </div>
                  </div>
                  <div className={`w-12 h-6 rounded-full p-1 transition-colors ${theme === 'dark' ? 'bg-cyan-600' : 'bg-gray-300'}`}>
                    <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-transform ${theme === 'dark' ? 'translate-x-[-24px]' : 'translate-x-0'}`}></div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 hover:bg-white dark:hover:bg-white/5 rounded-xl transition-colors cursor-pointer">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-white/10 flex items-center justify-center text-gray-600 dark:text-gray-300">
                      <Bell size={20} />
                    </div>
                    <div>
                      <h5 className="font-bold text-gray-900 dark:text-white">الإشعارات</h5>
                      <p className="text-xs text-gray-500">تفعيل التنبيهات الصوتية والمرئية</p>
                    </div>
                  </div>
                  <div className="w-12 h-6 rounded-full bg-cyan-600 p-1">
                    <div className="w-4 h-4 rounded-full bg-white shadow-sm translate-x-[-24px]"></div>
                  </div>
                </div>
              </div>
            </section>

            <div className="text-center text-xs text-gray-400 pt-4">
              عضو منذ {formatDate(joinDate)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
