import React, { useState } from 'react';
import { X, Bot, Zap, Activity, TrendingUp, ArrowRight, Check, Settings, AlertTriangle } from 'lucide-react';

interface CreateBotModalProps {
  onClose: () => void;
  onCreate: (botData: any) => void;
}

const BOT_TEMPLATES = [
  {
    id: 'grid',
    name: 'Grid Trading',
    icon: <Activity size={24} />,
    description: 'يشتري عند انخفاض السعر ويبيع عند ارتفاعه في نطاق محدد.',
    suitableFor: 'الأسواق العرضية (Sideways)',
    risk: 'Low',
    color: 'emerald'
  },
  {
    id: 'dca',
    name: 'DCA Accumulator',
    icon: <TrendingUp size={24} />,
    description: 'شراء متكرر لخفض متوسط التكلفة مع ارتداد السعر.',
    suitableFor: 'الأسواق الهابطة/المتقلبة',
    risk: 'Medium',
    color: 'blue'
  },
  {
    id: 'ai_scalp',
    name: 'AI Scalper',
    icon: <Zap size={24} />,
    description: 'مضاربة سريعة تعتمد على إشارات الذكاء الاصطناعي.',
    suitableFor: 'الأسواق عالية السيولة',
    risk: 'High',
    color: 'rose'
  }
];

export const CreateBotModal: React.FC<CreateBotModalProps> = ({ onClose, onCreate }) => {
  const [step, setStep] = useState(1);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [config, setConfig] = useState({
    name: '',
    pair: 'BTC/USDT',
    amount: 1000,
    leverage: 1,
    gridSize: 10,
    takeProfit: 1.5,
    stopLoss: 5,
    dcaStep: 2,
    maxSafetyOrders: 5
  });

  const handleCreate = () => {
    const template = BOT_TEMPLATES.find(t => t.id === selectedTemplate);
    onCreate({
      ...config,
      strategy: template?.name,
      market: config.leverage > 1 ? 'Futures' : 'Spot',
      type: selectedTemplate
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-[#0a0f18] w-full max-w-2xl rounded-[2rem] border border-cyan-500/20 shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-gradient-to-r from-cyan-900/20 to-transparent">
          <div>
            <h2 className="text-2xl font-black text-white font-tech tracking-tight">إنشاء بوت جديد</h2>
            <p className="text-gray-400 text-sm mt-1">خطوة {step} من 2: {step === 1 ? 'اختر الاستراتيجية' : 'إعدادات البوت'}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-xl transition-colors text-gray-400 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
          {step === 1 ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {BOT_TEMPLATES.map(template => (
                <div 
                  key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`cursor-pointer relative group p-6 rounded-2xl border transition-all duration-300 ${
                    selectedTemplate === template.id 
                      ? `bg-${template.color}-500/10 border-${template.color}-500 ring-1 ring-${template.color}-500 shadow-[0_0_30px_rgba(0,0,0,0.3)]` 
                      : 'bg-white/5 border-white/5 hover:border-white/20 hover:bg-white/10'
                  }`}
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-colors ${
                    selectedTemplate === template.id ? `bg-${template.color}-500 text-white` : `bg-white/5 text-gray-400 group-hover:text-white`
                  }`}>
                    {template.icon}
                  </div>
                  <h3 className="text-lg font-black text-white mb-2">{template.name}</h3>
                  <p className="text-gray-400 text-xs leading-relaxed mb-4 min-h-[40px]">{template.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    <span className="text-[10px] px-2 py-1 rounded-md bg-black/40 border border-white/10 text-gray-300">
                      {template.suitableFor}
                    </span>
                    <span className={`text-[10px] px-2 py-1 rounded-md border ${
                      template.risk === 'Low' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                      template.risk === 'Medium' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                      'bg-rose-500/10 text-rose-400 border-rose-500/20'
                    }`}>
                      Risk: {template.risk}
                    </span>
                  </div>

                  {selectedTemplate === template.id && (
                    <div className="absolute top-4 left-4 w-6 h-6 bg-cyan-500 rounded-full flex items-center justify-center shadow-lg animate-in zoom-in duration-200">
                      <Check size={14} className="text-black" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">اسم البوت</label>
                  <input 
                    type="text" 
                    value={config.name}
                    onChange={(e) => setConfig({...config, name: e.target.value})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none font-mono text-sm"
                    placeholder="My Trading Bot"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">زوج العملات</label>
                  <input 
                    type="text" 
                    value={config.pair}
                    onChange={(e) => setConfig({...config, pair: e.target.value.toUpperCase()})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none font-mono text-sm"
                    placeholder="BTC/USDT"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">مبلغ الاستثمار (USDT)</label>
                  <input 
                    type="number" 
                    value={config.amount}
                    onChange={(e) => setConfig({...config, amount: Number(e.target.value)})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none font-mono text-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-500 uppercase">الرافعة المالية (x)</label>
                  <div className="flex items-center gap-4">
                    <input 
                      type="range" 
                      min="1" 
                      max="20" 
                      step="1"
                      value={config.leverage}
                      onChange={(e) => setConfig({...config, leverage: Number(e.target.value)})}
                      className="flex-1 h-2 bg-white/10 rounded-lg appearance-none cursor-pointer accent-cyan-500"
                    />
                    <span className="font-mono text-cyan-400 font-bold w-12 text-center">x{config.leverage}</span>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-cyan-500/5 border border-cyan-500/10 space-y-4">
                <h4 className="text-sm font-black text-cyan-400 flex items-center gap-2">
                  <Settings size={16} />
                  إعدادات الاستراتيجية ({selectedTemplate === 'grid' ? 'Grid' : selectedTemplate === 'dca' ? 'DCA' : 'AI Scalp'})
                </h4>
                
                <div className="grid grid-cols-3 gap-4">
                  {selectedTemplate === 'grid' && (
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase">عدد الشبكات</label>
                      <input 
                        type="number" 
                        value={config.gridSize}
                        onChange={(e) => setConfig({...config, gridSize: Number(e.target.value)})}
                        className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-xs"
                      />
                    </div>
                  )}
                  
                  {selectedTemplate === 'dca' && (
                    <>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-gray-500 uppercase">خطوة التعزيز (%)</label>
                        <input 
                          type="number" 
                          value={config.dcaStep}
                          onChange={(e) => setConfig({...config, dcaStep: Number(e.target.value)})}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-xs"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-gray-500 uppercase">Max Safety Orders</label>
                        <input 
                          type="number" 
                          value={config.maxSafetyOrders}
                          onChange={(e) => setConfig({...config, maxSafetyOrders: Number(e.target.value)})}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-xs"
                        />
                      </div>
                    </>
                  )}

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">جني الأرباح (%)</label>
                    <input 
                      type="number" 
                      value={config.takeProfit}
                      onChange={(e) => setConfig({...config, takeProfit: Number(e.target.value)})}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-emerald-400 text-xs"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">وقف الخسارة (%)</label>
                    <input 
                      type="number" 
                      value={config.stopLoss}
                      onChange={(e) => setConfig({...config, stopLoss: Number(e.target.value)})}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-rose-400 text-xs"
                    />
                  </div>
                </div>
              </div>

              {config.leverage > 1 && (
                <div className="flex items-start gap-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs">
                  <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                  <p>تنبيه: استخدام الرافعة المالية يزيد من المخاطر بشكل كبير. تأكد من إعداد وقف الخسارة بشكل صحيح.</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-white/5 bg-black/40 flex justify-between items-center">
          {step === 2 ? (
            <button 
              onClick={() => setStep(1)}
              className="px-6 py-3 rounded-xl font-bold text-gray-400 hover:text-white hover:bg-white/5 transition-colors"
            >
              رجوع
            </button>
          ) : (
            <div></div>
          )}

          <button 
            onClick={() => {
              if (step === 1 && selectedTemplate) setStep(2);
              else if (step === 2) handleCreate();
            }}
            disabled={step === 1 && !selectedTemplate}
            className={`px-8 py-3 rounded-xl font-black shadow-lg transition-all flex items-center gap-2 ${
              (step === 1 && !selectedTemplate)
                ? 'bg-gray-800 text-gray-500 cursor-not-allowed'
                : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-cyan-500/20 hover:shadow-cyan-500/40'
            }`}
          >
            {step === 1 ? (
              <>
                التالي <ArrowRight size={18} />
              </>
            ) : (
              <>
                <Bot size={18} /> إنشاء البوت
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
