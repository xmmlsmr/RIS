import React, { useState, useEffect } from 'react';
import { Users, Share2, Copy, Check, DollarSign, TrendingUp, Gift, X, Hash, Link as LinkIcon } from 'lucide-react';

interface ReferralProgramProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ReferralProgram: React.FC<ReferralProgramProps> = ({ isOpen, onClose }) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [referralCode, setReferralCode] = useState('');
  const [referralLink, setReferralLink] = useState('');

  useEffect(() => {
    // Generate a unique referral code based on user info or random
    const userName = localStorage.getItem('userName') || 'User';
    const baseCode = userName.substring(0, 3).toUpperCase() + Math.floor(Math.random() * 10000).toString();
    // In a real app, this would come from the backend
    const savedCode = localStorage.getItem('referralCode');
    
    if (savedCode) {
      setReferralCode(savedCode);
      setReferralLink(`https://alpharadar.ai/ref/${savedCode}`);
    } else {
      localStorage.setItem('referralCode', baseCode);
      setReferralCode(baseCode);
      setReferralLink(`https://alpharadar.ai/ref/${baseCode}`);
    }
  }, []);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-[#0e1116] w-full max-w-3xl rounded-[2.5rem] border border-cyan-500/20 shadow-[0_0_80px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col relative max-h-[90vh]">
        
        {/* Background Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent rotate-45 pointer-events-none"></div>

        {/* Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5 relative z-10">
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <Gift className="text-cyan-500" size={24} />
            برنامج الإحالة (Referral)
          </h2>
          <button 
            onClick={onClose}
            className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all text-gray-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto custom-scrollbar relative z-10 space-y-8">
          
          {/* Hero Section */}
          <div className="text-center space-y-3">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/20 shadow-[0_0_40px_rgba(6,182,212,0.2)] mb-2">
              <Users size={40} className="text-cyan-400" />
            </div>
            <h3 className="text-2xl font-black text-white">ادعُ أصدقاءك واربح!</h3>
            <p className="text-gray-400 max-w-lg mx-auto text-sm leading-relaxed">
              شارك كود الإحالة الخاص بك واحصل على <span className="text-cyan-400 font-black text-base">5%</span> عمولة فورية من كل عملية إيداع يقوم بها أصدقاؤك.
            </p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-white/5 to-white/0 p-4 rounded-2xl border border-white/10 text-center group hover:border-cyan-500/30 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-cyan-500/10 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-150"></div>
              <div className="w-10 h-10 mx-auto bg-cyan-500/10 rounded-xl flex items-center justify-center mb-2 group-hover:scale-110 transition-transform relative z-10">
                <Users size={20} className="text-cyan-400" />
              </div>
              <div className="text-2xl font-black text-white mb-1 relative z-10">0</div>
              <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider relative z-10">إجمالي الإحالات</div>
            </div>
            <div className="bg-gradient-to-br from-white/5 to-white/0 p-4 rounded-2xl border border-white/10 text-center group hover:border-emerald-500/30 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/10 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-150"></div>
              <div className="w-10 h-10 mx-auto bg-emerald-500/10 rounded-xl flex items-center justify-center mb-2 group-hover:scale-110 transition-transform relative z-10">
                <DollarSign size={20} className="text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white mb-1 relative z-10">$0.00</div>
              <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider relative z-10">الأرباح الكلية</div>
            </div>
            <div className="bg-gradient-to-br from-white/5 to-white/0 p-4 rounded-2xl border border-white/10 text-center group hover:border-amber-500/30 transition-all relative overflow-hidden">
              <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/10 rounded-bl-full -mr-8 -mt-8 transition-transform group-hover:scale-150"></div>
              <div className="w-10 h-10 mx-auto bg-amber-500/10 rounded-xl flex items-center justify-center mb-2 group-hover:scale-110 transition-transform relative z-10">
                <TrendingUp size={20} className="text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white mb-1 relative z-10">$0.00</div>
              <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider relative z-10">قيد المعالجة</div>
            </div>
          </div>

          {/* Referral Tools */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Referral Code */}
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:border-white/20 transition-all">
              <div className="flex items-center gap-2 mb-3">
                <Hash className="text-cyan-500" size={16} />
                <label className="text-xs font-bold text-gray-300">كود الإحالة الخاص بك</label>
              </div>
              <div className="flex gap-2">
                <div className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-3 text-lg font-black text-center text-white tracking-widest uppercase font-mono">
                  {referralCode}
                </div>
                <button 
                  onClick={handleCopyCode}
                  className="px-4 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 active:scale-95 border border-white/5"
                >
                  {copiedCode ? <Check size={16} className="text-emerald-400" /> : <Copy size={16} />}
                </button>
              </div>
              <p className="text-[9px] text-gray-500 mt-2">شارك هذا الكود مع أصدقائك ليستخدموه أثناء التسجيل.</p>
            </div>

            {/* Referral Link */}
            <div className="bg-white/5 p-4 rounded-2xl border border-white/10 hover:border-white/20 transition-all">
              <div className="flex items-center gap-2 mb-3">
                <LinkIcon className="text-cyan-500" size={16} />
                <label className="text-xs font-bold text-gray-300">رابط الإحالة المباشر</label>
              </div>
              <div className="flex gap-2">
                <div className="flex-1 bg-black/40 border border-white/10 rounded-xl px-3 py-3 text-xs font-mono text-gray-400 truncate flex items-center">
                  {referralLink}
                </div>
                <button 
                  onClick={handleCopyLink}
                  className="px-4 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95"
                >
                  {copiedLink ? <Check size={16} /> : <Copy size={16} />}
                </button>
              </div>
              <p className="text-[9px] text-gray-500 mt-2">أي شخص يسجل عبر هذا الرابط سيتم احتسابه لك تلقائياً.</p>
            </div>
          </div>

          {/* Recent Referrals List */}
          <div className="bg-white/5 rounded-3xl border border-white/10 overflow-hidden">
            <div className="p-6 border-b border-white/5 flex items-center justify-between">
              <h4 className="text-base font-bold text-white flex items-center gap-2">
                <Users size={18} className="text-cyan-500" />
                آخر المسجلين
              </h4>
              <button className="text-xs text-cyan-500 hover:text-cyan-400 font-bold">عرض الكل</button>
            </div>
            <div className="divide-y divide-white/5">
              {/* Empty State */}
              <div className="p-8 text-center">
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users size={32} className="text-gray-600" />
                </div>
                <p className="text-gray-400 font-bold text-sm">لا توجد إحالات حتى الآن</p>
                <p className="text-gray-600 text-xs mt-1">شارك رابط الإحالة الخاص بك لتبدأ في الربح!</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
