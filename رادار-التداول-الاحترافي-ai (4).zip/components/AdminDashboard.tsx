import React, { useState } from 'react';
import { Users, Package, CreditCard, Edit, Trash2, Check, X, Plus, Search, Save, Settings, DollarSign, Crown, Activity, ArrowDownLeft, ArrowUpRight, Copy, Layout, Eye, EyeOff, ArrowUp, ArrowDown } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { useWallet, Transaction } from '../context/WalletContext';

import { VipSettingsPage } from './VipSettingsPage';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'vip' | 'admin';
  status: 'active' | 'suspended';
  joinedDate: string;
}

interface Plan {
  id: string;
  name: string;
  price: number;
  duration: string;
  features: string[];
}

export const AdminDashboard: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'vip' | 'finance' | 'settings' | 'transactions'>('overview');
  const { siteSettings, financeSettings, updateSiteSettings, updateFinanceSettings } = useSettings();
  const { transactions, updateTransactionStatus } = useWallet();
  
  // Local state for forms to avoid constant re-renders on every keystroke, 
  // or just use the context state directly if performance is fine. 
  // For simplicity, I'll use local state initialized from context and save on submit.
  const [localSiteSettings, setLocalSiteSettings] = useState(siteSettings);
  const [localFinanceSettings, setLocalFinanceSettings] = useState(financeSettings);

  // Users Data
  const [users, setUsers] = useState<User[]>(() => {
    const storedUsers = localStorage.getItem('users');
    return storedUsers ? JSON.parse(storedUsers) : [
      { id: '1', name: 'Ahmed Ali', email: 'ahmed@example.com', role: 'vip', status: 'active', joinedDate: '2024-01-15' },
      { id: '2', name: 'Sarah Khan', email: 'sarah@example.com', role: 'user', status: 'active', joinedDate: '2024-02-10' },
      { id: '3', name: 'Mohamed Sami', email: 'mohamed@example.com', role: 'user', status: 'suspended', joinedDate: '2024-03-05' },
      { id: '4', name: 'Admin User', email: 'admin@alpharadar.ai', role: 'admin', status: 'active', joinedDate: '2023-11-01' },
    ];
  });

  // Sync users with localStorage whenever they change
  React.useEffect(() => {
    localStorage.setItem('users', JSON.stringify(users));
  }, [users]);

  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null);

  // Dashboard Widgets State
  const [showWidgetCustomizer, setShowWidgetCustomizer] = useState(false);
  const [widgets, setWidgets] = useState([
    { id: 'total_users', title: 'إجمالي المستخدمين', visible: true },
    { id: 'vip_subscribers', title: 'مشتركي VIP', visible: true },
    { id: 'pending_requests', title: 'طلبات معلقة', visible: true },
    { id: 'total_deposits', title: 'إجمالي الإيداعات', visible: true },
  ]);

  const toggleWidget = (id: string) => {
    setWidgets(widgets.map(w => w.id === id ? { ...w, visible: !w.visible } : w));
  };

  const moveWidget = (index: number, direction: 'up' | 'down') => {
    const newWidgets = [...widgets];
    if (direction === 'up' && index > 0) {
      [newWidgets[index], newWidgets[index - 1]] = [newWidgets[index - 1], newWidgets[index]];
    } else if (direction === 'down' && index < newWidgets.length - 1) {
      [newWidgets[index], newWidgets[index + 1]] = [newWidgets[index + 1], newWidgets[index]];
    }
    setWidgets(newWidgets);
  };

  // --- Handlers ---

  const handleUpdateSiteSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSiteSettings(localSiteSettings);
    alert('تم حفظ إعدادات الموقع بنجاح');
  };

  const handleUpdateFinanceSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateFinanceSettings(localFinanceSettings);
    alert('تم حفظ الإعدادات المالية بنجاح');
  };

  const handleTransactionAction = (id: string, action: 'approved' | 'rejected') => {
    updateTransactionStatus(id, action);
  };

  const handleUserRoleChange = (id: string, newRole: 'user' | 'vip' | 'admin') => {
    setUsers(users.map(u => u.id === id ? { ...u, role: newRole } : u));
  };

  const handleUserStatusChange = (id: string, newStatus: 'active' | 'suspended') => {
    setUsers(users.map(u => u.id === id ? { ...u, status: newStatus } : u));
  };

  const handleDeleteUser = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
      setUsers(users.filter(u => u.id !== id));
    }
  };

  const pendingTransactions = transactions.filter(t => t.status === 'pending').length;

  return (
    <div className="fixed inset-0 z-50 bg-[#050505] text-white overflow-hidden flex flex-col md:flex-row font-sans" dir="rtl">
      {/* Sidebar (Desktop) */}
      <div className="hidden md:flex w-64 bg-[#0e1116] border-l border-white/5 flex-col">
        <div className="p-6 border-b border-white/5">
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <div className="w-8 h-8 bg-rose-600 rounded-lg flex items-center justify-center shadow-lg shadow-rose-600/20">A</div>
            لوحة الإدارة
          </h2>
          <p className="text-[10px] text-gray-500 mt-2 font-mono">V 2.0.1 - SUPER ADMIN</p>
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto custom-scrollbar">
          <button onClick={() => setActiveTab('overview')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'overview' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <Activity size={18} /> نظرة عامة
          </button>
          <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'settings' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <Settings size={18} /> إعدادات الموقع
          </button>
          <button onClick={() => setActiveTab('finance')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'finance' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <DollarSign size={18} /> الإعدادات المالية
          </button>
          <button onClick={() => setActiveTab('transactions')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'transactions' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <CreditCard size={18} /> 
            العمليات المالية
            {pendingTransactions > 0 && <span className="mr-auto bg-rose-500 text-white text-[10px] px-2 py-0.5 rounded-full">{pendingTransactions}</span>}
          </button>
          <button onClick={() => setActiveTab('users')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'users' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <Users size={18} /> إدارة المستخدمين
          </button>
          <button onClick={() => setActiveTab('vip')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all ${activeTab === 'vip' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-500 hover:text-white hover:bg-white/5'}`}>
            <Crown size={18} /> التحكم في VIP
          </button>
        </nav>
        <div className="p-4 border-t border-white/5">
          <button onClick={onClose} className="w-full py-3 bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 rounded-xl font-bold transition-all flex items-center justify-center gap-2">
            <X size={18} /> تسجيل خروج
          </button>
        </div>
      </div>

      {/* Mobile Header */}
      <div className="md:hidden p-4 bg-[#0e1116] border-b border-white/5 flex justify-between items-center">
         <h2 className="text-lg font-black text-white flex items-center gap-2">
            <div className="w-8 h-8 bg-rose-600 rounded-lg flex items-center justify-center shadow-lg shadow-rose-600/20">A</div>
            لوحة الإدارة
         </h2>
         <button onClick={onClose} className="p-2 bg-white/5 rounded-lg text-gray-400">
           <X size={20} />
         </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto bg-[#050505] p-4 md:p-8 custom-scrollbar pb-24 md:pb-8">
        
        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="flex justify-between items-center">
              <h3 className="text-3xl font-black text-white">لوحة القيادة</h3>
              <button 
                onClick={() => setShowWidgetCustomizer(!showWidgetCustomizer)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${showWidgetCustomizer ? 'bg-cyan-500 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
              >
                <Layout size={16} />
                تخصيص الواجهة
              </button>
            </div>

            {showWidgetCustomizer && (
              <div className="bg-[#0e1116] p-6 rounded-3xl border border-white/5 animate-in fade-in slide-in-from-top-4 duration-300">
                <h4 className="text-sm font-bold text-gray-400 mb-4">ترتيب وإظهار العناصر</h4>
                <div className="space-y-2">
                  {widgets.map((widget, index) => (
                    <div key={widget.id} className="flex items-center justify-between bg-black/20 p-3 rounded-xl border border-white/5">
                      <span className="text-sm font-bold text-white">{widget.title}</span>
                      <div className="flex items-center gap-2">
                        <button 
                          onClick={() => moveWidget(index, 'up')} 
                          disabled={index === 0}
                          className="p-1.5 hover:bg-white/10 rounded-lg text-gray-400 disabled:opacity-30 transition-colors"
                        >
                          <ArrowUp size={14} />
                        </button>
                        <button 
                          onClick={() => moveWidget(index, 'down')} 
                          disabled={index === widgets.length - 1}
                          className="p-1.5 hover:bg-white/10 rounded-lg text-gray-400 disabled:opacity-30 transition-colors"
                        >
                          <ArrowDown size={14} />
                        </button>
                        <div className="w-px h-4 bg-white/10 mx-1"></div>
                        <button 
                          onClick={() => toggleWidget(widget.id)}
                          className={`p-1.5 rounded-lg transition-colors ${widget.visible ? 'text-emerald-500 bg-emerald-500/10' : 'text-gray-500 bg-white/5'}`}
                        >
                          {widget.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {widgets.map((widget) => {
                if (!widget.visible) return null;
                
                switch (widget.id) {
                  case 'total_users':
                    return (
                      <div key={widget.id} className="bg-[#0e1116] p-6 rounded-3xl border border-white/5 animate-in fade-in zoom-in duration-300">
                        <div className="text-gray-400 text-sm font-bold mb-2">إجمالي المستخدمين</div>
                        <div className="text-3xl font-black text-white">{users.length}</div>
                      </div>
                    );
                  case 'vip_subscribers':
                    return (
                      <div key={widget.id} className="bg-[#0e1116] p-6 rounded-3xl border border-white/5 animate-in fade-in zoom-in duration-300">
                        <div className="text-gray-400 text-sm font-bold mb-2">مشتركي VIP</div>
                        <div className="text-3xl font-black text-amber-500">{users.filter(u => u.role === 'vip').length}</div>
                      </div>
                    );
                  case 'pending_requests':
                    return (
                      <div key={widget.id} className="bg-[#0e1116] p-6 rounded-3xl border border-white/5 animate-in fade-in zoom-in duration-300">
                        <div className="text-gray-400 text-sm font-bold mb-2">طلبات معلقة</div>
                        <div className="text-3xl font-black text-rose-500">{pendingTransactions}</div>
                      </div>
                    );
                  case 'total_deposits':
                    return (
                      <div key={widget.id} className="bg-[#0e1116] p-6 rounded-3xl border border-white/5 animate-in fade-in zoom-in duration-300">
                        <div className="text-gray-400 text-sm font-bold mb-2">إجمالي الإيداعات</div>
                        <div className="text-3xl font-black text-emerald-500">$12,450</div>
                      </div>
                    );
                  default:
                    return null;
                }
              })}
            </div>
          </div>
        )}

        {/* Site Settings Tab */}
        {activeTab === 'settings' && (
          <div className="space-y-8 max-w-4xl">
            <h3 className="text-3xl font-black text-white flex items-center gap-3">
              <Settings className="text-cyan-500" /> إعدادات الموقع
            </h3>
            <form onSubmit={handleUpdateSiteSettings} className="space-y-6 bg-[#0e1116] p-8 rounded-3xl border border-white/5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-400">اسم الموقع</label>
                  <input 
                    type="text" 
                    value={localSiteSettings.siteName}
                    onChange={e => setLocalSiteSettings({...localSiteSettings, siteName: e.target.value})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-400">اللون الأساسي (Hex)</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={localSiteSettings.primaryColor}
                      onChange={e => setLocalSiteSettings({...localSiteSettings, primaryColor: e.target.value})}
                      className="h-12 w-12 rounded-xl bg-transparent border border-white/10 cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={localSiteSettings.primaryColor}
                      onChange={e => setLocalSiteSettings({...localSiteSettings, primaryColor: e.target.value})}
                      className="flex-1 bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-400">وصف الموقع (SEO)</label>
                <textarea 
                  value={localSiteSettings.siteDescription}
                  onChange={e => setLocalSiteSettings({...localSiteSettings, siteDescription: e.target.value})}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none h-24 resize-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-400">نوع الخط</label>
                  <select 
                    value={localSiteSettings.fontFamily}
                    onChange={e => setLocalSiteSettings({...localSiteSettings, fontFamily: e.target.value})}
                    className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="Inter">Inter (Default)</option>
                    <option value="Cairo">Cairo (Arabic)</option>
                    <option value="Tajawal">Tajawal</option>
                    <option value="Roboto">Roboto</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-400">وضع الصيانة</label>
                  <div className="flex items-center gap-4 p-3 bg-black/40 border border-white/10 rounded-xl">
                    <button 
                      type="button"
                      onClick={() => setLocalSiteSettings({...localSiteSettings, maintenanceMode: !localSiteSettings.maintenanceMode})}
                      className={`w-12 h-6 rounded-full transition-colors relative ${localSiteSettings.maintenanceMode ? 'bg-rose-500' : 'bg-gray-600'}`}
                    >
                      <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${localSiteSettings.maintenanceMode ? 'left-1' : 'right-1'}`}></div>
                    </button>
                    <span className={`text-sm font-bold ${localSiteSettings.maintenanceMode ? 'text-rose-500' : 'text-gray-400'}`}>
                      {localSiteSettings.maintenanceMode ? 'مفعل' : 'معطل'}
                    </span>
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full py-4 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-xl shadow-lg shadow-cyan-500/20 transition-all">
                حفظ التغييرات
              </button>
            </form>
          </div>
        )}

        {/* Finance Settings Tab */}
        {activeTab === 'finance' && (
          <div className="space-y-8 max-w-4xl">
            <h3 className="text-3xl font-black text-white flex items-center gap-3">
              <DollarSign className="text-emerald-500" /> الإعدادات المالية
            </h3>
            
            <form onSubmit={handleUpdateFinanceSettings} className="space-y-8">
              {/* Deposit Methods */}
              <div className="bg-[#0e1116] p-8 rounded-3xl border border-white/5 space-y-6">
                <div className="flex justify-between items-center border-b border-white/5 pb-4 mb-4">
                  <h4 className="text-xl font-bold text-white">طرق الإيداع</h4>
                  <button 
                    type="button"
                    onClick={() => {
                      setLocalFinanceSettings({
                        ...localFinanceSettings,
                        depositMethods: [
                          ...localFinanceSettings.depositMethods,
                          { id: Date.now().toString(), name: 'New Method', network: 'Network', address: '', enabled: true }
                        ]
                      });
                    }}
                    className="flex items-center gap-2 px-3 py-1.5 bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/20 rounded-lg text-xs font-bold transition-colors"
                  >
                    <Plus size={14} /> إضافة طريقة
                  </button>
                </div>
                
                {localFinanceSettings.depositMethods.map((method, index) => (
                  <div key={index} className="space-y-4 p-4 bg-black/20 rounded-xl border border-white/5 relative group">
                    <button
                      type="button"
                      onClick={() => {
                        const newMethods = localFinanceSettings.depositMethods.filter((_, i) => i !== index);
                        setLocalFinanceSettings({...localFinanceSettings, depositMethods: newMethods});
                      }}
                      className="absolute top-4 left-4 text-gray-600 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                      title="حذف الطريقة"
                    >
                      <Trash2 size={16} />
                    </button>

                    <div className="flex justify-between items-center pl-8">
                      <h5 className="font-bold text-gray-300">طريقة {index + 1}</h5>
                      <button 
                        type="button"
                        onClick={() => {
                          const newMethods = [...localFinanceSettings.depositMethods];
                          newMethods[index].enabled = !newMethods[index].enabled;
                          setLocalFinanceSettings({...localFinanceSettings, depositMethods: newMethods});
                        }}
                        className={`text-xs font-bold px-3 py-1 rounded-lg ${method.enabled ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}
                      >
                        {method.enabled ? 'نشط' : 'معطل'}
                      </button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500">اسم العملة</label>
                        <input 
                          value={method.name}
                          onChange={e => {
                            const newMethods = [...localFinanceSettings.depositMethods];
                            newMethods[index].name = e.target.value;
                            setLocalFinanceSettings({...localFinanceSettings, depositMethods: newMethods});
                          }}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-sm text-white"
                          placeholder="مثال: USDT"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500">الشبكة</label>
                        <input 
                          value={method.network}
                          onChange={e => {
                            const newMethods = [...localFinanceSettings.depositMethods];
                            newMethods[index].network = e.target.value;
                            setLocalFinanceSettings({...localFinanceSettings, depositMethods: newMethods});
                          }}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-sm text-white"
                          placeholder="مثال: TRC20"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500">عنوان المحفظة</label>
                        <input 
                          value={method.address}
                          onChange={e => {
                            const newMethods = [...localFinanceSettings.depositMethods];
                            newMethods[index].address = e.target.value;
                            setLocalFinanceSettings({...localFinanceSettings, depositMethods: newMethods});
                          }}
                          className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-sm text-white font-mono"
                          placeholder="عنوان المحفظة..."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Limits & Fees */}
              <div className="bg-[#0e1116] p-8 rounded-3xl border border-white/5 space-y-6">
                <h4 className="text-xl font-bold text-white mb-4 border-b border-white/5 pb-4">الحدود والرسوم</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-400">الحد الأدنى للإيداع ($)</label>
                    <input 
                      type="number"
                      value={localFinanceSettings.minDeposit}
                      onChange={e => setLocalFinanceSettings({...localFinanceSettings, minDeposit: Number(e.target.value)})}
                      className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-400">الحد الأدنى للسحب ($)</label>
                    <input 
                      type="number"
                      value={localFinanceSettings.minWithdraw}
                      onChange={e => setLocalFinanceSettings({...localFinanceSettings, minWithdraw: Number(e.target.value)})}
                      className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-400">رسوم السحب ($)</label>
                    <input 
                      type="number"
                      value={localFinanceSettings.withdrawFee}
                      onChange={e => setLocalFinanceSettings({...localFinanceSettings, withdrawFee: Number(e.target.value)})}
                      className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <button type="submit" className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-lg shadow-emerald-500/20 transition-all">
                حفظ الإعدادات المالية
              </button>
            </form>
          </div>
        )}

        {/* Transactions Tab */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <h3 className="text-3xl font-black text-white flex items-center gap-3">
              <CreditCard className="text-blue-500" /> التحقق من العمليات
            </h3>
            
            <div className="bg-[#0e1116] rounded-2xl border border-white/5 overflow-x-auto">
              <table className="w-full text-right min-w-[800px]">
                <thead className="bg-white/5 text-gray-400 text-xs uppercase font-bold">
                  <tr>
                    <th className="px-6 py-4">النوع</th>
                    <th className="px-6 py-4">المستخدم</th>
                    <th className="px-6 py-4">المبلغ</th>
                    <th className="px-6 py-4">التفاصيل</th>
                    <th className="px-6 py-4">الحالة</th>
                    <th className="px-6 py-4">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {transactions.map(tx => (
                    <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-lg text-xs font-black uppercase ${tx.type === 'deposit' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500'}`}>
                          {tx.type === 'deposit' ? 'إيداع' : 'سحب'}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-bold">{tx.userName}</td>
                      <td className="px-6 py-4 font-mono font-black text-white">${tx.amount}</td>
                      <td className="px-6 py-4 text-xs text-gray-400">
                        <div>{tx.method}</div>
                        <div className="font-mono">{tx.txId || tx.address || '-'}</div>
                        <div>{tx.date}</div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2 py-1 rounded-lg text-xs font-black uppercase ${
                          tx.status === 'approved' ? 'bg-emerald-500/10 text-emerald-500' : 
                          tx.status === 'rejected' ? 'bg-rose-500/10 text-rose-500' : 
                          'bg-amber-500/10 text-amber-500'
                        }`}>
                          {tx.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 flex gap-2">
                        {tx.status === 'pending' && (
                          <>
                            <button onClick={() => handleTransactionAction(tx.id, 'approved')} className="p-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-500 rounded-lg transition-colors" title="قبول">
                              <Check size={16} />
                            </button>
                            <button onClick={() => handleTransactionAction(tx.id, 'rejected')} className="p-2 bg-rose-500/20 hover:bg-rose-500/30 text-rose-500 rounded-lg transition-colors" title="رفض">
                              <X size={16} />
                            </button>
                          </>
                        )}
                        <button 
                          onClick={() => setSelectedTransaction(tx)} 
                          className="p-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white rounded-lg transition-colors flex items-center gap-2 text-xs font-bold"
                        >
                          <Search size={14} />
                          عرض التفاصيل
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-3xl font-black text-white flex items-center gap-3">
                <Users className="text-cyan-500" />
                إدارة المستخدمين
              </h3>
              <div className="relative">
                <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
                <input type="text" placeholder="بحث..." className="bg-white/5 border border-white/10 rounded-xl py-2 pr-10 pl-4 text-sm focus:outline-none focus:border-cyan-500/50 text-white" />
              </div>
            </div>
            
            <div className="bg-[#0e1116] rounded-2xl border border-white/5 overflow-x-auto">
              <table className="w-full text-right min-w-[800px]">
                <thead className="bg-white/5 text-gray-400 text-xs uppercase font-bold">
                  <tr>
                    <th className="px-6 py-4">المستخدم</th>
                    <th className="px-6 py-4">البريد الإلكتروني</th>
                    <th className="px-6 py-4">الدور</th>
                    <th className="px-6 py-4">الحالة</th>
                    <th className="px-6 py-4">تاريخ الانضمام</th>
                    <th className="px-6 py-4">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {users.map(user => (
                    <tr key={user.id} className="hover:bg-white/5 transition-colors">
                      <td className="px-6 py-4 font-bold text-white">{user.name}</td>
                      <td className="px-6 py-4 text-gray-400 font-mono text-sm">{user.email}</td>
                      <td className="px-6 py-4">
                        <select 
                          value={user.role}
                          onChange={(e) => handleUserRoleChange(user.id, e.target.value as any)}
                          className={`bg-transparent border-none text-xs font-black uppercase cursor-pointer focus:outline-none ${
                            user.role === 'vip' ? 'text-amber-500' : 
                            user.role === 'admin' ? 'text-rose-500' : 
                            'text-gray-500'
                          }`}
                        >
                          <option value="user" className="bg-gray-900 text-gray-500">USER</option>
                          <option value="vip" className="bg-gray-900 text-amber-500">VIP</option>
                          <option value="admin" className="bg-gray-900 text-rose-500">ADMIN</option>
                        </select>
                      </td>
                      <td className="px-6 py-4">
                        <button 
                          onClick={() => handleUserStatusChange(user.id, user.status === 'active' ? 'suspended' : 'active')}
                          className={`px-2 py-1 rounded-lg text-xs font-black uppercase transition-colors ${user.status === 'active' ? 'bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20' : 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20'}`}
                        >
                          {user.status}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-sm">{user.joinedDate}</td>
                      <td className="px-6 py-4 flex gap-2">
                        <button onClick={() => handleDeleteUser(user.id)} className="p-2 hover:bg-rose-500/20 text-rose-500 rounded-lg transition-colors" title="حذف"><Trash2 size={16} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* VIP Settings Tab */}
        {activeTab === 'vip' && (
          <VipSettingsPage />
        )}

      </div>

      {/* Mobile Bottom Navigation */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#0e1116] border-t border-white/5 p-2 flex justify-around items-center z-40 pb-safe">
        <button onClick={() => setActiveTab('overview')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab === 'overview' ? 'text-cyan-400' : 'text-gray-500'}`}>
          <Activity size={20} />
          <span className="text-[10px] font-bold">الرئيسية</span>
        </button>
        <button onClick={() => setActiveTab('transactions')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab === 'transactions' ? 'text-cyan-400' : 'text-gray-500'}`}>
          <CreditCard size={20} />
          <span className="text-[10px] font-bold">العمليات</span>
        </button>
        <button onClick={() => setActiveTab('users')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab === 'users' ? 'text-cyan-400' : 'text-gray-500'}`}>
          <Users size={20} />
          <span className="text-[10px] font-bold">المستخدمين</span>
        </button>
        <button onClick={() => setActiveTab('settings')} className={`flex flex-col items-center gap-1 p-2 rounded-lg ${activeTab === 'settings' ? 'text-cyan-400' : 'text-gray-500'}`}>
          <Settings size={20} />
          <span className="text-[10px] font-bold">الإعدادات</span>
        </button>
      </div>

      {/* Transaction Details Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0e1116] w-full max-w-md rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-white/5 flex justify-between items-center bg-white/5">
              <h3 className="text-xl font-black text-white flex items-center gap-2">
                {selectedTransaction.type === 'deposit' ? <ArrowDownLeft className="text-emerald-500" /> : <ArrowUpRight className="text-rose-500" />}
                تفاصيل العملية
              </h3>
              <button onClick={() => setSelectedTransaction(null)} className="text-gray-500 hover:text-white transition-colors">
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div className="flex justify-center">
                <div className="text-center">
                  <div className="text-sm text-gray-500 font-bold mb-1">المبلغ</div>
                  <div className="text-4xl font-black text-white tracking-tight">
                    ${selectedTransaction.amount.toLocaleString()}
                  </div>
                  <div className={`inline-block px-3 py-1 rounded-full text-xs font-black uppercase mt-3 ${
                    selectedTransaction.status === 'approved' ? 'bg-emerald-500/10 text-emerald-500' : 
                    selectedTransaction.status === 'rejected' ? 'bg-rose-500/10 text-rose-500' : 
                    'bg-amber-500/10 text-amber-500'
                  }`}>
                    {selectedTransaction.status}
                  </div>
                </div>
              </div>

              <div className="bg-black/40 rounded-xl border border-white/5 p-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500 font-bold">المستخدم</span>
                  <span className="text-white">{selectedTransaction.userName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 font-bold">النوع</span>
                  <span className="text-white">{selectedTransaction.type === 'deposit' ? 'إيداع' : 'سحب'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 font-bold">الطريقة</span>
                  <span className="text-white">{selectedTransaction.method}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500 font-bold">التاريخ</span>
                  <span className="text-white font-mono">{selectedTransaction.date}</span>
                </div>
                <div className="pt-3 border-t border-white/5">
                  <span className="text-gray-500 font-bold block mb-1">
                    {selectedTransaction.type === 'deposit' ? 'رقم العملية (TxID)' : 'عنوان المحفظة'}
                  </span>
                  <div className="flex items-center gap-2 bg-black/40 p-2 rounded-lg border border-white/5">
                    <code className="text-xs text-cyan-400 font-mono break-all">
                      {selectedTransaction.txId || selectedTransaction.address || '---'}
                    </code>
                    <button className="text-gray-500 hover:text-white" title="نسخ">
                      <Copy size={14} />
                    </button>
                  </div>
                </div>
              </div>

              {selectedTransaction.status === 'pending' && (
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <button 
                    onClick={() => {
                      handleTransactionAction(selectedTransaction.id, 'approved');
                      setSelectedTransaction(null);
                    }}
                    className="py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    <Check size={18} /> قبول
                  </button>
                  <button 
                    onClick={() => {
                      handleTransactionAction(selectedTransaction.id, 'rejected');
                      setSelectedTransaction(null);
                    }}
                    className="py-3 bg-rose-600 hover:bg-rose-500 text-white font-black rounded-xl shadow-lg shadow-rose-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    <X size={18} /> رفض
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
