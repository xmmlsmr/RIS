import React, { useState, useMemo, useEffect } from 'react';
import { Copy, Check, QrCode, ArrowRight, Wallet, ShieldCheck, AlertTriangle, History } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useWallet } from '../context/WalletContext';
import { useSettings } from '../context/SettingsContext';

interface DepositPageProps {
  onClose: () => void;
  onDepositSuccess?: () => void;
}

export const DepositPage: React.FC<DepositPageProps> = ({ onClose, onDepositSuccess }) => {
  const { user } = useAuth();
  const { addTransaction } = useWallet();
  const { financeSettings } = useSettings();

  const assets = useMemo(() => {
    const groups: Record<string, { symbol: string, networks: string[] }> = {};
    financeSettings.depositMethods.filter(m => m.enabled).forEach(m => {
      if (!groups[m.name]) {
        groups[m.name] = { symbol: m.name, networks: [] };
      }
      if (!groups[m.name].networks.includes(m.network)) {
        groups[m.name].networks.push(m.network);
      }
    });
    return Object.values(groups);
  }, [financeSettings.depositMethods]);

  const [selectedAsset, setSelectedAsset] = useState<{ symbol: string, networks: string[] }>(assets[0] || { symbol: '', networks: [] });
  const [selectedNetwork, setSelectedNetwork] = useState<string>(assets[0]?.networks[0] || '');
  const [address, setAddress] = useState('');
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  useEffect(() => {
    if (assets.length > 0 && (!selectedAsset.symbol || !assets.find(a => a.symbol === selectedAsset.symbol))) {
      setSelectedAsset(assets[0]);
      setSelectedNetwork(assets[0].networks[0]);
    }
  }, [assets, selectedAsset]);

  useEffect(() => {
    if (selectedAsset.symbol && selectedNetwork) {
      const method = financeSettings.depositMethods.find(
        m => m.name === selectedAsset.symbol && m.network === selectedNetwork
      );
      setAddress(method?.address || '');
    }
  }, [selectedAsset, selectedNetwork, financeSettings.depositMethods]);

  const handleCopy = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAssetChange = (assetSymbol: string) => {
    const asset = assets.find(a => a.symbol === assetSymbol);
    if (asset) {
      setSelectedAsset(asset);
      setSelectedNetwork(asset.networks[0]);
    }
  };

  const handleConfirm = async () => {
    if (!amount || parseFloat(amount) <= 0) {
      alert('يرجى إدخال مبلغ صحيح');
      return;
    }

    if (parseFloat(amount) < financeSettings.minDeposit) {
      alert(`الحد الأدنى للإيداع هو $${financeSettings.minDeposit}`);
      return;
    }

    setIsVerifying(true);
    // Simulate verification delay
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    addTransaction({
      userId: user?.id || 'guest', 
      userName: user?.name || 'Guest User', 
      type: 'deposit',
      amount: parseFloat(amount),
      method: `${selectedAsset.symbol} (${selectedNetwork})`,
      txId: `Tx${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      status: 'pending'
    });

    setIsVerifying(false);
    if (onDepositSuccess) onDepositSuccess();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-[#0e1116] w-full max-w-2xl rounded-[2rem] border border-cyan-500/20 shadow-[0_0_50px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col md:flex-row relative">
        
        {/* Background Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent rotate-45 pointer-events-none"></div>

        {/* Sidebar / Info */}
        <div className="w-full md:w-1/3 bg-black/40 p-5 border-l border-white/5 flex flex-col relative z-10">
          <div className="mb-6">
            <h2 className="text-xl font-black text-white mb-1.5 flex items-center gap-2">
              <Wallet className="text-cyan-500" size={20} />
              إيداع
            </h2>
            <p className="text-xs text-gray-400">قم بإيداع العملات الرقمية في محفظتك الآمنة.</p>
          </div>

          <div className="space-y-3 flex-1">
            <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/10">
              <div className="flex items-start gap-2">
                <ShieldCheck className="text-blue-500 shrink-0 mt-0.5" size={16} />
                <div>
                  <h4 className="text-[10px] font-bold text-blue-400 mb-0.5">إيداع آمن</h4>
                  <p className="text-[9px] text-gray-400 leading-relaxed">
                    جميع الإيداعات تخضع لعمليات فحص أمني متقدمة لضمان سلامة أصولك.
                  </p>
                </div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/10">
              <div className="flex items-start gap-2">
                <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={16} />
                <div>
                  <h4 className="text-[10px] font-bold text-amber-400 mb-0.5">تنبيه هام</h4>
                  <p className="text-[9px] text-gray-400 leading-relaxed">
                    تأكد من اختيار الشبكة الصحيحة. إرسال العملات عبر شبكة خاطئة قد يؤدي إلى فقدانها نهائياً.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="mt-6 flex items-center justify-center gap-2 text-gray-500 hover:text-white transition-colors text-xs font-bold"
          >
            <ArrowRight size={14} />
            العودة للرئيسية
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-5 md:p-6 relative z-10">
          {isVerifying ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 animate-in fade-in duration-500">
              <div className="relative w-20 h-20">
                <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-cyan-500 rounded-full border-t-transparent animate-spin"></div>
                <ShieldCheck className="absolute inset-0 m-auto text-cyan-500 animate-pulse" size={32} />
              </div>
              <div>
                <h3 className="text-lg font-black text-white mb-1">جاري التحقق من الإيداع</h3>
                <p className="text-gray-400 text-xs">يرجى الانتظار، قد تستغرق العملية بضع دقائق...</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              
              {/* Asset Selection */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400">العملة</label>
                <div className="grid grid-cols-3 gap-2">
                  {assets.map(asset => (
                    <button
                      key={asset.symbol}
                      onClick={() => handleAssetChange(asset.symbol)}
                      className={`p-2.5 rounded-xl border flex items-center justify-center gap-1.5 transition-all ${
                        selectedAsset.symbol === asset.symbol
                          ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                          : 'bg-black/40 border-white/5 hover:bg-white/5 text-gray-400'
                      }`}
                    >
                      <span className="font-black text-sm">{asset.symbol}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Network Selection */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400">الشبكة</label>
                <div className="relative">
                  <select 
                    value={selectedNetwork}
                    onChange={(e) => {
                      setSelectedNetwork(e.target.value);
                    }}
                    className="w-full p-2.5 rounded-xl bg-black/40 border border-white/10 text-white font-bold text-xs focus:outline-none focus:border-cyan-500 transition-colors appearance-none"
                  >
                    {selectedAsset.networks.map(net => (
                      <option key={net} value={net}>{net}</option>
                    ))}
                  </select>
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-500">
                    <ArrowRight size={12} className="rotate-90" />
                  </div>
                </div>
              </div>

              {/* Amount Input (Simulated for Deposit Request) */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-gray-400">المبلغ المودع (للتأكيد)</label>
                <input 
                  type="number" 
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full p-2.5 rounded-xl bg-black/40 border border-white/10 text-white font-bold text-sm focus:outline-none focus:border-cyan-500 transition-colors placeholder:text-gray-600"
                />
              </div>

              {/* QR Code & Address */}
              <div className="flex flex-col items-center justify-center p-4 bg-black/20 rounded-xl border border-white/5 border-dashed">
                <div className="w-32 h-32 bg-white p-2 rounded-xl mb-4 shadow-sm">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${address}`}
                    alt="QR Code"
                    className="w-full h-full object-contain"
                  />
                </div>
                
                <div className="w-full relative group">
                  <div className="absolute top-1/2 left-2 -translate-y-1/2">
                    <button 
                      onClick={handleCopy}
                      className="p-1.5 hover:bg-white/10 rounded-lg transition-colors text-gray-400 hover:text-white"
                      title="نسخ العنوان"
                    >
                      {copied ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                    </button>
                  </div>
                  <input 
                    type="text" 
                    readOnly 
                    value={address}
                    className="w-full py-2.5 pl-10 pr-3 bg-black/40 border border-white/10 rounded-lg text-center font-mono text-xs text-cyan-400 focus:outline-none"
                  />
                </div>
                <p className="mt-2 text-[9px] text-gray-500 text-center">
                  أرسل فقط <span className="font-bold text-white">{selectedAsset.symbol}</span> عبر شبكة <span className="font-bold text-white">{selectedNetwork}</span> لهذا العنوان.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-2">
                 <button 
                   onClick={handleConfirm}
                   className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-[0.98] text-sm flex items-center justify-center gap-2"
                 >
                   <Check size={16} />
                   تأكيد الإيداع
                 </button>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};
