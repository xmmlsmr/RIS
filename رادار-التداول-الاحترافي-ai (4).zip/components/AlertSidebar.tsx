
import React from 'react';
import { Alert } from '../types';
import { Bell, ShieldAlert, TrendingUp, BellPlus, X, Edit2 } from 'lucide-react';

interface Props {
  alerts: Alert[];
  onAddAlert: () => void;
  onDismissAlert: (id: string) => void;
  onEditAlert: (alert: Alert) => void;
}

const AlertItem = React.memo(({ alert, onDismiss, onEdit }: { alert: Alert; onDismiss: (id: string) => void; onEdit: (alert: Alert) => void }) => (
  <div className="p-3 rounded-xl bg-[#0a0f18]/60 backdrop-blur-sm border border-white/5 hover:border-cyan-500/30 transition-all cursor-pointer group animate-in slide-in-from-right duration-300 text-right relative shadow-sm hover:shadow-[0_0_15px_rgba(0,243,255,0.1)]">
    <div className="absolute top-2 left-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
      <button 
        onClick={(e) => {
          e.stopPropagation();
          onEdit(alert);
        }}
        className="p-1.5 rounded-lg bg-black/40 text-gray-400 hover:text-cyan-400 hover:bg-cyan-500/10 transition-colors border border-transparent hover:border-cyan-500/20"
        title="تعديل"
      >
        <Edit2 size={12} />
      </button>
      <button 
        onClick={(e) => {
          e.stopPropagation();
          onDismiss(alert.id);
        }}
        className="p-1.5 rounded-lg bg-black/40 text-gray-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors border border-transparent hover:border-rose-500/20"
        title="حذف"
      >
        <X size={12} />
      </button>
    </div>
    <div className="flex justify-between items-start mb-2 pl-12">
      <span className="font-black text-cyan-400 text-sm font-tech tracking-wider">{alert.symbol}</span>
      <span className="text-[10px] text-gray-500 font-mono">{alert.timestamp.toLocaleTimeString('ar-SA')}</span>
    </div>
    <p className="text-xs text-gray-300 line-clamp-2 leading-relaxed font-medium">{alert.message}</p>
    <div className="mt-2 flex items-center justify-end gap-2">
      <span className="text-[9px] uppercase font-black tracking-widest opacity-60 text-gray-500 font-tech">{alert.type}</span>
      {alert.type === 'Price' && <TrendingUp size={12} className="text-emerald-400" />}
      {alert.severity === 'critical' && <ShieldAlert size={12} className="text-rose-400 animate-pulse" />}
    </div>
  </div>
));

export const AlertSidebar: React.FC<Props> = React.memo(({ alerts, onAddAlert, onDismissAlert, onEditAlert }) => {
  return (
    <div className="bg-[#05080c]/80 backdrop-blur-xl border-r border-white/5 w-80 h-full flex flex-col shrink-0 overflow-hidden transition-colors duration-300 shadow-[4px_0_20px_rgba(0,0,0,0.2)] relative z-30">
      <div className="p-4 border-b border-white/5 flex items-center justify-between bg-[#0a0f18]/40 backdrop-blur-md sticky top-0 z-10">
        <button 
          onClick={onAddAlert}
          className="p-2 hover:bg-cyan-500/10 text-cyan-400 rounded-lg transition-all border border-transparent hover:border-cyan-500/20 hover:shadow-[0_0_10px_rgba(0,243,255,0.2)]"
          title="إضافة تنبيه"
        >
          <BellPlus size={18} />
        </button>
        <h2 className="text-sm font-black flex items-center gap-2 text-white font-tech uppercase tracking-wider">
          SMART ALERTS
          <Bell size={16} className="text-amber-400 fill-amber-400/20 animate-pulse-glow" />
        </h2>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {alerts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full opacity-30 text-center text-gray-500">
            <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 border border-white/10">
              <Bell size={32} className="text-gray-400" />
            </div>
            <p className="text-sm font-black font-tech uppercase tracking-wider">NO ACTIVE ALERTS</p>
            <p className="text-[10px] mt-2 max-w-[200px] leading-relaxed">Set price or indicator alerts to track the market automatically.</p>
          </div>
        ) : (
          alerts.map((alert) => <AlertItem key={alert.id} alert={alert} onDismiss={onDismissAlert} onEdit={onEditAlert} />)
        )}
      </div>
    </div>
  );
});
