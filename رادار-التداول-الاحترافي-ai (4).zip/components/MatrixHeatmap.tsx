
import React from 'react';

const COINS = ['BTC', 'ETH', 'SOL', 'BNB', 'XRP', 'ADA', 'DOGE', 'AVAX'];

export const MatrixHeatmap: React.FC = () => {
  return (
    <div className="grid grid-cols-8 gap-1 w-full aspect-square md:aspect-video bg-black/20 p-2 rounded-2xl border border-white/5">
      {COINS.map((coinY, y) => (
        <React.Fragment key={coinY}>
          {COINS.map((coinX, x) => {
            const correlation = x === y ? 1 : (Math.random() * 0.8 + 0.1);
            const intensity = Math.floor(correlation * 100);
            return (
              <div 
                key={`${coinX}-${coinY}`}
                className="relative group flex items-center justify-center rounded-sm transition-all hover:scale-110 hover:z-10 cursor-help"
                style={{ 
                  backgroundColor: `rgba(6, 182, 212, ${correlation * 0.8})`,
                  border: '1px solid rgba(255,255,255,0.05)'
                }}
              >
                <div className="hidden group-hover:flex absolute -top-12 left-1/2 -translate-x-1/2 bg-[#1e2329] border border-cyan-500/30 p-2 rounded shadow-2xl z-50 whitespace-nowrap flex-col items-center">
                   <span className="text-[8px] font-black text-gray-500">{coinY} / {coinX}</span>
                   <span className="text-xs font-mono font-black text-cyan-400">Corr: {correlation.toFixed(2)}</span>
                </div>
                {x === 0 && (
                  <span className="absolute -right-8 text-[8px] font-black text-gray-600 hidden md:block">{coinY}</span>
                )}
                {y === 0 && (
                  <span className="absolute -top-6 text-[8px] font-black text-gray-600 hidden md:block">{coinX}</span>
                )}
              </div>
            );
          })}
        </React.Fragment>
      ))}
    </div>
  );
};
