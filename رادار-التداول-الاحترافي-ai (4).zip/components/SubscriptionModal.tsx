import React from 'react';
import { Crown, Check, X, Zap } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: (planId: string, price: number, duration: number) => void;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onSubscribe }) => {
  const { vipPlans } = useSettings();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="glass-panel w-full max-w-4xl rounded-[2.5rem] p-8 border border-amber-500/20 shadow-[0_0_100px_rgba(245,158,11,0.15)] animate-in zoom-in-95 duration-500 relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Background Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-amber-500/10 via-transparent to-transparent rotate-45 pointer-events-none"></div>

        <button 
          onClick={onClose}
          className="absolute top-6 left-6 p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all text-gray-400 hover:text-white z-20"
        >
          <X size={20} />
        </button>

        <div className="text-center mb-8 relative z-10 shrink-0">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/20 mb-4 shadow-[0_0_40px_rgba(245,158,11,0.2)]">
            <Crown size={32} className="text-amber-400" />
          </div>
          <h2 className="text-3xl font-black text-white mb-2">اختر خطتك</h2>
          <p className="text-gray-400 font-medium">احصل على وصول كامل لأدوات التحليل الفني</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-y-auto custom-scrollbar p-2">
          {vipPlans.map((plan) => (
            <div key={plan.id} className={`bg-black/40 rounded-2xl border ${plan.isPopular ? 'border-amber-500 ring-1 ring-amber-500/50' : 'border-white/10'} p-6 relative overflow-hidden group hover:bg-white/5 transition-all flex flex-col`}>
              {plan.isPopular && (
                <div className="absolute top-0 right-0 bg-amber-500 text-black text-[10px] font-black px-3 py-1 rounded-bl-xl">الأكثر شيوعاً</div>
              )}
              
              <h3 className="text-xl font-black text-white mb-2">{plan.name}</h3>
              
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-3xl font-black text-white">${plan.price}</span>
                <span className="text-gray-500 font-bold text-sm">/ {plan.durationDays} يوم</span>
              </div>

              <ul className="space-y-3 mb-8 flex-1">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm text-gray-300">
                    <div className="w-5 h-5 rounded-full bg-amber-500/10 flex items-center justify-center shrink-0">
                      <Check size={10} className="text-amber-400" />
                    </div>
                    {feature}
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => onSubscribe(plan.id, plan.price, plan.durationDays)}
                className={`w-full py-3 font-black rounded-xl shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center gap-2 ${
                  plan.isPopular 
                    ? 'bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-black shadow-amber-500/20' 
                    : 'bg-white/10 hover:bg-white/20 text-white border border-white/10'
                }`}
              >
                <Zap size={18} fill={plan.isPopular ? "currentColor" : "none"} />
                اشترك الآن
              </button>
            </div>
          ))}
        </div>

        <p className="text-center text-[10px] text-gray-500 mt-6 shrink-0">
          * يمكنك إلغاء الاشتراك في أي وقت. تطبق الشروط والأحكام.
        </p>
      </div>
    </div>
  );
};
