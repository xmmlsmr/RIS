
import React from 'react';
import { CryptoTicker } from '../types';
import { ChevronUp, ChevronDown, Cpu } from 'lucide-react';
import { IndicatorBadge } from './IndicatorBadge';

interface Props {
  ticker: CryptoTicker;
  onAnalyze: (symbol: string) => void;
}

export const TickerRow: React.FC<Props> = React.memo(({ ticker, onAnalyze }) => {
  const priceChange = parseFloat(ticker.priceChangePercent);
  const isPositive = priceChange >= 0;

  return (
    <tr className="hover:bg-gray-800/40 transition-colors group border-b border-[#2b3139]/50 last:border-0">
      <td className="px-6 py-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gray-700/50 flex items-center justify-center text-[10px] font-bold border border-gray-600/30">
            {ticker.symbol.substring(0, 3)}
          </div>
          <span className="font-bold tracking-tight">{ticker.symbol}</span>
        </div>
      </td>
      <td className="px-6 py-4 font-mono text-left font-bold text-gray-100">
        ${parseFloat(ticker.lastPrice).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 })}
      </td>
      <td className="px-6 py-4 text-center">
        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${isPositive ? 'bg-green-500/10 text-green-400' : 'bg-red-500/10 text-red-400'}`}>
          {isPositive ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
          {ticker.priceChangePercent}%
        </span>
      </td>
      <td className="px-6 py-4">
        <div className="flex flex-wrap gap-2">
          <IndicatorBadge label="RSI" value={Math.floor(Math.random() * 40 + 30)} status={Math.random() > 0.5 ? 'bullish' : 'neutral'} />
          <IndicatorBadge label="MACD" value="Cross" status="bullish" />
        </div>
      </td>
      <td className="px-6 py-4 text-center">
        <button 
          onClick={() => onAnalyze(ticker.symbol)}
          className="bg-blue-600/10 text-blue-400 border border-blue-500/20 px-4 py-2 rounded-lg text-xs font-bold hover:bg-blue-600 hover:text-white transition-all transform active:scale-95 flex items-center gap-2 mx-auto"
        >
          <Cpu size={14} />
          تحليل
        </button>
      </td>
    </tr>
  );
});
