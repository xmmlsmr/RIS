
import React from 'react';

interface Props {
  label: string;
  value: string | number;
  status?: 'bullish' | 'bearish' | 'neutral';
}

export const IndicatorBadge: React.FC<Props> = ({ label, value, status = 'neutral' }) => {
  const bgColor = status === 'bullish' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                 status === 'bearish' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 
                 'bg-white/5 text-gray-400 border-white/5';

  return (
    <div className={`px-4 py-1.5 rounded-xl text-[10px] font-black tracking-widest flex items-center gap-3 border transition-all hover:scale-105 ${bgColor}`}>
      <span className="opacity-40 uppercase">{label}</span>
      <span className="font-mono font-black">{value}</span>
    </div>
  );
};
