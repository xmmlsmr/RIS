import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, CartesianGrid } from 'recharts';
import { AreaChart as AreaChartIcon, Activity } from 'lucide-react';
import { IndicatorHistory } from '../types';

interface IndicatorChartProps {
  history: IndicatorHistory;
  color?: string;
  type?: 'line' | 'area';
  height?: number | string;
}

export const IndicatorChart: React.FC<IndicatorChartProps> = ({ history, color = '#06b6d4', type = 'area', height = '100%' }) => {
  const [chartType, setChartType] = useState<'line' | 'area'>(type);

  const data = history.values.map((val, idx) => ({
    index: idx,
    value: val,
  }));

  const minValue = Math.min(...history.values);
  const maxValue = Math.max(...history.values);
  const padding = (maxValue - minValue) * 0.1;

  return (
    <div className="w-full h-full flex flex-col bg-black/20 rounded-2xl border border-white/5 p-4 min-h-[180px]">
      <div className="flex justify-between items-center mb-4 flex-none">
        <div className="flex items-center gap-3">
          <h4 className="text-sm font-black text-gray-300">{history.name}</h4>
          <div className="flex bg-white/5 rounded-lg p-0.5 border border-white/5">
            <button
              onClick={() => setChartType('area')}
              className={`p-1 rounded-md transition-all ${chartType === 'area' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
              title="Area Chart"
            >
              <AreaChartIcon size={12} />
            </button>
            <button
              onClick={() => setChartType('line')}
              className={`p-1 rounded-md transition-all ${chartType === 'line' ? 'bg-cyan-500/20 text-cyan-400' : 'text-gray-500 hover:text-gray-300'}`}
              title="Line Chart"
            >
              <Activity size={12} />
            </button>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {history.winRate !== undefined && (
            <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20" title="Historical Win Rate">
              WR: {history.winRate}%
            </span>
          )}
          {history.accuracy !== undefined && (
            <span className="text-[9px] font-bold text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20" title="Signal Accuracy">
              ACC: {history.accuracy}%
            </span>
          )}
          <span className="text-xs font-mono text-cyan-400">{history.values[history.values.length - 1].toFixed(2)}</span>
        </div>
      </div>
      <div className="flex-1 min-h-0 w-full">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'area' ? (
            <AreaChart data={data}>
              <defs>
                <linearGradient id={`gradient-${history.name}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={color} stopOpacity={0.3}/>
                  <stop offset="95%" stopColor={color} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="index" hide />
              <YAxis 
                hide 
                domain={[minValue - padding, maxValue + padding]} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e2329', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                labelStyle={{ display: 'none' }}
                formatter={(value: number) => [value.toFixed(2), history.name]}
              />
              <Area 
                type="monotone" 
                dataKey="value" 
                stroke={color} 
                fillOpacity={1} 
                fill={`url(#gradient-${history.name})`} 
                strokeWidth={2}
              />
            </AreaChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
              <XAxis dataKey="index" hide />
              <YAxis 
                hide 
                domain={[minValue - padding, maxValue + padding]} 
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#1e2329', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                labelStyle={{ display: 'none' }}
                formatter={(value: number) => [value.toFixed(2), history.name]}
              />
              <Line 
                type="monotone" 
                dataKey="value" 
                stroke={color} 
                strokeWidth={2} 
                dot={false}
                activeDot={{ r: 4, fill: '#fff' }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
};
