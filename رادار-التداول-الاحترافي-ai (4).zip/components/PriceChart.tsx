
import React, { useMemo, useState } from 'react';
import { KlineData } from '../types';

interface Props {
  data: KlineData[];
  height?: number;
}

export const PriceChart: React.FC<Props> = ({ data, height = 240 }) => {
  const [hoveredData, setHoveredData] = useState<KlineData | null>(null);
  const [mouseX, setMouseX] = useState<number | null>(null);

  const chartProps = useMemo(() => {
    if (data.length === 0) return null;

    const margin = { top: 20, right: 60, bottom: 20, left: 10 };
    const width = 800;
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const minPrice = Math.min(...data.map(d => d.low));
    const maxPrice = Math.max(...data.map(d => d.high));
    const priceRange = maxPrice - minPrice;
    const padding = priceRange * 0.1;

    const scaleY = (price: number) => 
      innerHeight - ((price - (minPrice - padding)) / (priceRange + padding * 2)) * innerHeight + margin.top;

    const scaleX = (index: number) => 
      (index / (data.length - 1)) * innerWidth + margin.left;

    const candleWidth = (innerWidth / data.length) * 0.8;
    const hitAreaWidth = innerWidth / data.length;

    return { margin, width, height, innerWidth, innerHeight, minPrice, maxPrice, scaleY, scaleX, candleWidth, hitAreaWidth };
  }, [data, height]);

  if (!chartProps || data.length === 0) return null;

  const { scaleY, scaleX, candleWidth, hitAreaWidth, width, maxPrice, minPrice, margin } = chartProps;

  return (
    <div className="w-full bg-[#1e2329]/50 rounded-2xl border border-[#2b3139] p-4 relative overflow-hidden group/chart">
      <div className="flex justify-between items-center mb-4 px-2">
        <div className="flex flex-col gap-1">
          <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">مخطط السعر (7 أيام / ساعة)</span>
          {hoveredData && (
            <div className="flex gap-3 text-[10px] font-mono text-blue-400 animate-in fade-in slide-in-from-left-2 duration-200">
              <span>O: <span className="text-gray-200">{hoveredData.open.toFixed(2)}</span></span>
              <span>H: <span className="text-gray-200">{hoveredData.high.toFixed(2)}</span></span>
              <span>L: <span className="text-gray-200">{hoveredData.low.toFixed(2)}</span></span>
              <span>C: <span className="text-gray-200">{hoveredData.close.toFixed(2)}</span></span>
              <span>V: <span className="text-gray-200">{hoveredData.volume.toFixed(2)}</span></span>
            </div>
          )}
        </div>
        <div className="flex gap-4 text-[10px] font-mono">
          <span className="text-green-500">أعلى: ${maxPrice.toLocaleString()}</span>
          <span className="text-red-500">أدنى: ${minPrice.toLocaleString()}</span>
        </div>
      </div>
      
      <div className="relative">
        <svg 
          viewBox={`0 0 ${width} ${height}`} 
          className="w-full h-auto overflow-visible cursor-crosshair"
          onMouseLeave={() => {
            setHoveredData(null);
            setMouseX(null);
          }}
        >
          {/* Horizontal Grid Lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((p, i) => {
            const y = margin.top + (chartProps.innerHeight * p);
            const price = maxPrice - (p * (maxPrice - minPrice));
            return (
              <g key={i}>
                <line 
                  x1={margin.left} y1={y} x2={width - margin.right} y2={y} 
                  stroke="#2b3139" strokeWidth="1" strokeDasharray="4 4" 
                />
                <text 
                  x={width - margin.right + 5} y={y + 4} 
                  fill="#474d57" fontSize="10" fontFamily="monospace"
                >
                  {price.toLocaleString(undefined, { maximumFractionDigits: 2 })}
                </text>
              </g>
            );
          })}

          {/* Vertical Indicator Line */}
          {mouseX !== null && (
            <line 
              x1={mouseX} y1={margin.top} x2={mouseX} y2={height - margin.bottom} 
              stroke="#3b82f6" strokeWidth="1" strokeDasharray="2 2"
              className="pointer-events-none"
            />
          )}

          {/* Candlesticks */}
          {data.map((d, i) => {
            const x = scaleX(i);
            const isBullish = d.close >= d.open;
            const color = isBullish ? '#22c55e' : '#ef4444';
            const top = scaleY(Math.max(d.open, d.close));
            const bottom = scaleY(Math.min(d.open, d.close));
            const high = scaleY(d.high);
            const low = scaleY(d.low);

            return (
              <g key={i} className="pointer-events-none">
                {/* Wick */}
                <line x1={x} y1={high} x2={x} y2={low} stroke={color} strokeWidth="1" />
                {/* Body */}
                <rect 
                  x={x - candleWidth / 2} 
                  y={top} 
                  width={candleWidth} 
                  height={Math.max(1, bottom - top)} 
                  fill={color} 
                  rx="1"
                />
              </g>
            );
          })}

          {/* Hit Areas for Tooltip */}
          {data.map((d, i) => {
            const x = scaleX(i);
            return (
              <rect
                key={`hit-${i}`}
                x={x - hitAreaWidth / 2}
                y={margin.top}
                width={hitAreaWidth}
                height={height - margin.top - margin.bottom}
                fill="transparent"
                onMouseEnter={() => {
                  setHoveredData(d);
                  setMouseX(x);
                }}
                onMouseMove={() => {
                  setHoveredData(d);
                  setMouseX(x);
                }}
              />
            );
          })}
        </svg>

        {/* Floating Tooltip Box */}
        {hoveredData && mouseX !== null && (
          <div 
            className="absolute z-50 pointer-events-none bg-[#1e2329] border border-blue-500/30 p-2 rounded-lg shadow-xl text-[10px] font-mono text-gray-300 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200"
            style={{ 
              left: mouseX > width / 2 ? mouseX - 130 : mouseX + 20, 
              top: 20 
            }}
          >
            <div className="flex flex-col gap-1">
              <div className="border-b border-gray-700 pb-1 mb-1 font-bold text-blue-400">
                {new Date(hoveredData.time).toLocaleString('ar-SA', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
              </div>
              <div className="flex justify-between gap-4"><span>O:</span> <span className="text-white">{hoveredData.open.toFixed(2)}</span></div>
              <div className="flex justify-between gap-4"><span>H:</span> <span className="text-green-400">{hoveredData.high.toFixed(2)}</span></div>
              <div className="flex justify-between gap-4"><span>L:</span> <span className="text-red-400">{hoveredData.low.toFixed(2)}</span></div>
              <div className="flex justify-between gap-4"><span>C:</span> <span className="text-white">{hoveredData.close.toFixed(2)}</span></div>
              <div className="flex justify-between gap-4"><span>V:</span> <span className="text-gray-400">{hoveredData.volume.toFixed(2)}</span></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
