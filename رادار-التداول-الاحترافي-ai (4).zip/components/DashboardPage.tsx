import React, { useMemo } from 'react';
import { 
  Activity, TrendingUp, Zap, Bot, ArrowUpRight, ArrowDownRight, 
  BrainCircuit, LayoutGrid, Wallet, Bell, ChevronRight, BarChart3,
  Gauge, PieChart, Globe, Cpu, Radio, Flame, Layers, Users, Crown, Lock
} from 'lucide-react';
import { CryptoTicker } from '../types';

interface DashboardPageProps {
  user: any;
  tickers: CryptoTicker[];
  onNavigate: (tab: any) => void;
  onAnalyze: (symbol: string) => void;
  onShowWallet: () => void;
  onShowReferral: () => void;
  isVip: boolean;
  onShowSubscription: () => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ user, tickers, onNavigate, onAnalyze, onShowWallet, onShowReferral, isVip, onShowSubscription }) => {
  
  // Calculate Market Overview
  const marketStats = useMemo(() => {
    if (!tickers.length) return { sentiment: 'Neutral', up: 0, down: 0, vol: 0, dominance: 45, fearGreed: 65 };
    
    const up = tickers.filter(t => parseFloat(t.priceChangePercent) > 0).length;
    const down = tickers.length - up;
    const sentiment = up > down ? 'Bullish' : 'Bearish';
    const totalVol = tickers.reduce((acc, t) => acc + parseFloat(t.quoteVolume), 0);
    
    return { 
      sentiment, 
      up, 
      down, 
      vol: totalVol,
      dominance: 52.4, // Mocked
      fearGreed: up > down ? 72 : 34 // Dynamic based on market breadth
    };
  }, [tickers]);

  // Top Gainers
  const topGainers = useMemo(() => {
    return [...tickers]
      .sort((a, b) => parseFloat(b.priceChangePercent) - parseFloat(a.priceChangePercent))
      .slice(0, 4);
  }, [tickers]);

  // AI Insights (Mock)
  const aiInsights = [
    { id: 1, type: 'anomaly', msg: 'Unusual volume spike detected in SOL/USDT', time: '2m ago' },
    { id: 2, type: 'pattern', msg: 'Double Bottom formation on ETH 4h chart', time: '15m ago' },
    { id: 3, type: 'sentiment', msg: 'Social sentiment flipping bullish for AI tokens', time: '1h ago' },
  ];

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20" dir="rtl">
      
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 bg-gradient-to-r from-indigo-900/20 to-transparent p-6 rounded-[2rem] border border-white/5 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[80px] rounded-full pointer-events-none -mr-20 -mt-20"></div>
        <div className="relative z-10">
          <h2 className="text-4xl font-black text-white tracking-tighter mb-2 flex items-center gap-3">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">مرحباً،</span>
            <span className="text-cyan-400 glow-text-cyan">{user?.name || 'Commander'}</span> 
            {isVip && (
              <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-[10px] font-black border border-amber-500/30 flex items-center gap-1">
                <Crown size={10} fill="currentColor" />
                VIP
              </span>
            )}
            <span className="text-2xl">👋</span>
          </h2>
          <p className="text-gray-400 text-sm font-bold max-w-lg leading-relaxed">
            نظام الرادار نشط. جاري مسح {tickers.length} أصل رقمي في الوقت الفعلي.
          </p>
        </div>
        <div className="flex gap-3 relative z-10">
          <button 
            onClick={onShowWallet}
            className="px-5 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-black text-white flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          >
            <Wallet size={18} className="text-cyan-400" />
            المحفظة
          </button>
          <button 
            onClick={() => onNavigate('ai')}
            className="px-5 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white rounded-2xl text-xs font-black shadow-lg shadow-cyan-500/20 flex items-center gap-2 transition-all hover:scale-105 active:scale-95"
          >
            <BrainCircuit size={18} />
            تحليل جديد
          </button>
        </div>
      </div>

      {/* AI Live Ticker */}
      <div className="glass-panel p-1 rounded-2xl border border-cyan-500/20 overflow-hidden flex items-center relative">
        <div className="bg-cyan-500/10 px-4 py-2 flex items-center gap-2 z-10 border-l border-white/5">
          <Radio size={14} className="text-cyan-400 animate-pulse" />
          <span className="text-[10px] font-black text-cyan-400 uppercase tracking-widest whitespace-nowrap">AI LIVE FEED</span>
        </div>
        <div className="flex-1 overflow-hidden relative h-8">
          <div className="absolute top-0 right-0 whitespace-nowrap animate-marquee flex items-center h-full gap-8 px-4">
            {aiInsights.map((insight, i) => (
              <div key={i} className="flex items-center gap-2 text-xs font-bold text-gray-300">
                <span className={`w-1.5 h-1.5 rounded-full ${insight.type === 'anomaly' ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                <span className="text-white">{insight.msg}</span>
                <span className="text-[9px] text-gray-500 font-mono opacity-60">[{insight.time}]</span>
              </div>
            ))}
             {/* Duplicate for seamless loop */}
             {aiInsights.map((insight, i) => (
              <div key={`dup-${i}`} className="flex items-center gap-2 text-xs font-bold text-gray-300">
                <span className={`w-1.5 h-1.5 rounded-full ${insight.type === 'anomaly' ? 'bg-rose-500' : 'bg-emerald-500'}`}></span>
                <span className="text-white">{insight.msg}</span>
                <span className="text-[9px] text-gray-500 font-mono opacity-60">[{insight.time}]</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Market Pulse Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Market Sentiment */}
        <div className="glass-panel p-5 rounded-[2rem] border border-white/5 relative overflow-hidden group hover:border-emerald-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mb-1">Market Sentiment</p>
              <h3 className={`text-xl font-black ${marketStats.sentiment === 'Bullish' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {marketStats.sentiment}
              </h3>
            </div>
            <div className={`p-2.5 rounded-xl ${marketStats.sentiment === 'Bullish' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
              <Gauge size={20} />
            </div>
          </div>
          <div className="w-full bg-white/5 rounded-full h-1.5 mb-2 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-1000 ${marketStats.sentiment === 'Bullish' ? 'bg-emerald-500' : 'bg-rose-500'}`} 
              style={{ width: `${marketStats.fearGreed}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-[9px] font-bold text-gray-500 uppercase">
            <span>Fear</span>
            <span className="text-white">{marketStats.fearGreed}/100</span>
            <span>Greed</span>
          </div>
        </div>

        {/* BTC Dominance */}
        <div className="glass-panel p-5 rounded-[2rem] border border-white/5 relative overflow-hidden group hover:border-amber-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mb-1">BTC Dominance</p>
              <h3 className="text-xl font-black text-amber-400">{marketStats.dominance}%</h3>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400">
              <PieChart size={20} />
            </div>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <span className="text-amber-400 flex items-center gap-1"><TrendingUp size={12}/> +0.4%</span>
            <span>vs Altcoins</span>
          </div>
        </div>

        {/* 24h Volume */}
        <div className="glass-panel p-5 rounded-[2rem] border border-white/5 relative overflow-hidden group hover:border-blue-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mb-1">24h Volume</p>
              <h3 className="text-xl font-black text-blue-400">${(marketStats.vol / 1000000000).toFixed(2)}B</h3>
            </div>
            <div className="p-2.5 rounded-xl bg-blue-500/10 text-blue-400">
              <BarChart3 size={20} />
            </div>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <span className="text-emerald-400 flex items-center gap-1"><ArrowUpRight size={12}/> +12.5%</span>
            <span>Since yesterday</span>
          </div>
        </div>

        {/* AI Confidence */}
        <div className="glass-panel p-5 rounded-[2rem] border border-white/5 relative overflow-hidden group hover:border-purple-500/30 transition-all">
          <div className="flex justify-between items-start mb-4">
            <div>
              <p className="text-gray-500 text-[9px] font-black uppercase tracking-widest mb-1">AI Confidence</p>
              <h3 className="text-xl font-black text-purple-400">88%</h3>
            </div>
            <div className="p-2.5 rounded-xl bg-purple-500/10 text-purple-400">
              <BrainCircuit size={20} />
            </div>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-gray-400">
            <span className="text-purple-400">High Accuracy</span>
            <span>on recent signals</span>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Top Gainers List (Span 2) */}
        <div className="lg:col-span-2 glass-panel p-6 rounded-[2rem] border border-white/5">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-black text-white flex items-center gap-2">
              <TrendingUp size={20} className="text-emerald-400" />
              الأعلى ارتفاعاً (24h)
            </h3>
            <button onClick={() => onNavigate('screener')} className="text-xs text-cyan-400 font-bold hover:underline">عرض الكل</button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {topGainers.map(t => (
              <div 
                key={t.symbol} 
                onClick={() => onAnalyze(t.symbol)}
                className="p-4 rounded-2xl bg-white/5 hover:bg-white/10 cursor-pointer transition-all group border border-white/5 hover:border-emerald-500/30 relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:opacity-20 transition-opacity">
                  <TrendingUp size={40} className="text-emerald-500" />
                </div>
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-900/20 flex items-center justify-center text-emerald-400 font-black text-xs border border-emerald-500/20 shadow-inner">
                      {t.symbol.substring(0, 3)}
                    </div>
                    <div>
                      <h4 className="font-black text-white text-sm group-hover:text-emerald-400 transition-colors">{t.symbol}</h4>
                      <span className="text-[10px] text-gray-500 font-mono">${parseFloat(t.lastPrice).toLocaleString()}</span>
                    </div>
                  </div>
                  <span className="px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-400 text-xs font-black border border-emerald-500/20">
                    +{t.priceChangePercent}%
                  </span>
                </div>
                
                {/* Mini Sparkline Visualization (CSS based) */}
                <div className="h-10 flex items-end gap-1 mt-2 opacity-50 group-hover:opacity-100 transition-opacity">
                   {[...Array(10)].map((_, i) => (
                      <div 
                        key={i} 
                        className="flex-1 bg-emerald-500 rounded-t-sm" 
                        style={{ height: `${20 + Math.random() * 80}%`, opacity: 0.3 + (i/20) }}
                      ></div>
                   ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions / Shortcuts (Span 1) */}
        <div className="glass-panel p-6 rounded-[2rem] border border-white/5 flex flex-col">
          <h3 className="text-lg font-black text-white flex items-center gap-2 mb-6">
            <LayoutGrid size={20} className="text-indigo-400" />
            مركز التحكم
          </h3>
          <div className="flex-1 grid grid-cols-1 gap-3">
            <button 
              onClick={() => isVip ? onNavigate('strategies') : onShowSubscription()}
              className={`p-4 rounded-2xl bg-white/5 border border-white/5 transition-all text-right group flex items-center gap-4 ${
                isVip 
                  ? 'hover:border-cyan-500/30 hover:bg-cyan-500/5 cursor-pointer' 
                  : 'opacity-70 hover:opacity-100 cursor-not-allowed'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-transform border ${
                isVip 
                  ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20 group-hover:scale-110' 
                  : 'bg-gray-800 text-gray-500 border-gray-700'
              }`}>
                {isVip ? <BrainCircuit size={24} /> : <Lock size={20} />}
              </div>
              <div>
                <h4 className="font-black text-white text-sm mb-0.5 group-hover:text-cyan-400 transition-colors flex items-center gap-2">
                  استراتيجيات التداول
                  {!isVip && <span className="text-[9px] px-1.5 py-0.5 bg-amber-500/20 text-amber-400 rounded border border-amber-500/30">VIP</span>}
                </h4>
                <p className="text-[10px] text-gray-500">تخصيص خوارزميات التحليل</p>
              </div>
            </button>

            <button 
              onClick={() => isVip ? onNavigate('matrix') : onShowSubscription()}
              className={`p-4 rounded-2xl bg-white/5 border border-white/5 transition-all text-right group flex items-center gap-4 ${
                isVip 
                  ? 'hover:border-purple-500/30 hover:bg-purple-500/5 cursor-pointer' 
                  : 'opacity-70 hover:opacity-100 cursor-not-allowed'
              }`}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-transform border ${
                isVip 
                  ? 'bg-purple-500/10 text-purple-400 border-purple-500/20 group-hover:scale-110' 
                  : 'bg-gray-800 text-gray-500 border-gray-700'
              }`}>
                {isVip ? <BarChart3 size={24} /> : <Lock size={20} />}
              </div>
              <div>
                <h4 className="font-black text-white text-sm mb-0.5 group-hover:text-purple-400 transition-colors flex items-center gap-2">
                  المصفوفة (Matrix)
                  {!isVip && <span className="text-[9px] px-1.5 py-0.5 bg-amber-500/20 text-amber-400 rounded border border-amber-500/30">VIP</span>}
                </h4>
                <p className="text-[10px] text-gray-500">تحليل السيولة والارتباط</p>
              </div>
            </button>

            <button 
              onClick={() => onNavigate('bots')}
              className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition-all text-right group flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform border border-emerald-500/20">
                <Bot size={24} />
              </div>
              <div>
                <h4 className="font-black text-white text-sm mb-0.5 group-hover:text-emerald-400 transition-colors">بوتات التداول</h4>
                <p className="text-[10px] text-gray-500">إدارة التداول الآلي</p>
              </div>
            </button>

            <button 
              onClick={onShowReferral}
              className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-amber-500/30 hover:bg-amber-500/5 transition-all text-right group flex items-center gap-4"
            >
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform border border-amber-500/20">
                <Users size={24} />
              </div>
              <div>
                <h4 className="font-black text-white text-sm mb-0.5 group-hover:text-amber-400 transition-colors">نظام الإحالة</h4>
                <p className="text-[10px] text-gray-500">اربح عمولات ومكافآت</p>
              </div>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
