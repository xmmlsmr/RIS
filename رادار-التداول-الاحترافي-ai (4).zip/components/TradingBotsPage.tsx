import React, { useState, useEffect } from 'react';
import { Bot, Play, Pause, Settings, Activity, TrendingUp, Zap, BarChart2, AlertTriangle, Check, X, ArrowUpRight, ArrowDownRight, Key, ShieldCheck, Loader2 } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { CreateBotModal } from './CreateBotModal';
import { TradingBot } from '../types';

const MOCK_BOTS: TradingBot[] = [
  {
    id: '1',
    name: 'Alpha Grid Master',
    description: 'بوت تداول شبكي يستغل تذبذب السوق العرضي لتحقيق أرباح صغيرة ومتكررة.',
    strategy: 'Grid Trading',
    market: 'Spot',
    exchange: 'Binance',
    status: 'inactive',
    performance: {
      roi: 12.5,
      winRate: 92,
      totalTrades: 1450,
      profit: 345.20,
      history: Array.from({ length: 30 }, (_, i) => ({
        date: `Day ${i + 1}`,
        roi: 5 + Math.random() * 10,
        winRate: 85 + Math.random() * 10
      }))
    },
    config: {
      pair: 'BTC/USDT',
      amount: 1000
    },
    advancedConfig: {
      gridSize: 10,
      stopLoss: 5,
      takeProfit: 10,
      marketType: 'Specific',
      investmentAmount: 1000
    }
  },
  {
    id: '2',
    name: 'Futures Momentum Hunter',
    description: 'بوت يتبع الاتجاهات القوية في سوق العقود الآجلة مع إدارة مخاطر صارمة.',
    strategy: 'Trend Following',
    market: 'Futures',
    exchange: 'Binance',
    status: 'inactive',
    performance: {
      roi: 45.8,
      winRate: 65,
      totalTrades: 320,
      profit: 1250.50,
      history: Array.from({ length: 30 }, (_, i) => ({
        date: `Day ${i + 1}`,
        roi: 20 + Math.random() * 40,
        winRate: 50 + Math.random() * 30
      }))
    },
    config: {
      pair: 'ETH/USDT',
      leverage: 10,
      amount: 500
    },
    advancedConfig: {
      stopLoss: 10,
      takeProfit: 30,
      marketType: 'Specific',
      investmentAmount: 500
    }
  },
  {
    id: '3',
    name: 'DCA Accumulator',
    description: 'بوت الشراء بمتوسط التكلفة لتجميع العملات القوية على المدى الطويل.',
    strategy: 'DCA',
    market: 'Spot',
    exchange: 'Binance',
    status: 'inactive',
    performance: {
      roi: 8.2,
      winRate: 100,
      totalTrades: 50,
      profit: 120.00,
      history: Array.from({ length: 30 }, (_, i) => ({
        date: `Day ${i + 1}`,
        roi: 2 + Math.random() * 8,
        winRate: 95 + Math.random() * 5
      }))
    },
    config: {
      pair: 'SOL/USDT',
      amount: 200
    },
    advancedConfig: {
      marketType: 'Specific',
      investmentAmount: 200,
      dcaStep: 2.5,
      takeProfit: 15,
      stopLoss: 20
    }
  },
  {
    id: '4',
    name: 'Scalping Sniper AI',
    description: 'بوت مضاربة لحظية يعتمد على الذكاء الاصطناعي لاقتناص الفرص السريعة.',
    strategy: 'AI Scalping',
    market: 'Futures',
    exchange: 'Binance',
    status: 'inactive',
    performance: {
      roi: 18.4,
      winRate: 78,
      totalTrades: 890,
      profit: 450.80,
      history: Array.from({ length: 30 }, (_, i) => ({
        date: `Day ${i + 1}`,
        roi: 10 + Math.random() * 15,
        winRate: 70 + Math.random() * 15
      }))
    },
    config: {
      pair: 'BNB/USDT',
      leverage: 20,
      amount: 300
    },
    advancedConfig: {
      stopLoss: 2,
      takeProfit: 4,
      marketType: 'Specific',
      investmentAmount: 300
    }
  }
];

interface TradingBotsPageProps {
  isVip: boolean;
  freeUsageCount: number;
  onConsumeFreeUsage: () => void;
  onShowSubscription: () => void;
}

export const TradingBotsPage: React.FC<TradingBotsPageProps> = ({ isVip, freeUsageCount, onConsumeFreeUsage, onShowSubscription }) => {
  const [bots, setBots] = useState<TradingBot[]>(MOCK_BOTS);
  const [selectedBot, setSelectedBot] = useState<TradingBot | null>(null);
  const [showApiModal, setShowApiModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [apiKey, setApiKey] = useState('');
  const [apiSecret, setApiSecret] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [expandedBotId, setExpandedBotId] = useState<string | null>(null);

  useEffect(() => {
    const savedKey = localStorage.getItem('binanceApiKey');
    const savedSecret = localStorage.getItem('binanceApiSecret');
    if (savedKey && savedSecret) {
      setApiKey(savedKey);
      setApiSecret(savedSecret);
      setIsConnected(true);
    }
  }, []);

  const handleConnect = async () => {
    if (!apiKey || !apiSecret) {
      alert('يرجى إدخال مفاتيح API');
      return;
    }

    setIsConnecting(true);
    
    // Simulate connection verification
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Basic validation simulation
      if (apiKey.length < 10 || apiSecret.length < 10) {
        throw new Error('مفاتيح API غير صالحة');
      }

      localStorage.setItem('binanceApiKey', apiKey);
      localStorage.setItem('binanceApiSecret', apiSecret);
      setIsConnected(true);
      setIsConnecting(false);
      setShowApiModal(false);
    } catch (error) {
      alert('فشل الاتصال بالمنصة. يرجى التحقق من مفاتيح API والمحاولة مرة أخرى.');
      setIsConnecting(false);
    }
  };

  const handleDisconnect = () => {
    localStorage.removeItem('binanceApiKey');
    localStorage.removeItem('binanceApiSecret');
    setApiKey('');
    setApiSecret('');
    setIsConnected(false);
    // Stop all bots
    setBots(prev => prev.map(bot => ({ ...bot, status: 'inactive' })));
  };

  const handleCreateBot = (botData: any) => {
    const newBot: TradingBot = {
      id: Date.now().toString(),
      name: botData.name || 'New Bot',
      description: botData.strategy === 'Grid Trading' ? 'بوت تداول شبكي مخصص' : botData.strategy === 'DCA Accumulator' ? 'بوت DCA مخصص' : 'بوت مضاربة AI',
      strategy: botData.strategy,
      market: botData.market,
      exchange: 'Binance',
      status: 'inactive',
      performance: {
        roi: 0,
        winRate: 0,
        totalTrades: 0,
        profit: 0,
        history: []
      },
      config: {
        pair: botData.pair,
        amount: botData.amount,
        leverage: botData.leverage
      },
      advancedConfig: {
        gridSize: botData.gridSize,
        stopLoss: botData.stopLoss,
        takeProfit: botData.takeProfit,
        dcaStep: botData.dcaStep,
        marketType: 'Specific',
        investmentAmount: botData.amount
      }
    };
    setBots(prev => [...prev, newBot]);
  };

  const toggleBotStatus = (id: string) => {
    if (!isConnected) {
      setShowApiModal(true);
      return;
    }

    const bot = bots.find(b => b.id === id);
    if (bot && bot.status !== 'active') {
      // Validate bot settings before activating
      if (!bot.config.amount || bot.config.amount <= 0) {
        alert('يرجى تحديد مبلغ استثمار صالح');
        setExpandedBotId(id);
        return;
      }
      if (bot.market === 'Futures' && (!bot.config.leverage || bot.config.leverage > 20)) {
        alert('الرافعة المالية يجب أن تكون بين 1x و 20x');
        setExpandedBotId(id);
        return;
      }
    }

    // Check VIP/Free usage
    if (!isVip) {
      if (freeUsageCount >= 1) {
        onShowSubscription();
        return;
      }
      // Consume free usage
      onConsumeFreeUsage();
    }

    setBots(prev => prev.map(bot => {
      if (bot.id === id) {
        const newStatus = bot.status === 'active' ? 'inactive' : 'active';
        return { ...bot, status: newStatus };
      }
      return bot;
    }));
  };

  const toggleSettings = (id: string) => {
    if (!isConnected) {
      setShowApiModal(true);
      return;
    }
    setExpandedBotId(expandedBotId === id ? null : id);
  };

  const updateBotConfig = (id: string, field: string, value: any) => {
    setBots(prev => prev.map(bot => {
      if (bot.id === id) {
        return {
          ...bot,
          advancedConfig: {
            ...bot.advancedConfig,
            [field]: value,
            marketType: bot.advancedConfig?.marketType || 'Specific',
            investmentAmount: bot.advancedConfig?.investmentAmount || 0
          }
        };
      }
      return bot;
    }));
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-20" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-br from-indigo-900/40 to-black p-8 rounded-[2rem] border border-indigo-500/20 shadow-xl relative overflow-hidden group text-right flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="relative z-10">
          <Bot size={48} className="text-indigo-400 mb-4 opacity-20 absolute left-8 top-8" />
          <h2 className="text-3xl font-black text-white mb-2 tracking-tighter">بوتات التداول الآلي</h2>
          <p className="text-gray-400 font-bold text-base max-w-3xl leading-relaxed">
            قم بإدارة وتشغيل بوتات التداول الذكية الخاصة بك. اختر الاستراتيجية المناسبة ودع البوت يعمل نيابة عنك على مدار الساعة.
          </p>
        </div>
        
        <div className="relative z-10">
          {isConnected ? (
            <div className="flex items-center gap-3">
              {!isVip && (
                <div className="bg-white/10 px-3 py-1.5 rounded-lg border border-white/10 flex items-center gap-2">
                  <span className="text-[10px] text-gray-400 font-bold uppercase">Free Trial</span>
                  <span className={`text-xs font-black ${freeUsageCount >= 1 ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {1 - freeUsageCount}/1 Left
                  </span>
                </div>
              )}
              <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                <span className="text-emerald-400 font-black text-xs">Binance Connected</span>
                <button 
                  onClick={handleDisconnect}
                  className="mr-2 p-1 hover:bg-white/10 rounded-lg transition-colors text-gray-400 hover:text-white"
                  title="Disconnect"
                >
                  <X size={14} />
                </button>
              </div>
            </div>
          ) : (
            <button 
              onClick={() => setShowApiModal(true)}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl shadow-lg shadow-indigo-500/20 transition-all flex items-center gap-2 text-sm"
            >
              <Key size={16} />
              ربط منصة Binance
            </button>
          )}
        </div>
      </div>

      {/* Bots Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-6">
        {bots.map(bot => (
          <div key={bot.id} className={`glass-panel p-6 rounded-[2rem] border transition-all flex flex-col justify-between shadow-xl group relative overflow-hidden ${
            bot.status === 'active' ? 'border-emerald-500/30 shadow-emerald-500/10' : 'border-white/5 hover:border-indigo-500/30'
          }`}>
            {/* Status Indicator */}
            <div className={`absolute top-0 left-0 w-1 h-full transition-colors ${
              bot.status === 'active' ? 'bg-emerald-500' : 
              bot.status === 'paused' ? 'bg-amber-500' : 'bg-gray-800'
            }`}></div>

            <div className="space-y-6 relative z-10">
              <div className="flex justify-between items-start pl-4">
                <div className="flex items-center gap-4">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border shadow-lg ${
                    bot.market === 'Futures' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                  }`}>
                    {bot.market === 'Futures' ? <TrendingUp size={28} /> : <Activity size={28} />}
                  </div>
                  <div>
                    <h3 className="text-xl font-black text-white tracking-tight">{bot.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded-md border ${
                        bot.market === 'Futures' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                      }`}>
                        {bot.market}
                      </span>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-white/5 text-gray-400 border border-white/10">
                        {bot.strategy}
                      </span>
                      <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        {bot.exchange}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase flex items-center gap-1.5 border ${
                  bot.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 
                  bot.status === 'paused' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 
                  'bg-gray-800/50 text-gray-500 border-gray-700/50'
                }`}>
                  <div className={`w-1.5 h-1.5 rounded-full ${
                    bot.status === 'active' ? 'bg-emerald-500 animate-pulse' : 
                    bot.status === 'paused' ? 'bg-amber-500' : 'bg-gray-500'
                  }`}></div>
                  {bot.status === 'active' ? 'نشط' : bot.status === 'paused' ? 'مؤقت' : 'متوقف'}
                </div>
              </div>

              <p className="text-gray-400 text-sm font-medium leading-relaxed pr-2">
                {bot.description}
              </p>

              {/* Performance Metrics */}
              <div className="grid grid-cols-4 gap-2 bg-black/40 p-4 rounded-2xl border border-white/5">
                <div className="text-center">
                  <span className="text-[9px] text-gray-500 font-black uppercase block mb-1">ROI</span>
                  <div className="flex items-center justify-center gap-1">
                    {bot.performance.roi >= 0 ? (
                      <ArrowUpRight size={12} className="text-emerald-400" />
                    ) : (
                      <ArrowDownRight size={12} className="text-rose-400" />
                    )}
                    <span className={`text-sm font-mono font-black ${bot.performance.roi >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {bot.performance.roi > 0 ? '+' : ''}{bot.performance.roi}%
                    </span>
                  </div>
                </div>
                <div className="text-center border-r border-white/5">
                  <span className="text-[9px] text-gray-500 font-black uppercase block mb-1">Win Rate</span>
                  <div className="flex items-center justify-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-indigo-500"></div>
                    <span className="text-sm font-mono font-black text-white">{bot.performance.winRate}%</span>
                  </div>
                </div>
                <div className="text-center border-r border-white/5">
                  <span className="text-[9px] text-gray-500 font-black uppercase block mb-1">Profit</span>
                  <span className="text-sm font-mono font-black text-emerald-400">${bot.performance.profit}</span>
                </div>
                <div className="text-center border-r border-white/5">
                  <span className="text-[9px] text-gray-500 font-black uppercase block mb-1">Trades</span>
                  <span className="text-sm font-mono font-black text-white">{bot.performance.totalTrades}</span>
                </div>
              </div>

              {/* Historical Chart */}
              <div className="h-32 w-full mt-4 bg-black/20 rounded-xl border border-white/5 p-2">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={bot.performance.history}>
                    <defs>
                      <linearGradient id={`colorRoi-${bot.id}`} x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#000', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                      itemStyle={{ fontSize: '12px' }}
                      labelStyle={{ display: 'none' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="roi" 
                      stroke="#10b981" 
                      fillOpacity={1} 
                      fill={`url(#colorRoi-${bot.id})`} 
                      strokeWidth={2}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Configuration Preview */}
              <div className="flex items-center justify-between text-xs font-mono text-gray-500 bg-white/5 px-4 py-2 rounded-lg border border-white/5">
                <span>{bot.config.pair}</span>
                {bot.config.leverage && <span className="text-amber-500">x{bot.config.leverage}</span>}
                <span>${bot.config.amount}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-3 mt-6 relative z-10">
              <button 
                onClick={() => toggleBotStatus(bot.id)}
                className={`flex-1 py-3 rounded-xl font-black text-sm shadow-lg transition-all flex items-center justify-center gap-2 ${
                  bot.status === 'active' 
                    ? 'bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20' 
                    : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-500/20'
                }`}
              >
                {bot.status === 'active' ? (
                  <>
                    <Pause size={18} fill="currentColor" /> إيقاف البوت
                  </>
                ) : (
                  <>
                    <Play size={18} fill="currentColor" /> تشغيل البوت
                  </>
                )}
              </button>
              <button 
                onClick={() => toggleSettings(bot.id)}
                className={`p-3 rounded-xl transition-all border ${
                  expandedBotId === bot.id 
                    ? 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30' 
                    : 'bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border-white/5'
                }`}
              >
                <Settings size={20} />
              </button>
            </div>

            {/* Advanced Settings */}
            {expandedBotId === bot.id && (
              <div className="mt-6 pt-6 border-t border-white/5 animate-in slide-in-from-top-2 duration-300">
                <h4 className="text-sm font-black text-white mb-4 flex items-center gap-2">
                  <Settings size={14} className="text-indigo-400" />
                  إعدادات متقدمة
                </h4>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">نطاق السوق</label>
                    <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
                      <button
                        onClick={() => updateBotConfig(bot.id, 'marketType', 'Specific')}
                        className={`flex-1 py-1.5 text-[10px] font-black rounded-md transition-all ${
                          bot.advancedConfig?.marketType === 'Specific' 
                            ? 'bg-indigo-500/20 text-indigo-400 shadow-sm' 
                            : 'text-gray-500 hover:text-gray-300'
                        }`}
                      >
                        عملة محددة
                      </button>
                      <button
                        onClick={() => updateBotConfig(bot.id, 'marketType', 'Full')}
                        className={`flex-1 py-1.5 text-[10px] font-black rounded-md transition-all ${
                          bot.advancedConfig?.marketType === 'Full' 
                            ? 'bg-indigo-500/20 text-indigo-400 shadow-sm' 
                            : 'text-gray-500 hover:text-gray-300'
                        }`}
                      >
                        السوق كامل
                      </button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">مبلغ الاستثمار ($)</label>
                    <input 
                      type="number" 
                      value={bot.advancedConfig?.investmentAmount || ''}
                      onChange={(e) => updateBotConfig(bot.id, 'investmentAmount', Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white focus:border-indigo-500 focus:outline-none font-mono text-xs"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">وقف الخسارة (%)</label>
                    <input 
                      type="number" 
                      value={bot.advancedConfig?.stopLoss || ''}
                      onChange={(e) => updateBotConfig(bot.id, 'stopLoss', Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-rose-400 focus:border-rose-500 focus:outline-none font-mono text-xs"
                      placeholder="Disabled"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-gray-500 uppercase">جني الأرباح (%)</label>
                    <input 
                      type="number" 
                      value={bot.advancedConfig?.takeProfit || ''}
                      onChange={(e) => updateBotConfig(bot.id, 'takeProfit', Number(e.target.value))}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-emerald-400 focus:border-emerald-500 focus:outline-none font-mono text-xs"
                      placeholder="Disabled"
                    />
                  </div>

                  {bot.strategy === 'DCA' && (
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase">خطوة التعزيز (DCA Step %)</label>
                      <input 
                        type="number" 
                        value={bot.advancedConfig?.dcaStep || ''}
                        onChange={(e) => updateBotConfig(bot.id, 'dcaStep', Number(e.target.value))}
                        className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white focus:border-indigo-500 focus:outline-none font-mono text-xs"
                        placeholder="e.g. 2.5"
                      />
                    </div>
                  )}

                  {bot.strategy === 'Grid Trading' && (
                    <div className="space-y-2 col-span-2">
                      <label className="text-[10px] font-bold text-gray-500 uppercase">عدد الشبكات (Grids)</label>
                      <input 
                        type="number" 
                        value={bot.advancedConfig?.gridSize || ''}
                        onChange={(e) => updateBotConfig(bot.id, 'gridSize', Number(e.target.value))}
                        className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white focus:border-indigo-500 focus:outline-none font-mono text-xs"
                      />
                    </div>
                  )}
                </div>

                <button 
                  onClick={() => setExpandedBotId(null)}
                  className="w-full mt-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-lg shadow-lg shadow-indigo-500/20 transition-all flex items-center justify-center gap-2"
                >
                  <Check size={14} /> حفظ الإعدادات
                </button>
              </div>
            )}
          </div>
        ))}

        {/* Add New Bot Card */}
        <div 
          onClick={() => setShowCreateModal(true)}
          className="glass-panel p-6 rounded-[2rem] border border-white/5 border-dashed hover:border-indigo-500/50 transition-all flex flex-col items-center justify-center gap-4 min-h-[300px] cursor-pointer group bg-black/20 hover:bg-black/40"
        >
          <div className="w-20 h-20 rounded-full bg-white/5 group-hover:bg-indigo-500/20 flex items-center justify-center transition-all border border-white/10 group-hover:border-indigo-500/30">
            <Bot size={32} className="text-gray-500 group-hover:text-indigo-400 transition-colors" />
          </div>
          <div className="text-center">
            <h3 className="text-xl font-black text-white mb-1 group-hover:text-indigo-400 transition-colors">إنشاء بوت جديد</h3>
            <p className="text-gray-500 text-sm">قم بتخصيص استراتيجية جديدة</p>
          </div>
        </div>
      </div>

      {/* Create Bot Modal */}
      {showCreateModal && (
        <CreateBotModal 
          onClose={() => setShowCreateModal(false)}
          onCreate={handleCreateBot}
        />
      )}

      {/* API Key Modal */}
      {showApiModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-[#0e1116] w-full max-w-md rounded-[2rem] border border-indigo-500/20 shadow-[0_0_50px_rgba(99,102,241,0.15)] overflow-hidden p-8 relative">
            <button 
              onClick={() => setShowApiModal(false)}
              className="absolute top-4 left-4 text-gray-500 hover:text-white"
            >
              <X size={24} />
            </button>

            <div className="text-center mb-8">
              <div className="w-16 h-16 mx-auto bg-indigo-500/10 rounded-2xl flex items-center justify-center border border-indigo-500/20 mb-4">
                <Key size={32} className="text-indigo-400" />
              </div>
              <h3 className="text-2xl font-black text-white mb-2">ربط منصة Binance</h3>
              <p className="text-gray-400 text-sm">
                أدخل مفاتيح API الخاصة بك لتمكين التداول الآلي.
                <br />
                <span className="text-xs text-amber-500 mt-2 block flex items-center justify-center gap-1">
                  <AlertTriangle size={12} />
                  يتم تخزين المفاتيح محلياً في متصفحك فقط.
                </span>
              </p>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500">API Key</label>
                <input 
                  type="text" 
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-indigo-500 focus:outline-none font-mono text-sm"
                  placeholder="Enter your Binance API Key"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-500">Secret Key</label>
                <input 
                  type="password" 
                  value={apiSecret}
                  onChange={(e) => setApiSecret(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-indigo-500 focus:outline-none font-mono text-sm"
                  placeholder="Enter your Binance Secret Key"
                />
              </div>

              <button 
                onClick={handleConnect}
                disabled={isConnecting}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white font-black rounded-xl shadow-lg shadow-indigo-500/20 transition-all mt-4 flex items-center justify-center gap-2"
              >
                {isConnecting ? <Loader2 size={20} className="animate-spin" /> : 'تأكيد الربط'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
