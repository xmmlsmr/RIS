import React, { useState, useEffect } from 'react';
import { X, Bell, Save, Trash2 } from 'lucide-react';
import { Alert } from '../types';

interface AlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (alert: Partial<Alert>) => void;
  alert?: Alert | null;
}

export const AlertModal: React.FC<AlertModalProps> = ({ isOpen, onClose, onSave, alert }) => {
  const [symbol, setSymbol] = useState('');
  const [type, setType] = useState<'Price' | 'RSI' | 'Change' | 'Volume'>('Price');
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<'info' | 'warning' | 'critical'>('info');

  useEffect(() => {
    if (alert) {
      setSymbol(alert.symbol);
      setType(alert.type);
      setMessage(alert.message);
      setSeverity(alert.severity);
    } else {
      setSymbol('');
      setType('Price');
      setMessage('');
      setSeverity('info');
    }
  }, [alert, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      symbol,
      type,
      message,
      severity
    });
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200" dir="rtl">
      <div className="bg-[#0e1116] w-full max-w-md rounded-3xl border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="p-6 border-b border-white/5 flex justify-between items-center bg-white/5">
          <h3 className="text-xl font-black text-white flex items-center gap-2">
            <Bell className="text-cyan-500" />
            {alert ? 'تعديل التنبيه' : 'إضافة تنبيه جديد'}
          </h3>
          <button onClick={onClose} className="text-gray-500 hover:text-white transition-colors">
            <X size={20} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400">رمز العملة</label>
            <input 
              type="text" 
              value={symbol}
              onChange={(e) => setSymbol(e.target.value.toUpperCase())}
              className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none font-mono"
              placeholder="BTC, ETH, SOL..."
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400">نوع التنبيه</label>
            <select 
              value={type}
              onChange={(e) => setType(e.target.value as any)}
              className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none"
            >
              <option value="Price">سعر (Price)</option>
              <option value="RSI">مؤشر (RSI)</option>
              <option value="Change">تغير (Change)</option>
              <option value="Volume">حجم (Volume)</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400">نص التنبيه</label>
            <textarea 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full bg-black/40 border border-white/10 rounded-xl p-3 text-white focus:border-cyan-500 focus:outline-none h-24 resize-none"
              placeholder="اكتب وصف التنبيه هنا..."
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400">الأهمية</label>
            <div className="flex gap-2">
              <button 
                type="button"
                onClick={() => setSeverity('info')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${severity === 'info' ? 'bg-blue-500/20 border-blue-500 text-blue-500' : 'bg-black/40 border-white/5 text-gray-500'}`}
              >
                عادي
              </button>
              <button 
                type="button"
                onClick={() => setSeverity('warning')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${severity === 'warning' ? 'bg-amber-500/20 border-amber-500 text-amber-500' : 'bg-black/40 border-white/5 text-gray-500'}`}
              >
                متوسط
              </button>
              <button 
                type="button"
                onClick={() => setSeverity('critical')}
                className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${severity === 'critical' ? 'bg-rose-500/20 border-rose-500 text-rose-500' : 'bg-black/40 border-white/5 text-gray-500'}`}
              >
                حرج
              </button>
            </div>
          </div>

          <button 
            type="submit" 
            className="w-full py-4 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center justify-center gap-2 mt-4"
          >
            <Save size={18} />
            {alert ? 'حفظ التعديلات' : 'إضافة التنبيه'}
          </button>
        </form>
      </div>
    </div>
  );
};
