import React, { useState, useEffect } from 'react';
import { Newspaper, ExternalLink, Clock, TrendingUp, TrendingDown, Minus, Filter, Search } from 'lucide-react';
import { NewsItem } from '../types';
import { fetchNews, fetchLatestNews } from '../services/newsService';

export const NewsPage: React.FC = () => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'All' | 'Crypto' | 'Market' | 'Tech' | 'Regulation'>('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const loadNews = async () => {
      try {
        const data = await fetchNews();
        setNews(data);
      } catch (error) {
        console.error('Failed to load news', error);
      } finally {
        setLoading(false);
      }
    };

    loadNews();

    // Simulate real-time updates
    const interval = setInterval(async () => {
      const latest = await fetchLatestNews();
      if (latest) {
        setNews(prev => [latest, ...prev]);
      }
    }, 15000); // Check every 15 seconds

    return () => clearInterval(interval);
  }, []);

  const filteredNews = news.filter(item => {
    const matchesFilter = filter === 'All' || item.category === filter;
    const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          item.summary.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'Positive': return <TrendingUp size={16} className="text-emerald-400" />;
      case 'Negative': return <TrendingDown size={16} className="text-rose-400" />;
      default: return <Minus size={16} className="text-gray-400" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
      switch (sentiment) {
        case 'Positive': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
        case 'Negative': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
        default: return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
      }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6 animate-in fade-in duration-500 pb-20" dir="rtl">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-gradient-to-br from-blue-900/20 to-black p-8 rounded-[2rem] border border-blue-500/20 shadow-xl relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl font-black text-white tracking-tight mb-2 flex items-center gap-3">
            <Newspaper size={32} className="text-blue-400" />
            أخبار السوق المباشرة
          </h2>
          <p className="text-gray-400 font-medium max-w-2xl">
            تغطية حية ومستمرة لأهم الأحداث المؤثرة في سوق العملات الرقمية والأسواق العالمية.
          </p>
        </div>
        
        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto z-10">
            <div className="relative">
                <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input 
                    type="text" 
                    placeholder="بحث في الأخبار..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full sm:w-64 bg-black/40 border border-white/10 rounded-xl py-2 pr-10 pl-4 text-sm text-white focus:outline-none focus:border-blue-500 transition-colors"
                />
            </div>
            <div className="flex bg-black/40 rounded-xl p-1 border border-white/10 overflow-x-auto">
                {['All', 'Crypto', 'Market', 'Tech', 'Regulation'].map((cat) => (
                    <button
                        key={cat}
                        onClick={() => setFilter(cat as any)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap ${
                            filter === cat 
                            ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20' 
                            : 'text-gray-400 hover:text-white hover:bg-white/5'
                        }`}
                    >
                        {cat === 'All' ? 'الكل' : cat}
                    </button>
                ))}
            </div>
        </div>
      </div>

      {/* News Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
                <div key={i} className="h-64 bg-white/5 rounded-[2rem] animate-pulse"></div>
            ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNews.map((item) => (
            <div key={item.id} className="glass-panel rounded-[2rem] border border-white/5 overflow-hidden group hover:border-blue-500/30 transition-all hover:-translate-y-1 duration-300 flex flex-col">
              {/* Image */}
              <div className="h-48 overflow-hidden relative">
                <img 
                    src={item.imageUrl || 'https://images.unsplash.com/photo-1621504450168-38f647315648?w=500&auto=format&fit=crop&q=60'} 
                    alt={item.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase backdrop-blur-md border ${getSentimentColor(item.sentiment)}`}>
                        {item.sentiment}
                    </span>
                </div>
                <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-black to-transparent"></div>
              </div>

              {/* Content */}
              <div className="p-6 flex-1 flex flex-col">
                <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider bg-blue-500/10 px-2 py-1 rounded-md border border-blue-500/20">
                        {item.category}
                    </span>
                    <span className="text-[10px] text-gray-500 flex items-center gap-1">
                        <Clock size={12} />
                        {new Date(item.publishedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                </div>

                <h3 className="text-lg font-bold text-white mb-3 line-clamp-2 leading-tight group-hover:text-blue-400 transition-colors">
                    {item.title}
                </h3>
                
                <p className="text-gray-400 text-sm line-clamp-3 mb-6 flex-1">
                    {item.summary}
                </p>

                <div className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
                    <span className="text-xs font-bold text-gray-500">
                        Source: <span className="text-gray-300">{item.source}</span>
                    </span>
                    <a 
                        href={item.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-xs font-bold text-blue-400 hover:text-blue-300 transition-colors"
                    >
                        اقرأ المزيد <ExternalLink size={12} />
                    </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
