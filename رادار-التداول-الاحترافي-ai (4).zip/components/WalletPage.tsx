import React, { useState, useEffect } from 'react';
import { Wallet, ArrowUpRight, ArrowDownLeft, History, CreditCard, PieChart, TrendingUp, DollarSign, X, ChevronRight, Copy, Check, RefreshCw, ArrowRightLeft } from 'lucide-react';
import { useWallet } from '../context/WalletContext';
import { fetchTickers } from '../services/cryptoService';

interface WalletPageProps {
  onClose: () => void;
  onDeposit: () => void;
  onWithdraw: () => void;
}

export const WalletPage: React.FC<WalletPageProps> = ({ onClose, onDeposit, onWithdraw }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'exchange'>('overview');
  const { balance, assets: userAssets, transactions, exchangeAssets } = useWallet();
  
  // Exchange State
  const [fromAsset, setFromAsset] = useState('USDT');
  const [toAsset, setToAsset] = useState('BTC');
  const [amount, setAmount] = useState('');
  const [exchangeRate, setExchangeRate] = useState<number | null>(null);
  const [loadingRate, setLoadingRate] = useState(false);
  const [exchangeError, setExchangeError] = useState('');
  const [exchangeSuccess, setExchangeSuccess] = useState('');

  const balanceInfo = {
    total: balance + Object.entries(userAssets || {}).reduce((acc, [symbol, amount]) => {
      // Mock value calculation, ideally fetch prices
      const mockPrices: {[key: string]: number} = { 'BTC': 95000, 'ETH': 2800, 'SOL': 140, 'USDT': 1 };
      return acc + (Number(amount) * (mockPrices[symbol] || 0));
    }, 0),
    available: balance, // Simplified
    locked: 0,
    pnl: +12.5,
  };

  const assetsList = [
    { symbol: 'USDT', name: 'Tether', balance: balance, value: balance, change: 0.01 },
    ...Object.entries(userAssets || {}).map(([symbol, amount]) => {
       const mockPrices: {[key: string]: number} = { 'BTC': 95000, 'ETH': 2800, 'SOL': 140 };
       const price = mockPrices[symbol] || 0;
       return {
         symbol,
         name: symbol, // Simplified
         balance: Number(amount),
         value: Number(amount) * price,
         change: 2.5 // Mock change
       };
    })
  ];

  useEffect(() => {
    const fetchRate = async () => {
      setLoadingRate(true);
      try {
        const tickers = await fetchTickers();
        const getPrice = (symbol: string) => {
          if (symbol === 'USDT') return 1;
          const ticker = tickers.find(t => t.symbol === `${symbol}USDT`);
          return ticker ? parseFloat(ticker.lastPrice) : 0;
        };

        const fromPrice = getPrice(fromAsset);
        const toPrice = getPrice(toAsset);

        if (fromPrice && toPrice) {
          setExchangeRate(fromPrice / toPrice);
        } else {
          // Fallback to mock prices if API fails or symbol not found
          const mockPrices: {[key: string]: number} = { 'BTC': 95000, 'ETH': 2800, 'SOL': 140, 'USDT': 1 };
          const mockFrom = mockPrices[fromAsset] || 1;
          const mockTo = mockPrices[toAsset] || 1;
          setExchangeRate(mockFrom / mockTo);
        }
      } catch (error) {
        console.error('Failed to fetch rate', error);
        // Fallback
        const mockPrices: {[key: string]: number} = { 'BTC': 95000, 'ETH': 2800, 'SOL': 140, 'USDT': 1 };
        const mockFrom = mockPrices[fromAsset] || 1;
        const mockTo = mockPrices[toAsset] || 1;
        setExchangeRate(mockFrom / mockTo);
      } finally {
        setLoadingRate(false);
      }
    };

    if (fromAsset && toAsset) {
      fetchRate();
    }
  }, [fromAsset, toAsset]);

  const handleExchange = async () => {
    setExchangeError('');
    setExchangeSuccess('');
    
    if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
      setExchangeError('الرجاء إدخال مبلغ صحيح');
      return;
    }

    if (!exchangeRate) {
      setExchangeError('فشل في الحصول على سعر الصرف');
      return;
    }

    try {
      const result = await exchangeAssets(fromAsset, toAsset, Number(amount), exchangeRate, 0.001); // 0.1% fee
      if (result.success) {
        setExchangeSuccess('تم التحويل بنجاح');
        setAmount('');
      } else {
        setExchangeError(result.error || 'فشل التحويل');
      }
    } catch (error) {
      setExchangeError('حدث خطأ أثناء التحويل');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-[#0e1116] w-full max-w-4xl rounded-[2.5rem] border border-cyan-500/20 shadow-[0_0_80px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col h-[85vh] relative">
        
        {/* Background Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent rotate-45 pointer-events-none"></div>

        {/* Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/20 flex items-center justify-center">
              <Wallet className="text-cyan-400" size={24} />
            </div>
            <div>
              <h2 className="text-xl font-black text-white">المحفظة</h2>
              <p className="text-xs text-gray-400">إدارة الأصول والعمليات المالية</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all text-gray-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex flex-1 overflow-hidden relative z-10">
          {/* Sidebar Navigation */}
          <div className="w-64 bg-black/20 border-l border-white/5 p-4 flex flex-col gap-2 hidden md:flex">
            <button 
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm ${activeTab === 'overview' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <PieChart size={18} />
              نظرة عامة
            </button>
            <button 
              onClick={() => setActiveTab('exchange')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm ${activeTab === 'exchange' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-400 hover:bg-white/5 hover:text-white'} opacity-50 cursor-not-allowed`}
              disabled
            >
              <RefreshCw size={18} />
              تبادل الأصول (قريباً)
            </button>
            <button 
              onClick={() => setActiveTab('transactions')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold text-sm ${activeTab === 'transactions' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
            >
              <History size={18} />
              سجل العمليات
            </button>
          </div>

          {/* Main Content Area */}
          <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
            
            {activeTab === 'overview' && (
              <div className="space-y-6">
                {/* Balance Card */}
                <div className="bg-gradient-to-br from-cyan-900/20 to-blue-900/20 rounded-3xl p-6 border border-cyan-500/20 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
                  
                  <div className="relative z-10">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <p className="text-gray-400 text-xs font-bold mb-1">إجمالي الرصيد المقدر</p>
                        <h3 className="text-3xl font-black text-white flex items-baseline gap-2">
                          ${balanceInfo.total.toLocaleString()}
                          <span className="text-xs font-bold text-gray-500">USD</span>
                        </h3>
                        <div className="flex items-center gap-2 mt-2 text-emerald-400 text-xs font-bold bg-emerald-500/10 px-2 py-1 rounded-lg w-fit">
                          <TrendingUp size={12} />
                          +{balanceInfo.pnl}% (24h)
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={onDeposit}
                          className="flex items-center gap-2 px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-95 text-xs"
                        >
                          <ArrowDownLeft size={16} />
                          إيداع
                        </button>
                        <button 
                          onClick={onWithdraw}
                          className="flex items-center gap-2 px-5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl border border-white/10 transition-all active:scale-95 text-xs"
                        >
                          <ArrowUpRight size={16} />
                          سحب
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
                      <div>
                        <p className="text-gray-400 text-[10px] mb-1">الرصيد المتاح</p>
                        <p className="text-lg font-bold text-white">${balanceInfo.available.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-[10px] mb-1">الرصيد المحجوز (في صفقات)</p>
                        <p className="text-lg font-bold text-white">${balanceInfo.locked.toLocaleString()}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Assets List */}
                <div>
                  <h3 className="text-base font-bold text-white mb-3 flex items-center gap-2">
                    <CreditCard size={16} className="text-cyan-500" />
                    الأصول
                  </h3>
                  <div className="space-y-2">
                    {assetsList.map((asset) => {
                      const percentage = (asset.value / (balanceInfo.total || 1)) * 100;
                      return (
                        <div key={asset.symbol} className="bg-white/5 hover:bg-white/10 p-3 rounded-xl border border-white/5 transition-all group relative overflow-hidden">
                          <div className="flex items-center justify-between relative z-10 mb-2">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold text-white text-xs">
                                {asset.symbol[0]}
                              </div>
                              <div>
                                <div className="font-bold text-white text-sm">{asset.symbol}</div>
                                <div className="text-[10px] text-gray-400">{asset.name}</div>
                              </div>
                            </div>
                            <div className="text-left">
                              <div className="font-bold text-white text-sm">{asset.balance.toLocaleString()} {asset.symbol}</div>
                              <div className="text-[10px] text-gray-400">${asset.value.toLocaleString()}</div>
                            </div>
                          </div>
                          
                          {/* Progress Bar */}
                          <div className="w-full bg-black/40 h-2 rounded-full overflow-hidden mt-3 relative">
                             <div 
                               className={`h-full rounded-full transition-all duration-1000 ease-out ${
                                 asset.change >= 0 ? 'bg-gradient-to-r from-cyan-500 to-blue-500' : 'bg-gradient-to-r from-rose-500 to-pink-500'
                               }`}
                               style={{ width: `${percentage}%` }}
                             ></div>
                          </div>
                          <div className="flex justify-between items-center mt-1">
                            <span className={`text-[10px] font-bold ${asset.change >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                              {asset.change > 0 ? '+' : ''}{asset.change}% (24h)
                            </span>
                            <span className="text-xs text-gray-500 font-mono">
                              {percentage.toFixed(1)}% of portfolio
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'exchange' && (
              <div className="space-y-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <RefreshCw size={18} className="text-cyan-500" />
                  تبادل الأصول
                </h3>

                <div className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-6">
                  {/* From Asset */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400">من (بيع)</label>
                    <div className="flex gap-4">
                      <select 
                        value={fromAsset}
                        onChange={(e) => setFromAsset(e.target.value)}
                        className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white font-bold w-1/3 focus:outline-none focus:border-cyan-500"
                      >
                        <option value="USDT">USDT</option>
                        <option value="BTC">BTC</option>
                        <option value="ETH">ETH</option>
                        <option value="SOL">SOL</option>
                      </select>
                      <input 
                        type="number" 
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                        placeholder="الكمية"
                        className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white font-bold w-2/3 focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div className="text-xs text-gray-500 text-left">
                      الرصيد المتاح: {fromAsset === 'USDT' ? balance : (userAssets[fromAsset] || 0)} {fromAsset}
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <ArrowRightLeft size={18} className="text-gray-400" />
                    </div>
                  </div>

                  {/* To Asset */}
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-400">إلى (شراء)</label>
                    <div className="flex gap-4">
                      <select 
                        value={toAsset}
                        onChange={(e) => setToAsset(e.target.value)}
                        className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white font-bold w-1/3 focus:outline-none focus:border-cyan-500"
                      >
                        <option value="USDT">USDT</option>
                        <option value="BTC">BTC</option>
                        <option value="ETH">ETH</option>
                        <option value="SOL">SOL</option>
                      </select>
                      <div className="bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white font-bold w-2/3 flex items-center justify-between opacity-70">
                        <span>
                          {amount && exchangeRate 
                            ? (Number(amount) * exchangeRate * 0.999).toFixed(6) 
                            : '0.00'}
                        </span>
                        <span className="text-xs text-gray-500">تقديري</span>
                      </div>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="bg-black/20 rounded-xl p-4 space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">سعر الصرف</span>
                      <span className="text-white font-mono">
                        1 {fromAsset} = {exchangeRate ? exchangeRate.toFixed(6) : '...'} {toAsset}
                      </span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">رسوم التحويل (0.1%)</span>
                      <span className="text-rose-400 font-mono">
                        {amount ? (Number(amount) * 0.001).toFixed(6) : '0.00'} {fromAsset}
                      </span>
                    </div>
                  </div>

                  {exchangeError && (
                    <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-3 rounded-xl text-xs font-bold text-center">
                      {exchangeError}
                    </div>
                  )}

                  {exchangeSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-3 rounded-xl text-xs font-bold text-center">
                      {exchangeSuccess}
                    </div>
                  )}

                  <button 
                    onClick={handleExchange}
                    disabled={loadingRate || !amount}
                    className="w-full py-4 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-95"
                  >
                    {loadingRate ? 'جاري تحديث السعر...' : 'تأكيد التحويل'}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'transactions' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <History size={18} className="text-cyan-500" />
                  آخر العمليات
                </h3>
                <div className="space-y-3">
                  {transactions.map((tx) => (
                    <div key={tx.id} className="bg-white/5 p-4 rounded-2xl border border-white/5 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          tx.type === 'deposit' ? 'bg-emerald-500/20 text-emerald-400' :
                          tx.type === 'withdraw' ? 'bg-rose-500/20 text-rose-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {tx.type === 'deposit' && <ArrowDownLeft size={18} />}
                          {tx.type === 'withdraw' && <ArrowUpRight size={18} />}
                        </div>
                        <div>
                          <div className="font-bold text-white capitalize">{tx.type === 'deposit' ? 'إيداع' : 'سحب'}</div>
                          <div className="text-xs text-gray-400">{tx.date}</div>
                        </div>
                      </div>
                      <div className="text-left">
                        <div className={`font-bold ${
                          tx.type === 'deposit' ? 'text-emerald-400' : 'text-white'
                        }`}>
                          {tx.type === 'deposit' ? '+' : '-'}{tx.amount} {tx.method.split(' ')[0]}
                        </div>
                        <div className={`text-[10px] font-bold px-2 py-0.5 rounded-lg inline-block mt-1 ${
                          tx.status === 'approved' ? 'bg-emerald-500/10 text-emerald-400' : 
                          tx.status === 'rejected' ? 'bg-rose-500/10 text-rose-400' :
                          'bg-amber-500/10 text-amber-400'
                        }`}>
                          {tx.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        </div>
      </div>
    </div>
  );
};
