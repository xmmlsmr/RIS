import React, { useState } from 'react';
import { Wallet, ArrowUpRight, ArrowDownLeft, History, CreditCard, PieChart, TrendingUp, DollarSign, X, ChevronRight, Copy, Check, AlertTriangle, ShieldCheck, Loader2 } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { useWallet } from '../context/WalletContext';

interface WithdrawPageProps {
  onClose: () => void;
  onSuccess?: () => void;
}

export const WithdrawPage: React.FC<WithdrawPageProps> = ({ onClose, onSuccess }) => {
  const { financeSettings } = useSettings();
  const { addTransaction, balance } = useWallet();
  
  const ASSETS = [
    { symbol: 'USDT', name: 'Tether', networks: ['TRC20', 'ERC20', 'BEP20'], balance: balance },
    { symbol: 'BTC', name: 'Bitcoin', networks: ['Bitcoin'], balance: 0.00 }, // Mock
    { symbol: 'ETH', name: 'Ethereum', networks: ['ERC20', 'Arbitrum', 'Optimism'], balance: 0.00 }, // Mock
  ];

  const [selectedAssetSymbol, setSelectedAssetSymbol] = useState(ASSETS[0].symbol);
  const selectedAsset = ASSETS.find(a => a.symbol === selectedAssetSymbol) || ASSETS[0];
  const [selectedNetwork, setSelectedNetwork] = useState(ASSETS[0].networks[0]);
  const [address, setAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState<'form' | 'confirm' | 'success'>('form');

  // Use global settings for fee and min withdraw
  // In a real app, these might be per-asset, but for now we use the global admin settings
  const minWithdraw = financeSettings.minWithdraw;
  const fee = financeSettings.withdrawFee;

  const handleAssetChange = (assetSymbol: string) => {
    const asset = ASSETS.find(a => a.symbol === assetSymbol) || ASSETS[0];
    setSelectedAssetSymbol(asset.symbol);
    setSelectedNetwork(asset.networks[0]);
    setAmount('');
  };

  const handleMaxAmount = () => {
    setAmount(selectedAsset.balance.toString());
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    addTransaction({
      userId: 'current-user-id', // In a real app, get from auth context
      userName: 'Current User', // In a real app, get from auth context
      type: 'withdraw',
      amount: parseFloat(amount),
      method: `${selectedAsset.symbol} (${selectedNetwork})`,
      address: address,
    });

    setIsSubmitting(false);
    setStep('success');
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="bg-[#0e1116] w-full max-w-lg rounded-[2.5rem] border border-cyan-500/20 shadow-[0_0_80px_rgba(6,182,212,0.15)] overflow-hidden flex flex-col relative max-h-[90vh]">
        
        {/* Background Glow */}
        <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-gradient-to-br from-cyan-500/5 via-transparent to-transparent rotate-45 pointer-events-none"></div>

        {/* Header */}
        <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5 relative z-10">
          <h2 className="text-xl font-black text-white flex items-center gap-2">
            <ArrowUpRight className="text-cyan-500" size={24} />
            سحب الأموال
          </h2>
          <button 
            onClick={onClose}
            className="p-2 bg-white/5 rounded-xl hover:bg-white/10 transition-all text-gray-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto custom-scrollbar relative z-10">
          
          {step === 'form' && (
            <div className="space-y-5">
              {/* Asset Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400">العملة</label>
                <div className="grid grid-cols-3 gap-2">
                  {ASSETS.map(asset => (
                    <button
                      key={asset.symbol}
                      onClick={() => handleAssetChange(asset.symbol)}
                      className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                        selectedAsset.symbol === asset.symbol
                          ? 'bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                          : 'bg-black/40 border-white/5 hover:bg-white/5 text-gray-400'
                      }`}
                    >
                      <span className="font-black text-xs">{asset.symbol}</span>
                      <span className="text-[9px] text-gray-500">{asset.balance}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Network Selection */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400">الشبكة</label>
                <select 
                  value={selectedNetwork}
                  onChange={(e) => setSelectedNetwork(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-black/40 border border-white/10 text-white font-bold text-xs focus:outline-none focus:border-cyan-500 transition-colors appearance-none"
                >
                  {selectedAsset.networks.map(net => (
                    <option key={net} value={net}>{net}</option>
                  ))}
                </select>
              </div>

              {/* Address Input */}
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-400">عنوان المحفظة</label>
                <input 
                  type="text" 
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={`أدخل عنوان ${selectedAsset.symbol} (${selectedNetwork})`}
                  className="w-full p-2.5 rounded-xl bg-black/40 border border-white/10 text-white font-mono text-xs focus:outline-none focus:border-cyan-500 transition-colors placeholder:text-gray-600"
                />
                <p className="text-[9px] text-amber-500 flex items-center gap-1">
                  <AlertTriangle size={10} />
                  تأكد من تطابق الشبكة لتجنب فقدان الأموال.
                </p>
              </div>

              {/* Amount Input */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] font-bold text-gray-400">المبلغ</label>
                  <span className="text-[9px] text-gray-500">
                    المتاح: <span className="text-white font-bold">{selectedAsset.balance} {selectedAsset.symbol}</span>
                  </span>
                </div>
                <div className="relative">
                  <input 
                    type="number" 
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full p-2.5 pl-16 rounded-xl bg-black/40 border border-white/10 text-white font-bold text-base focus:outline-none focus:border-cyan-500 transition-colors placeholder:text-gray-600"
                  />
                  <button 
                    onClick={handleMaxAmount}
                    className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[9px] font-black bg-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded hover:bg-cyan-500/30 transition-colors"
                  >
                    MAX
                  </button>
                </div>
                <div className="flex justify-between text-[9px] text-gray-500 px-1">
                   <span>الحد الأدنى: {minWithdraw} {selectedAsset.symbol}</span>
                </div>
              </div>

              {/* Summary */}
              <div className="bg-white/5 rounded-xl p-3 space-y-2 border border-white/5">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-gray-400">رسوم الشبكة</span>
                  <span className="text-white font-mono">{fee} {selectedAsset.symbol}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-bold pt-2 border-t border-white/5">
                  <span className="text-gray-300">الإجمالي المستلم</span>
                  <span className="text-cyan-400 font-mono">
                    {amount ? (parseFloat(amount) - fee).toFixed(4) : '0.00'} {selectedAsset.symbol}
                  </span>
                </div>
              </div>

              <button 
                onClick={() => setStep('confirm')}
                disabled={!address || !amount || parseFloat(amount) < minWithdraw || parseFloat(amount) > selectedAsset.balance}
                className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-800 disabled:text-gray-500 disabled:cursor-not-allowed text-white font-black rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2 text-sm"
              >
                متابعة السحب
                <ArrowUpRight size={16} />
              </button>
            </div>
          )}

          {step === 'confirm' && (
            <div className="space-y-6 text-center">
              <div className="w-20 h-20 mx-auto bg-amber-500/10 rounded-full flex items-center justify-center border border-amber-500/20 mb-4">
                <ShieldCheck size={40} className="text-amber-500" />
              </div>
              
              <h3 className="text-xl font-black text-white">تأكيد عملية السحب</h3>
              <p className="text-sm text-gray-400">يرجى مراجعة التفاصيل أدناه بعناية قبل التأكيد.</p>

              <div className="bg-black/40 rounded-xl border border-white/10 p-4 space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">المبلغ</span>
                  <span className="text-white font-bold">{amount} {selectedAsset.symbol}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">الشبكة</span>
                  <span className="text-white font-bold">{selectedNetwork}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">العنوان</span>
                  <span className="text-white font-mono text-xs truncate max-w-[200px]">{address}</span>
                </div>
                <div className="flex justify-between pt-2 border-t border-white/5">
                  <span className="text-gray-500">الصافي</span>
                  <span className="text-cyan-400 font-bold">{(parseFloat(amount) - fee).toFixed(4)} {selectedAsset.symbol}</span>
                </div>
              </div>

              <div className="flex gap-3">
                <button 
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="flex-1 py-3 bg-cyan-600 hover:bg-cyan-500 text-white font-black rounded-xl shadow-lg shadow-cyan-500/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : 'تأكيد وإرسال'}
                </button>
                <button 
                  onClick={() => setStep('form')}
                  disabled={isSubmitting}
                  className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white font-bold rounded-xl transition-all"
                >
                  تراجع
                </button>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="space-y-6 text-center py-8">
              <div className="w-24 h-24 mx-auto bg-emerald-500/10 rounded-full flex items-center justify-center border border-emerald-500/20 mb-4 shadow-[0_0_40px_rgba(16,185,129,0.2)]">
                <Check size={48} className="text-emerald-500" />
              </div>
              
              <h3 className="text-2xl font-black text-white">تم تقديم الطلب بنجاح!</h3>
              <p className="text-gray-400 text-sm max-w-xs mx-auto">
                سيتم معالجة طلب السحب الخاص بك خلال 24 ساعة. يمكنك متابعة الحالة في سجل العمليات.
              </p>

              <button 
                onClick={() => {
                  if (onSuccess) onSuccess();
                  onClose();
                }}
                className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-lg shadow-emerald-500/20 transition-all active:scale-[0.98]"
              >
                العودة للمحفظة
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
