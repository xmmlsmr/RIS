import React, { useState } from 'react';
import { motion, useScroll, useTransform } from 'motion/react';
import { 
  Activity, ArrowRight, ShieldCheck, Zap, BarChart2, Globe, Cpu, 
  TrendingUp, Lock, Users, Play, CheckCircle2, X,
  LineChart, Wallet, Layers, ArrowUpRight, Bot, Gift, Crown, Network,
  Search, MousePointerClick, Coins, BrainCircuit
} from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

const FloatingElement = ({ children, delay = 0, x = 0, y = 0 }: { children: React.ReactNode, delay?: number, x?: number, y?: number }) => (
  <motion.div
    animate={{ 
      y: [0, -15, 0],
    }}
    transition={{ 
      duration: 4, 
      repeat: Infinity, 
      ease: "easeInOut",
      delay: delay 
    }}
    className="absolute z-0 hidden lg:block"
    style={{ top: `${50 + y}%`, left: `${50 + x}%` }}
  >
    {children}
  </motion.div>
);

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted }) => {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState('');
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'samamohamed010') {
      setShowAdminLogin(false);
      window.dispatchEvent(new CustomEvent('openAdmin'));
      setAdminPassword('');
      setAdminError('');
    } else {
      setAdminError('كلمة المرور غير صحيحة');
    }
  };

  return (
    <div className="min-h-screen bg-[#030303] text-white font-sans selection:bg-indigo-500/30 overflow-x-hidden" dir="rtl">
      
      {/* Demo Modal */}
      {showDemo && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/90 backdrop-blur-xl p-4 animate-in fade-in duration-300">
          <div className="relative w-full max-w-6xl aspect-video bg-black rounded-3xl overflow-hidden border border-white/10 shadow-2xl ring-1 ring-white/10">
            <button 
              onClick={() => setShowDemo(false)}
              className="absolute top-6 right-6 z-20 p-2 bg-black/50 hover:bg-white/10 text-white rounded-full transition-all backdrop-blur-md border border-white/10"
            >
              <X size={24} />
            </button>
            <div className="absolute inset-0 flex items-center justify-center bg-[#0a0a0a]">
              {/* Placeholder for actual demo video */}
              <div className="text-center">
                <div className="w-20 h-20 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-6 animate-pulse">
                  <Play size={40} className="text-white/50 ml-1" fill="currentColor" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2">Demo Video Coming Soon</h3>
                <p className="text-gray-500">We are preparing a detailed walkthrough of the platform.</p>
              </div>
              
              {/* If you have a video URL, uncomment this: */}
              {/* <iframe 
                width="100%" 
                height="100%" 
                src="https://www.youtube.com/embed/YOUR_VIDEO_ID?autoplay=1" 
                title="Alpha Radar Demo" 
                frameBorder="0" 
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                allowFullScreen
                className="absolute inset-0 w-full h-full"
              ></iframe> */}
            </div>
          </div>
        </div>
      )}

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-xl p-4 animate-in fade-in duration-200">
          <div className="bg-[#0a0a0a] p-8 rounded-3xl border border-white/10 w-full max-w-md shadow-2xl relative">
            <button 
              onClick={() => setShowAdminLogin(false)}
              className="absolute top-4 left-4 text-gray-500 hover:text-white transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-white/10">
              <Lock size={24} className="text-white" />
            </div>
            <h3 className="text-xl font-medium mb-2 text-center text-white">Admin Access</h3>
            <p className="text-gray-500 text-sm text-center mb-8">Enter your secure credentials to continue.</p>
            
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <input 
                  type="password" 
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-xl py-3.5 px-4 text-white focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 transition-all text-center tracking-widest"
                  placeholder="••••••••"
                  autoFocus
                />
              </div>
              {adminError && (
                <div className="text-rose-500 text-xs font-medium text-center bg-rose-500/10 py-2 rounded-lg border border-rose-500/20">{adminError}</div>
              )}
              <button 
                type="submit"
                className="w-full py-3.5 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-all transform active:scale-[0.98]"
              >
                Authenticate
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Navbar */}
      <nav className="fixed top-0 w-full z-50 bg-[#030303]/80 backdrop-blur-md border-b border-white/5">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white text-black rounded-xl flex items-center justify-center font-black text-xl tracking-tighter">
              A
            </div>
            <span className="text-lg font-bold tracking-tight">ALPHA RADAR</span>
          </div>
          <div className="flex items-center gap-6">
            <button 
              onClick={onGetStarted}
              className="px-6 py-2.5 bg-white text-black rounded-full font-bold text-sm hover:bg-gray-200 transition-all transform hover:scale-105"
            >
              Launch App
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center pt-32 pb-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-[-20%] left-[20%] w-[60%] h-[60%] bg-indigo-600/20 rounded-full blur-[120px] opacity-40"></div>
          <div className="absolute bottom-[-10%] right-[20%] w-[60%] h-[60%] bg-blue-600/10 rounded-full blur-[120px] opacity-40"></div>
          <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-gray-300 text-xs font-medium mb-8 backdrop-blur-sm"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>System v4.0 Now Live</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-medium tracking-tight leading-[1.1] mb-8"
          >
            The Future of <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-white/40">Digital Trading.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg md:text-xl text-gray-400 max-w-2xl mx-auto leading-relaxed mb-12"
          >
            منصة تحليل متقدمة تدمج الذكاء الاصطناعي مع التحليل الفني العميق. 
            اكتشف الفرص الاستثمارية قبل الجميع.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button 
              onClick={onGetStarted}
              className="w-full sm:w-auto px-8 py-4 bg-white text-black text-base font-bold rounded-2xl hover:bg-gray-100 transition-all transform hover:scale-105 flex items-center justify-center gap-2"
            >
              Start Analysis Free
              <ArrowRight size={18} />
            </button>
            <button 
              onClick={() => setShowDemo(true)}
              className="w-full sm:w-auto px-8 py-4 bg-white/5 text-white text-base font-bold rounded-2xl hover:bg-white/10 border border-white/10 transition-all backdrop-blur-sm flex items-center justify-center gap-2"
            >
              <Play size={18} fill="currentColor" />
              Watch Demo
            </button>
          </motion.div>
        </div>

        {/* Floating Cards */}
        <FloatingElement delay={0} x={-35} y={-10}>
          <div className="bg-[#0a0a0a]/80 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-2xl w-64 transform -rotate-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
                <TrendingUp size={20} className="text-emerald-500" />
              </div>
              <span className="text-emerald-500 font-bold text-sm">+24.5%</span>
            </div>
            <div className="space-y-1">
              <div className="h-2 w-20 bg-white/10 rounded-full"></div>
              <div className="h-2 w-32 bg-white/10 rounded-full"></div>
            </div>
            <div className="mt-4 pt-4 border-t border-white/5 flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-gray-700"></div>
              <span className="text-xs text-gray-400">AI Signal Detected</span>
            </div>
          </div>
        </FloatingElement>

        <FloatingElement delay={2} x={35} y={15}>
          <div className="bg-[#0a0a0a]/80 backdrop-blur-xl p-5 rounded-2xl border border-white/10 shadow-2xl w-64 transform rotate-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Zap size={20} className="text-indigo-500" />
              </div>
              <span className="text-indigo-500 font-bold text-sm">98/100</span>
            </div>
            <div className="space-y-1">
              <div className="text-sm font-bold text-white">Smart Score</div>
              <div className="text-xs text-gray-500">Based on 15 indicators</div>
            </div>
          </div>
        </FloatingElement>
      </section>

      {/* Marquee Section */}
      <div className="py-8 border-y border-white/5 bg-black/20 overflow-hidden relative">
        <div className="absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#050505] to-transparent z-10"></div>
        <div className="absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#050505] to-transparent z-10"></div>
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="flex gap-12 whitespace-nowrap"
        >
          {[...Array(2)].map((_, i) => (
            <React.Fragment key={i}>
              {['BTC', 'ETH', 'SOL', 'XRP', 'ADA', 'DOT', 'AVAX', 'LINK', 'MATIC', 'UNI'].map((coin) => (
                <div key={coin} className="flex items-center gap-3 text-2xl font-black text-gray-500/50">
                  <span>{coin}</span>
                  <span className="text-emerald-500/50 text-lg">+2.4%</span>
                </div>
              ))}
            </React.Fragment>
          ))}
        </motion.div>
      </div>

      {/* 1. Who We Are (من نحن) */}
      <section className="py-24 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-bold mb-6">
                <Globe size={14} />
                <span>من نحن</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-medium mb-6 leading-tight">
                نحن نبني الجيل القادم من <span className="text-indigo-400">أدوات التداول الذكية</span>.
              </h2>
              <p className="text-gray-400 text-lg leading-relaxed mb-8">
                ALPHA RADAR هي منصة متكاملة تهدف إلى تمكين المتداولين الأفراد من الوصول إلى الأدوات التي كانت حكراً على المؤسسات المالية الكبرى. نستخدم أحدث تقنيات الذكاء الاصطناعي لتحليل الأسواق وكشف الفرص الخفية.
              </p>
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5">
                  <h4 className="text-3xl font-bold text-white mb-2">+50K</h4>
                  <p className="text-gray-500 text-sm">متداول نشط</p>
                </div>
                <div className="bg-[#0a0a0a] p-6 rounded-2xl border border-white/5">
                  <h4 className="text-3xl font-bold text-white mb-2">$2B+</h4>
                  <p className="text-gray-500 text-sm">حجم تداول محلل</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/20 to-transparent rounded-[2.5rem] blur-2xl"></div>
              <div className="bg-[#0a0a0a] rounded-[2.5rem] border border-white/10 p-2 relative overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-all duration-500">
                <img src="https://images.unsplash.com/photo-1642790106117-e829e14a795f?auto=format&fit=crop&q=80&w=1000" alt="Dashboard Preview" className="rounded-[2rem] w-full object-cover opacity-80 hover:opacity-100 transition-opacity" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. How It Works (طريقة العمل) */}
      <section className="py-24 px-6 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-medium mb-4">كيف تعمل المنصة؟</h2>
            <p className="text-gray-400">ثلاث خطوات بسيطة تفصلك عن التداول الاحترافي</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Search, title: '1. اختر الأصل', desc: 'استخدم الرادار لاكتشاف العملات التي تظهر نشاطاً غير عادي أو اختر عملتك المفضلة.' },
              { icon: Cpu, title: '2. التحليل الذكي', desc: 'يقوم محرك AI بتحليل ملايين نقاط البيانات والمؤشرات الفنية في ثوانٍ معدودة.' },
              { icon: ArrowUpRight, title: '3. نفذ الصفقة', desc: 'احصل على نقاط الدخول والخروج ووقف الخسارة بدقة متناهية ونفذ صفقتك.' }
            ].map((step, i) => (
              <div key={i} className="bg-[#0a0a0a] p-8 rounded-[2rem] border border-white/5 hover:border-indigo-500/30 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-[50px] group-hover:bg-indigo-500/10 transition-all"></div>
                <div className="w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 border border-white/10 group-hover:scale-110 transition-transform">
                  <step.icon size={28} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                <p className="text-gray-400 leading-relaxed text-sm">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. Tools (الأدوات) */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-medium mb-4">أدوات احترافية</h2>
            <p className="text-gray-400">ترسانة متكاملة من الأدوات التقنية</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Activity, title: 'Market Radar', desc: 'ماسح ضوئي للسوق يرصد الفرص اللحظية.' },
              { icon: BrainCircuit, title: 'Neural Engine', desc: 'محرك ذكاء اصطناعي للتحليل العميق.' },
              { icon: Wallet, title: 'Smart Wallets', desc: 'تتبع محافظ الحيتان والمؤسسات.' },
              { icon: ShieldCheck, title: 'Risk Guard', desc: 'نظام إدارة مخاطر آلي لحماية رأس المال.' },
              { icon: LineChart, title: 'Advanced Charts', desc: 'رسوم بيانية متقدمة مع مؤشرات حصرية.' },
              { icon: Zap, title: 'Flash Signals', desc: 'تنبيهات فورية للفرص السريعة (Scalping).' },
              { icon: Layers, title: 'Strategy Matrix', desc: 'مكتبة استراتيجيات جاهزة للتطبيق.' },
              { icon: Network, title: 'On-Chain Data', desc: 'تحليل بيانات البلوكشين والتدفقات.' }
            ].map((tool, i) => (
              <div key={i} className="bg-[#0a0a0a] p-6 rounded-3xl border border-white/5 hover:border-white/20 transition-all hover:-translate-y-1">
                <tool.icon size={32} className="text-indigo-400 mb-4" />
                <h3 className="text-lg font-bold text-white mb-2">{tool.title}</h3>
                <p className="text-gray-500 text-xs leading-relaxed">{tool.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Strategies & Bots (الاستراتيجيات والبوتات) */}
      <section className="py-24 px-6 bg-[#050505]">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Strategies */}
            <div className="bg-[#0a0a0a] rounded-[2.5rem] p-10 border border-white/5 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-emerald-500/5 to-transparent"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-emerald-500/10 rounded-xl text-emerald-400">
                    <Layers size={24} />
                  </div>
                  <h3 className="text-3xl font-medium text-white">الاستراتيجيات الذكية</h3>
                </div>
                <p className="text-gray-400 mb-8 leading-relaxed">
                  نقدم لك مكتبة من الاستراتيجيات المثبتة إحصائياً. سواء كنت تفضل التداول السريع (Scalping) أو التداول اليومي (Day Trading)، ستجد الاستراتيجية المناسبة.
                </p>
                <div className="space-y-4">
                  {['RSI Breakout', 'Golden Cross Institutional', 'MACD Momentum', 'Bollinger Squeeze'].map((s, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-black/40 rounded-xl border border-white/5">
                      <span className="font-bold text-gray-300">{s}</span>
                      <span className="text-emerald-400 text-xs font-bold bg-emerald-500/10 px-2 py-1 rounded">High Win Rate</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Bots */}
            <div className="bg-[#0a0a0a] rounded-[2.5rem] p-10 border border-white/5 relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-bl from-rose-500/5 to-transparent"></div>
              <div className="relative z-10">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-3 bg-rose-500/10 rounded-xl text-rose-400">
                    <Bot size={24} />
                  </div>
                  <h3 className="text-3xl font-medium text-white">بوتات التداول الآلي</h3>
                </div>
                <p className="text-gray-400 mb-8 leading-relaxed">
                  لا تضيع وقتك أمام الشاشات. قم بتفعيل بوتات التداول الآلي لتعمل نيابة عنك 24/7 بناءً على الاستراتيجيات التي تختارها.
                </p>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                    <span className="block text-2xl font-bold text-white mb-1">24/7</span>
                    <span className="text-xs text-gray-500">عمل متواصل</span>
                  </div>
                  <div className="p-4 bg-black/40 rounded-2xl border border-white/5 text-center">
                    <span className="block text-2xl font-bold text-white mb-1">0ms</span>
                    <span className="text-xs text-gray-500">تأخير التنفيذ</span>
                  </div>
                </div>
                <button onClick={onGetStarted} className="w-full mt-8 py-4 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-colors">
                  تفعيل البوتات الآن
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. VIP System (نظام VIP) */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#030303] to-[#0a0a0a]"></div>
        <div className="max-w-5xl mx-auto relative z-10">
          <div className="text-center mb-16">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-amber-500/10 text-amber-400 mb-6 border border-amber-500/20">
              <Crown size={32} />
            </div>
            <h2 className="text-4xl md:text-6xl font-medium mb-6">نظام العضوية VIP</h2>
            <p className="text-gray-400 max-w-2xl mx-auto text-lg">
              احصل على القوة الكاملة للمنصة. بدون قيود، بدون حدود.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Free Tier */}
            <div className="bg-[#0a0a0a] p-8 rounded-[2.5rem] border border-white/5 opacity-60 hover:opacity-100 transition-opacity">
              <h3 className="text-2xl font-bold text-white mb-2">الباقة المجانية</h3>
              <div className="text-4xl font-bold text-white mb-6">$0<span className="text-lg text-gray-500 font-normal">/شهر</span></div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3 text-gray-400"><CheckCircle2 size={18} /> تحليل واحد يومياً</li>
                <li className="flex items-center gap-3 text-gray-400"><CheckCircle2 size={18} /> الوصول للبيانات الأساسية</li>
                <li className="flex items-center gap-3 text-gray-400"><CheckCircle2 size={18} /> استراتيجية واحدة فقط</li>
              </ul>
              <button onClick={onGetStarted} className="w-full py-4 rounded-xl border border-white/10 text-white font-bold hover:bg-white/5 transition-colors">
                ابدأ مجاناً
              </button>
            </div>

            {/* VIP Tier */}
            <div className="bg-gradient-to-b from-[#1a1a1a] to-[#0a0a0a] p-8 rounded-[2.5rem] border border-amber-500/30 relative shadow-2xl transform md:-translate-y-4">
              <div className="absolute top-0 right-0 bg-amber-500 text-black text-xs font-bold px-4 py-1 rounded-bl-xl rounded-tr-[2.5rem]">الأكثر طلباً</div>
              <h3 className="text-2xl font-bold text-white mb-2 flex items-center gap-2">
                VIP Access <Crown size={20} className="text-amber-400" fill="currentColor" />
              </h3>
              <div className="text-4xl font-bold text-white mb-6">$49<span className="text-lg text-gray-500 font-normal">/شهر</span></div>
              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3 text-white"><CheckCircle2 size={18} className="text-amber-400" /> تحليلات غير محدودة</li>
                <li className="flex items-center gap-3 text-white"><CheckCircle2 size={18} className="text-amber-400" /> جميع الاستراتيجيات والبوتات</li>
                <li className="flex items-center gap-3 text-white"><CheckCircle2 size={18} className="text-amber-400" /> تنبيهات لحظية عبر Telegram</li>
                <li className="flex items-center gap-3 text-white"><CheckCircle2 size={18} className="text-amber-400" /> تتبع المحافظ الذكية</li>
              </ul>
              <button onClick={onGetStarted} className="w-full py-4 rounded-xl bg-amber-500 text-black font-bold hover:bg-amber-400 transition-colors shadow-[0_0_20px_rgba(245,158,11,0.3)]">
                ترقية الآن
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Referral Program (برنامج الاحالة) */}
      <section className="py-24 px-6 bg-gradient-to-b from-[#050505] to-[#0a0a0a]">
        <div className="max-w-4xl mx-auto bg-[#0a0a0a] rounded-[3rem] p-10 md:p-16 border border-white/5 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-[80px]"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/10 rounded-full blur-[80px]"></div>
          
          <div className="relative z-10">
            <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-2xl rotate-12">
              <Gift size={40} className="text-white" />
            </div>
            <h2 className="text-4xl md:text-5xl font-medium mb-6">برنامج الشركاء</h2>
            <p className="text-gray-400 text-lg mb-10 max-w-2xl mx-auto">
              ادعُ أصدقائك للانضمام إلى ALPHA RADAR واحصل على عمولات مجزية تصل إلى 30% من اشتراكاتهم، بالإضافة إلى أيام VIP مجانية لكل صديق يسجل.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <div className="flex items-center gap-3 bg-black/40 px-6 py-4 rounded-2xl border border-white/5">
                <Users size={24} className="text-indigo-400" />
                <div className="text-right">
                  <span className="block font-bold text-white">ادعُ صديق</span>
                  <span className="text-xs text-gray-500">شارك الرابط الخاص بك</span>
                </div>
              </div>
              <ArrowRight className="hidden sm:block text-gray-600" />
              <div className="flex items-center gap-3 bg-black/40 px-6 py-4 rounded-2xl border border-white/5">
                <Coins size={24} className="text-amber-400" />
                <div className="text-right">
                  <span className="block font-bold text-white">اكسب المال</span>
                  <span className="text-xs text-gray-500">عمولات فورية</span>
                </div>
              </div>
            </div>
            <button onClick={onGetStarted} className="mt-12 px-10 py-4 bg-white text-black font-bold rounded-xl hover:scale-105 transition-transform">
              ابدأ الربح الآن
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 border-y border-white/5 bg-black/40 backdrop-blur-sm relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
            {[
              { label: 'Active Users', value: '50K+' },
              { label: 'Daily Volume', value: '$20M+' },
              { label: 'Strategies', value: '100+' },
              { label: 'Uptime', value: '99.9%' },
            ].map((stat, i) => (
              <div key={i}>
                <div className="text-4xl md:text-5xl font-medium text-white mb-2 tracking-tighter">{stat.value}</div>
                <div className="text-gray-500 text-sm font-medium uppercase tracking-widest">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-32 px-6 text-center relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
        
        <div className="relative z-10 max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-7xl font-black mb-8 tracking-tight font-tech uppercase text-white">Ready to <span className="text-cyan-400 glow-text-cyan">Ascend?</span></h2>
          <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto font-sans">
            انضم إلى آلاف المتداولين الذين يستخدمون ALPHA RADAR لتحقيق عوائد استثنائية.
          </p>
          <button 
            onClick={onGetStarted}
            className="px-12 py-6 bg-white text-black text-xl font-black rounded-2xl hover:scale-105 transition-transform shadow-[0_0_60px_rgba(255,255,255,0.3)] font-tech tracking-wider uppercase border-2 border-transparent hover:border-cyan-400 hover:text-cyan-400 hover:bg-black"
          >
            Create Free Account
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/5 bg-[#020202]">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-gradient-to-tr from-cyan-600 to-blue-600 rounded-lg flex items-center justify-center font-black text-white text-sm">A</div>
            <span className="font-bold text-gray-300">ALPHA RADAR</span>
          </div>
          <div className="flex flex-col items-center gap-4 md:flex-row md:gap-8">
            <div className="flex gap-6 text-sm text-gray-500 font-medium items-center">
              <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
              <a href="#" className="hover:text-white transition-colors">شروط الاستخدام</a>
              <a href="#" className="hover:text-white transition-colors">الدعم الفني</a>
            </div>
          </div>
          <p className="text-gray-600 text-sm">© 2024 جميع الحقوق محفوظة.</p>
        </div>
      </footer>

      {/* Fixed Admin Button */}
      <button 
        onClick={() => setShowAdminLogin(true)}
        className="fixed bottom-4 right-4 z-50 p-2 bg-black/50 hover:bg-rose-500/20 text-gray-600 hover:text-rose-400 rounded-full transition-all border border-white/5 hover:border-rose-500/30 backdrop-blur-sm group"
        title="Admin Access"
      >
        <ShieldCheck size={16} className="opacity-50 group-hover:opacity-100 transition-opacity" />
      </button>
    </div>
  );
};
