import React, { useState, useEffect } from 'react';
import { Crown, Check, X, Zap, Copy, QrCode, ArrowRight, Wallet, CreditCard, Loader2, ShieldCheck } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

type PaymentMethod = 'USDT' | 'BTC' | 'ETH';

const WALLETS = {
  USDT: {
    network: 'TRC20',
    address: 'TVj7xV7xV7xV7xV7xV7xV7xV7xV7xV7xV7',
    qr: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=TVj7xV7xV7xV7xV7xV7xV7xV7xV7xV7xV7'
  },
  BTC: {
    network: 'Bitcoin',
    address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    qr: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
  },
  ETH: {
    network: 'ERC20',
    address: '0x71C7656EC7ab88b098defB751B7401B5f6d8976F',
    qr: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=0x71C7656EC7ab88b098defB751B7401B5f6d8976F'
  }
};

export const PaymentModal: React.FC<PaymentModalProps> = ({ isOpen, onClose, onSuccess }) => {
  const [step, setStep] = useState<'plan' | 'method' | 'payment' | 'verifying' | 'success'>('plan');
  const [selectedMethod, setSelectedMethod] = useState<PaymentMethod>('USDT');
  const [timeLeft, setTimeLeft] = useState(1800); // 30 minutes

  useEffect(() => {
    if (isOpen) {
      setStep('plan');
      setTimeLeft(1800);
    }
  }, [isOpen]);

  useEffect(() => {
    if (step === 'payment' && timeLeft > 0) {
      const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
      return () => clearInterval(timer);
    }
  }, [step, timeLeft]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    // Could add toast here
  };

  const handleVerify = async () => {
    setStep('verifying');
    // Simulate API verification
    await new Promise(resolve => setTimeout(resolve, 3000));
    setStep('success');
    setTimeout(() => {
      onSuccess();
    }, 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in duration-300" dir="rtl">
      <div className="glass-panel w-full max-w-md rounded-[2rem] border border-amber-500/20 shadow-[0_0_80px_rgba(245,158,11,0.15)] animate-in zoom-in-95 duration-500 relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 border-b border-white/5 flex items-center justify-between bg-white/5">
          <h2 className="text-lg font-black text-white flex items-center gap-2">
            {step === 'plan' && 'اختر خطتك'}
            {step === 'method' && 'طريقة الدفع'}
            {step === 'payment' && 'إتمام الدفع'}
            {step === 'verifying' && 'جاري التحقق'}
            {step === 'success' && 'تم بنجاح'}
          </h2>
          <button 
            onClick={onClose}
            className="p-1.5 bg-white/5 rounded-lg hover:bg-white/10 transition-all text-gray-400 hover:text-white"
          >
            <X size={16} />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto custom-scrollbar">
          
          {/* Step 1: Plan Selection */}
          {step === 'plan' && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-500/20 to-orange-600/20 border border-amber-500/20 mb-3 shadow-[0_0_30px_rgba(245,158,11,0.2)]">
                  <Crown size={32} className="text-amber-400" />
                </div>
                <h3 className="text-xl font-black text-white">عضوية VIP</h3>
                <p className="text-gray-400 text-xs">وصول كامل لجميع ميزات المنصة</p>
              </div>

              <div className="bg-gradient-to-br from-amber-500/10 to-orange-600/10 rounded-xl border border-amber-500/30 p-5 relative overflow-hidden group hover:border-amber-500/50 transition-all cursor-pointer ring-1 ring-amber-500/50 shadow-lg">
                <div className="absolute top-0 right-0 bg-amber-500 text-black text-[9px] font-black px-2 py-0.5 rounded-bl-lg">الأكثر مبيعاً</div>
                <div className="flex justify-between items-center mb-3">
                  <div>
                    <span className="text-2xl font-black text-white">$20</span>
                    <span className="text-gray-400 font-bold text-xs"> / 10 أيام</span>
                  </div>
                  <Check className="text-amber-500 bg-amber-500/20 rounded-full p-1" size={20} />
                </div>
                <ul className="space-y-1.5">
                  {['تحليل فني غير محدود', 'توصيات الذكاء الاصطناعي', 'كشف تحركات الحيتان', 'تنبيهات فورية'].map((f, i) => (
                    <li key={i} className="flex items-center gap-2 text-xs text-gray-300">
                      <Check size={12} className="text-amber-500" /> {f}
                    </li>
                  ))}
                </ul>
              </div>

              <button 
                onClick={() => setStep('method')}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-black font-black rounded-xl shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 text-sm"
              >
                متابعة للدفع <ArrowRight size={16} className="rotate-180" />
              </button>
            </div>
          )}

          {/* Step 2: Method Selection */}
          {step === 'method' && (
            <div className="space-y-3">
              <p className="text-gray-400 text-xs mb-3">اختر العملة الرقمية للدفع:</p>
              
              {(Object.keys(WALLETS) as PaymentMethod[]).map((method) => (
                <div 
                  key={method}
                  onClick={() => setSelectedMethod(method)}
                  className={`p-3 rounded-xl border cursor-pointer flex items-center justify-between transition-all ${
                    selectedMethod === method 
                      ? 'bg-amber-500/10 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.1)]' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-sm">
                      {method === 'USDT' ? <span className="font-bold text-green-500">T</span> : 
                       method === 'BTC' ? <span className="font-bold text-orange-500">₿</span> : 
                       <span className="font-bold text-blue-500">Ξ</span>}
                    </div>
                    <div>
                      <div className="font-bold text-white text-sm">{method}</div>
                      <div className="text-[10px] text-gray-500">{WALLETS[method].network}</div>
                    </div>
                  </div>
                  {selectedMethod === method && <div className="w-3 h-3 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"></div>}
                </div>
              ))}

              <button 
                onClick={() => setStep('payment')}
                className="w-full py-3 mt-6 bg-amber-500 hover:bg-amber-400 text-black font-black rounded-xl shadow-lg shadow-amber-500/20 transition-all text-sm"
              >
                تأكيد الاختيار
              </button>
            </div>
          )}

          {/* Step 3: Payment */}
          {step === 'payment' && (
            <div className="space-y-5 text-center">
              <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 flex items-center justify-between">
                <span className="text-gray-400 text-xs">المبلغ المطلوب:</span>
                <span className="text-lg font-black text-amber-400">$20.00</span>
              </div>

              <div className="bg-white p-3 rounded-xl inline-block mx-auto shadow-lg">
                <img src={WALLETS[selectedMethod].qr} alt="QR Code" className="w-32 h-32" />
              </div>

              <div className="space-y-1.5">
                <p className="text-[10px] text-gray-500">عنوان المحفظة ({WALLETS[selectedMethod].network})</p>
                <div className="flex items-center gap-2 bg-black/40 border border-white/10 rounded-xl p-2.5">
                  <code className="flex-1 text-[10px] text-gray-300 font-mono break-all text-left leading-tight">
                    {WALLETS[selectedMethod].address}
                  </code>
                  <button 
                    onClick={() => handleCopy(WALLETS[selectedMethod].address)}
                    className="p-1.5 hover:bg-white/10 rounded-lg text-gray-400 hover:text-white transition-colors"
                  >
                    <Copy size={14} />
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 text-amber-500 text-xs font-bold bg-amber-500/5 py-2 rounded-lg">
                <Loader2 size={14} className="animate-spin" />
                ينتهي الوقت خلال: {formatTime(timeLeft)}
              </div>

              <button 
                onClick={handleVerify}
                className="w-full py-3 bg-green-600 hover:bg-green-500 text-white font-black rounded-xl shadow-lg shadow-green-500/20 transition-all text-sm"
              >
                تم الإرسال، تحقق الآن
              </button>
            </div>
          )}

          {/* Step 4: Verifying */}
          {step === 'verifying' && (
            <div className="py-8 text-center space-y-4">
              <div className="relative w-20 h-20 mx-auto">
                <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-amber-500 rounded-full border-t-transparent animate-spin"></div>
                <ShieldCheck className="absolute inset-0 m-auto text-amber-500 animate-pulse" size={32} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white mb-1">جاري التحقق من الدفع</h3>
                <p className="text-gray-400 text-xs">يرجى الانتظار، قد تستغرق العملية بضع دقائق...</p>
              </div>
            </div>
          )}

          {/* Step 5: Success */}
          {step === 'success' && (
            <div className="py-8 text-center space-y-4 animate-in zoom-in duration-500">
              <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_40px_rgba(34,197,94,0.4)]">
                <Check size={40} className="text-white" />
              </div>
              <div>
                <h3 className="text-xl font-black text-white mb-1">تم تفعيل الاشتراك بنجاح!</h3>
                <p className="text-gray-400 text-sm">استمتع بجميع ميزات VIP الآن.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
