import React, { useState } from 'react';
import { Crown, Plus, Trash2, Save, X, Check, DollarSign, Calendar, Star } from 'lucide-react';
import { useSettings, VipPlan } from '../context/SettingsContext';

export const VipSettingsPage: React.FC = () => {
  const { vipPlans, updateVipPlans } = useSettings();
  const [editingPlan, setEditingPlan] = useState<VipPlan | null>(null);
  const [isAdding, setIsAdding] = useState(false);

  const [newPlan, setNewPlan] = useState<VipPlan>({
    id: '',
    name: '',
    price: 0,
    durationDays: 30,
    features: [''],
    isPopular: false
  });

  const handleSavePlan = (plan: VipPlan) => {
    const updatedPlans = vipPlans.map(p => p.id === plan.id ? plan : p);
    updateVipPlans(updatedPlans);
    setEditingPlan(null);
  };

  const handleDeletePlan = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الخطة؟')) {
      const updatedPlans = vipPlans.filter(p => p.id !== id);
      updateVipPlans(updatedPlans);
    }
  };

  const handleAddPlan = () => {
    if (!newPlan.name || newPlan.price <= 0) {
      alert('يرجى إدخال اسم الخطة وسعر صحيح');
      return;
    }
    
    const planToAdd = {
      ...newPlan,
      id: Math.random().toString(36).substr(2, 9),
      features: newPlan.features.filter(f => f.trim() !== '')
    };
    
    updateVipPlans([...vipPlans, planToAdd]);
    setIsAdding(false);
    setNewPlan({
      id: '',
      name: '',
      price: 0,
      durationDays: 30,
      features: [''],
      isPopular: false
    });
  };

  const handleFeatureChange = (index: number, value: string, isNew: boolean, plan?: VipPlan) => {
    if (isNew) {
      const newFeatures = [...newPlan.features];
      newFeatures[index] = value;
      setNewPlan({ ...newPlan, features: newFeatures });
    } else if (plan && editingPlan) {
      const newFeatures = [...editingPlan.features];
      newFeatures[index] = value;
      setEditingPlan({ ...editingPlan, features: newFeatures });
    }
  };

  const addFeatureField = (isNew: boolean, plan?: VipPlan) => {
    if (isNew) {
      setNewPlan({ ...newPlan, features: [...newPlan.features, ''] });
    } else if (plan && editingPlan) {
      setEditingPlan({ ...editingPlan, features: [...editingPlan.features, ''] });
    }
  };

  const removeFeatureField = (index: number, isNew: boolean, plan?: VipPlan) => {
    if (isNew) {
      const newFeatures = newPlan.features.filter((_, i) => i !== index);
      setNewPlan({ ...newPlan, features: newFeatures });
    } else if (plan && editingPlan) {
      const newFeatures = editingPlan.features.filter((_, i) => i !== index);
      setEditingPlan({ ...editingPlan, features: newFeatures });
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Crown className="text-amber-500" />
            إدارة باقات VIP
          </h2>
          <p className="text-gray-400 text-sm mt-1">قم بإدارة خطط الاشتراك والأسعار والمميزات</p>
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold flex items-center gap-2 transition-all"
        >
          <Plus size={18} />
          إضافة خطة جديدة
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {vipPlans.map(plan => (
          <div key={plan.id} className={`bg-[#0e1116] border rounded-2xl p-6 relative group transition-all ${editingPlan?.id === plan.id ? 'border-indigo-500 ring-1 ring-indigo-500/50' : 'border-white/5 hover:border-white/10'}`}>
            {editingPlan?.id === plan.id ? (
              // Edit Mode
              <div className="space-y-4">
                <div>
                  <label className="text-xs text-gray-500 font-bold block mb-1">اسم الخطة</label>
                  <input 
                    type="text" 
                    value={editingPlan.name}
                    onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-bold block mb-1">السعر ($)</label>
                    <input 
                      type="number" 
                      value={editingPlan.price}
                      onChange={(e) => setEditingPlan({ ...editingPlan, price: Number(e.target.value) })}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-bold block mb-1">المدة (أيام)</label>
                    <input 
                      type="number" 
                      value={editingPlan.durationDays}
                      onChange={(e) => setEditingPlan({ ...editingPlan, durationDays: Number(e.target.value) })}
                      className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs text-gray-500 font-bold block mb-1">المميزات</label>
                  <div className="space-y-2">
                    {editingPlan.features.map((feature, idx) => (
                      <div key={idx} className="flex gap-2">
                        <input 
                          type="text" 
                          value={feature}
                          onChange={(e) => handleFeatureChange(idx, e.target.value, false, plan)}
                          className="flex-1 bg-black/40 border border-white/10 rounded-lg p-2 text-white text-xs"
                        />
                        <button 
                          onClick={() => removeFeatureField(idx, false, plan)}
                          className="text-rose-500 hover:text-rose-400 p-1"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    ))}
                    <button 
                      onClick={() => addFeatureField(false, plan)}
                      className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                    >
                      <Plus size={12} /> إضافة ميزة
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input 
                    type="checkbox" 
                    id={`popular-${plan.id}`}
                    checked={editingPlan.isPopular}
                    onChange={(e) => setEditingPlan({ ...editingPlan, isPopular: e.target.checked })}
                    className="rounded border-white/10 bg-black/40 text-indigo-500 focus:ring-indigo-500"
                  />
                  <label htmlFor={`popular-${plan.id}`} className="text-xs text-gray-400 cursor-pointer">تعيين كخطة شائعة (Popular)</label>
                </div>

                <div className="flex gap-2 pt-4 border-t border-white/5">
                  <button 
                    onClick={() => handleSavePlan(editingPlan)}
                    className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2"
                  >
                    <Save size={14} /> حفظ
                  </button>
                  <button 
                    onClick={() => setEditingPlan(null)}
                    className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2"
                  >
                    <X size={14} /> إلغاء
                  </button>
                </div>
              </div>
            ) : (
              // View Mode
              <>
                <div className="flex justify-between items-start mb-4">
                  <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/20">
                    <Crown size={24} className="text-amber-500" />
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setEditingPlan(plan)}
                      className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button 
                      onClick={() => handleDeletePlan(plan.id)}
                      className="p-2 hover:bg-rose-500/10 rounded-lg text-gray-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>

                <h3 className="text-xl font-black text-white mb-1">{plan.name}</h3>
                <div className="flex items-baseline gap-1 mb-4">
                  <span className="text-2xl font-black text-indigo-400">${plan.price}</span>
                  <span className="text-sm text-gray-500">/ {plan.durationDays} يوم</span>
                </div>

                {plan.isPopular && (
                  <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/10 text-amber-500 text-[10px] font-bold border border-amber-500/20 mb-4">
                    <Star size={10} fill="currentColor" /> الأكثر شيوعاً
                  </div>
                )}

                <ul className="space-y-2 mb-4">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs text-gray-400">
                      <Check size={12} className="text-emerald-500 shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </>
            )}
          </div>
        ))}

        {/* Add New Plan Card */}
        {isAdding && (
          <div className="bg-[#0e1116] border border-indigo-500 ring-1 ring-indigo-500/50 rounded-2xl p-6 relative animate-in zoom-in-95 duration-300">
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-2 text-indigo-400 font-bold text-sm">
                <Plus size={16} /> إضافة خطة جديدة
              </div>
              
              <div>
                <label className="text-xs text-gray-500 font-bold block mb-1">اسم الخطة</label>
                <input 
                  type="text" 
                  value={newPlan.name}
                  onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                  placeholder="مثال: الباقة الذهبية"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 font-bold block mb-1">السعر ($)</label>
                  <input 
                    type="number" 
                    value={newPlan.price}
                    onChange={(e) => setNewPlan({ ...newPlan, price: Number(e.target.value) })}
                    className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                  />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-bold block mb-1">المدة (أيام)</label>
                  <input 
                    type="number" 
                    value={newPlan.durationDays}
                    onChange={(e) => setNewPlan({ ...newPlan, durationDays: Number(e.target.value) })}
                    className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-500 font-bold block mb-1">المميزات</label>
                <div className="space-y-2">
                  {newPlan.features.map((feature, idx) => (
                    <div key={idx} className="flex gap-2">
                      <input 
                        type="text" 
                        value={feature}
                        onChange={(e) => handleFeatureChange(idx, e.target.value, true)}
                        className="flex-1 bg-black/40 border border-white/10 rounded-lg p-2 text-white text-xs"
                        placeholder="ميزة جديدة..."
                      />
                      <button 
                        onClick={() => removeFeatureField(idx, true)}
                        className="text-rose-500 hover:text-rose-400 p-1"
                      >
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                  <button 
                    onClick={() => addFeatureField(true)}
                    className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
                  >
                    <Plus size={12} /> إضافة ميزة
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input 
                  type="checkbox" 
                  id="new-popular"
                  checked={newPlan.isPopular}
                  onChange={(e) => setNewPlan({ ...newPlan, isPopular: e.target.checked })}
                  className="rounded border-white/10 bg-black/40 text-indigo-500 focus:ring-indigo-500"
                />
                <label htmlFor="new-popular" className="text-xs text-gray-400 cursor-pointer">تعيين كخطة شائعة (Popular)</label>
              </div>

              <div className="flex gap-2 pt-4 border-t border-white/5">
                <button 
                  onClick={handleAddPlan}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2"
                >
                  <Plus size={14} /> إنشاء
                </button>
                <button 
                  onClick={() => setIsAdding(false)}
                  className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2"
                >
                  <X size={14} /> إلغاء
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// Helper component for Edit Icon since it's not imported from lucide-react in the main file
const Edit2 = ({ size = 24, className = "" }: { size?: number, className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size} 
    height={size} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path>
  </svg>
);
