
import React from 'react';

interface Props {
  values: number[];
  color?: string;
  className?: string;
}

export const Sparkline: React.FC<Props> = ({ 
  values, 
  color = '#3b82f6', 
  className = ''
}) => {
  if (values.length < 2) return null;

  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  const padding = range * 0.1;
  const displayMin = min - padding;
  const displayRange = range + padding * 2;

  // Use a normalized coordinate system
  const width = 100;
  const height = 100;

  const points = values.map((v, i) => {
    const x = (i / (values.length - 1)) * width;
    const y = height - ((v - displayMin) / displayRange) * height;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg 
      viewBox={`0 0 ${width} ${height}`} 
      preserveAspectRatio="none" 
      className={`overflow-visible w-full h-full ${className}`}
    >
      <polyline
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
        vectorEffect="non-scaling-stroke"
      />
      {/* Glow effect */}
      <polyline
        fill="none"
        stroke={color}
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        points={points}
        style={{ opacity: 0.2, filter: 'blur(2px)' }}
        vectorEffect="non-scaling-stroke"
      />
    </svg>
  );
};
