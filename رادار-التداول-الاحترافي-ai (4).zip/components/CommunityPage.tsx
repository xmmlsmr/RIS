import React, { useState, useEffect } from 'react';
import { 
  Users, MessageSquare, ThumbsUp, Share2, Filter, Search, 
  TrendingUp, BarChart2, Hash, MoreHorizontal, Send, 
  Image as ImageIcon, Smile, Paperclip, Heart, MessageCircle,
  Repeat, Bookmark, UserPlus, BadgeCheck, ArrowRight, Calendar, MapPin, Link as LinkIcon
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Post, CommunityUser } from '../types';

const MOCK_USERS: Record<string, CommunityUser> = {
  'u1': {
    id: 'u1',
    name: 'Ahmed Crypto',
    handle: '@ahmed_crypto',
    bio: 'Professional Crypto Trader & Analyst 🚀 | Bitcoin Max | NFA',
    followers: 12500,
    following: 245,
    joinDate: 'March 2021',
    verified: true,
    coverImage: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=1000'
  },
  'u2': {
    id: 'u2',
    name: 'Sarah Trading',
    handle: '@sarah_trades',
    bio: 'Scalping Specialist ⚡ | Sharing daily setups and educational content.',
    followers: 8900,
    following: 120,
    joinDate: 'July 2022',
    verified: false,
    coverImage: 'https://images.unsplash.com/photo-1611974765270-ca1258634369?auto=format&fit=crop&q=80&w=1000'
  },
  'u3': {
    id: 'u3',
    name: 'Whale Watcher',
    handle: '@whale_alert',
    bio: 'Tracking large crypto movements on-chain. 🐋',
    followers: 45000,
    following: 10,
    joinDate: 'January 2020',
    verified: true,
    coverImage: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&q=80&w=1000'
  }
};

const MOCK_POSTS: Post[] = [
  {
    id: '1',
    userId: 'u1',
    userName: 'Ahmed Crypto',
    userHandle: '@ahmed_crypto',
    verified: true,
    content: 'تحليل البيتكوين اليوم يظهر نموذج رأس وكتفين مقلوب على فريم 4 ساعات. الهدف القادم 68,000$ 🚀 #BTC #Crypto',
    image: 'https://images.unsplash.com/photo-1642790106117-e829e14a795f?auto=format&fit=crop&q=80&w=1000',
    likes: 124,
    comments: 45,
    shares: 12,
    timestamp: 'منذ ساعتين',
    tags: ['BTC', 'Technical_Analysis'],
    isLiked: true
  },
  {
    id: '2',
    userId: 'u2',
    userName: 'Sarah Trading',
    userHandle: '@sarah_trades',
    content: 'استراتيجية سكالبينج جديدة جربتها اليوم على ETH وحققت نتائج ممتازة! تعتمد على تقاطع EMA 9/21 مع مؤشر RSI. هل مهتمين بالشرح؟ 👇',
    likes: 89,
    comments: 156,
    shares: 34,
    timestamp: 'منذ 5 ساعات',
    tags: ['ETH', 'Strategy', 'Scalping']
  },
  {
    id: '3',
    userId: 'u3',
    userName: 'Whale Watcher',
    userHandle: '@whale_alert',
    verified: true,
    content: '🚨 تنبيه حيتان: تم رصد تحويل 5,000 BTC إلى منصة Binance قبل قليل. الحذر واجب قد نشهد تقلبات سعرية قوية.',
    likes: 567,
    comments: 89,
    shares: 230,
    timestamp: 'منذ 30 دقيقة',
    tags: ['Whale_Alert', 'Market_Update']
  }
];

interface CommunityProfileProps {
  userId: string;
  onBack: () => void;
  posts: Post[];
  onLike: (postId: string) => void;
}

interface PostCardProps {
  post: Post;
  onLike: () => void;
  onUserClick?: (id: string) => void;
}

const CommunityProfile: React.FC<CommunityProfileProps> = ({ userId, onBack, posts, onLike }) => {
  const user = MOCK_USERS[userId] || {
    id: userId,
    name: 'Unknown User',
    handle: '@unknown',
    bio: 'This user has not set up their profile yet.',
    followers: 0,
    following: 0,
    joinDate: 'Just now',
    verified: false,
    coverImage: undefined,
    avatar: undefined
  } as CommunityUser;

  const userPosts = posts.filter(p => p.userId === userId);
  const [activeTab, setActiveTab] = useState<'posts' | 'media' | 'likes'>('posts');
  const [isFollowing, setIsFollowing] = useState(false);

  return (
    <div className="flex-1 overflow-y-auto custom-scrollbar bg-[#030303]">
      {/* Header / Cover */}
      <div className="relative h-48 md:h-64 bg-gray-800">
        <button 
          onClick={onBack}
          className="absolute top-4 right-4 z-10 p-2 bg-black/50 hover:bg-black/70 rounded-full text-white transition-colors backdrop-blur-sm"
        >
          <ArrowRight size={20} />
        </button>
        {user.coverImage && (
          <img src={user.coverImage} alt="Cover" className="w-full h-full object-cover opacity-80" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#030303] via-transparent to-transparent"></div>
      </div>

      {/* Profile Info */}
      <div className="px-6 relative -mt-16 mb-6">
        <div className="flex justify-between items-end mb-4">
          <div className="w-32 h-32 rounded-full bg-[#030303] p-1.5">
            <div className="w-full h-full rounded-full bg-gray-700 overflow-hidden border-2 border-white/10">
              {user.avatar ? (
                <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-cyan-600 to-blue-700 text-4xl font-bold text-white">
                  {user.name.charAt(0)}
                </div>
              )}
            </div>
          </div>
          <button 
            onClick={() => setIsFollowing(!isFollowing)}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
              isFollowing 
                ? 'bg-transparent border border-white/20 text-white hover:border-rose-500/50 hover:text-rose-400' 
                : 'bg-white text-black hover:bg-gray-200'
            }`}
          >
            {isFollowing ? 'إلغاء المتابعة' : 'متابعة'}
          </button>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-black text-white">{user.name}</h1>
            {user.verified && <BadgeCheck size={20} className="text-cyan-400" fill="currentColor" stroke="black" />}
          </div>
          <p className="text-gray-500 text-sm mb-4">{user.handle}</p>
          <p className="text-gray-300 mb-4 max-w-2xl leading-relaxed">{user.bio}</p>
          
          <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-6">
            <div className="flex items-center gap-1">
              <MapPin size={16} />
              <span>Global</span>
            </div>
            <div className="flex items-center gap-1">
              <LinkIcon size={16} />
              <a href="#" className="text-cyan-400 hover:underline">website.com</a>
            </div>
            <div className="flex items-center gap-1">
              <Calendar size={16} />
              <span>انضم {user.joinDate}</span>
            </div>
          </div>

          <div className="flex gap-6 text-sm">
            <div className="flex gap-1 hover:underline cursor-pointer">
              <span className="font-bold text-white">{user.following.toLocaleString()}</span>
              <span className="text-gray-500">يتابع</span>
            </div>
            <div className="flex gap-1 hover:underline cursor-pointer">
              <span className="font-bold text-white">{user.followers.toLocaleString()}</span>
              <span className="text-gray-500">متابعون</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-white/10 px-6 mb-4">
        <div className="flex gap-8">
          {['posts', 'media', 'likes'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`py-4 text-sm font-bold relative transition-colors ${
                activeTab === tab ? 'text-cyan-400' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              {tab === 'posts' && 'المنشورات'}
              {tab === 'media' && 'الوسائط'}
              {tab === 'likes' && 'الإعجابات'}
              {activeTab === tab && (
                <div className="absolute bottom-0 left-0 w-full h-1 bg-cyan-400 rounded-t-full"></div>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="px-4 pb-20">
        {activeTab === 'posts' && (
          <div className="space-y-4">
            {userPosts.length > 0 ? (
              userPosts.map(post => (
                <PostCard key={post.id} post={post} onLike={() => onLike(post.id)} />
              ))
            ) : (
              <div className="text-center py-12 text-gray-500">
                لا توجد منشورات حتى الآن
              </div>
            )}
          </div>
        )}
        {activeTab === 'media' && (
          <div className="grid grid-cols-3 gap-1">
            {userPosts.filter(p => p.image).map(post => (
              <div key={post.id} className="aspect-square bg-white/5 overflow-hidden cursor-pointer hover:opacity-80 transition-opacity">
                <img src={post.image} alt="" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}
        {activeTab === 'likes' && (
           <div className="text-center py-12 text-gray-500">
             قائمة الإعجابات خاصة
           </div>
        )}
      </div>
    </div>
  );
};

const PostCard: React.FC<PostCardProps> = ({ post, onLike, onUserClick }) => (
  <div className="bg-[#0e1116] rounded-2xl border border-white/5 p-4 hover:border-white/10 transition-all">
    <div className="flex items-start justify-between mb-4">
      <div className="flex gap-3">
        <div 
          onClick={() => onUserClick && onUserClick(post.userId)}
          className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center font-bold text-white border border-white/10 cursor-pointer hover:border-cyan-500/50 transition-colors"
        >
          {post.userAvatar ? (
            <img src={post.userAvatar} alt={post.userName} className="w-full h-full rounded-full object-cover" />
          ) : (
            post.userName.charAt(0)
          )}
        </div>
        <div>
          <div className="flex items-center gap-1">
            <h4 
              onClick={() => onUserClick && onUserClick(post.userId)}
              className="font-bold text-white hover:underline cursor-pointer"
            >
              {post.userName}
            </h4>
            {post.verified && <BadgeCheck size={14} className="text-cyan-400" fill="currentColor" stroke="black" />}
          </div>
          <div className="text-xs text-gray-500 flex items-center gap-2">
            <span>{post.userHandle}</span>
            <span>•</span>
            <span>{post.timestamp}</span>
          </div>
        </div>
      </div>
      <button className="text-gray-500 hover:text-white transition-colors">
        <MoreHorizontal size={20} />
      </button>
    </div>

    <div className="mb-4">
      <p className="text-gray-200 whitespace-pre-wrap leading-relaxed mb-3">{post.content}</p>
      {post.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-3">
          {post.tags.map(tag => (
            <span key={tag} className="text-cyan-400 text-sm hover:underline cursor-pointer">#{tag}</span>
          ))}
        </div>
      )}
      {post.image && (
        <div className="rounded-xl overflow-hidden border border-white/5 mt-3">
          <img src={post.image} alt="Post attachment" className="w-full h-auto object-cover max-h-[400px]" />
        </div>
      )}
    </div>

    <div className="flex items-center justify-between border-t border-white/5 pt-3">
      <button 
        onClick={onLike}
        className={`flex items-center gap-2 text-sm font-medium transition-colors group ${post.isLiked ? 'text-rose-500' : 'text-gray-500 hover:text-rose-500'}`}
      >
        <div className={`p-2 rounded-full group-hover:bg-rose-500/10 ${post.isLiked ? 'bg-rose-500/10' : ''}`}>
          <Heart size={18} fill={post.isLiked ? "currentColor" : "none"} />
        </div>
        <span>{post.likes}</span>
      </button>

      <button className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-cyan-400 transition-colors group">
        <div className="p-2 rounded-full group-hover:bg-cyan-500/10">
          <MessageCircle size={18} />
        </div>
        <span>{post.comments}</span>
      </button>

      <button className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-emerald-400 transition-colors group">
        <div className="p-2 rounded-full group-hover:bg-emerald-500/10">
          <Repeat size={18} />
        </div>
        <span>{post.shares}</span>
      </button>

      <button className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-blue-400 transition-colors group">
        <div className="p-2 rounded-full group-hover:bg-blue-500/10">
          <Share2 size={18} />
        </div>
      </button>
    </div>
  </div>
);

export const CommunityPage: React.FC = () => {
  const { user } = useAuth();
  const [posts, setPosts] = useState<Post[]>(MOCK_POSTS);
  const [newPostContent, setNewPostContent] = useState('');
  const [activeTab, setActiveTab] = useState<'feed' | 'trending' | 'following'>('feed');
  const [view, setView] = useState<'feed' | 'profile'>('feed');
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1,
          isLiked: !post.isLiked
        };
      }
      return post;
    }));
  };

  const handlePostSubmit = () => {
    if (!newPostContent.trim()) return;

    const newPost: Post = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user?.id || 'guest',
      userName: user?.name || 'Guest User',
      userHandle: `@${user?.name?.toLowerCase().replace(/\s/g, '_') || 'guest'}`,
      content: newPostContent,
      likes: 0,
      comments: 0,
      shares: 0,
      timestamp: 'الآن',
      tags: [],
      verified: user?.role === 'vip' || user?.role === 'admin'
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
  };

  const navigateToProfile = (userId: string) => {
    setSelectedUserId(userId);
    setView('profile');
  };

  if (view === 'profile' && selectedUserId) {
    return (
      <CommunityProfile 
        userId={selectedUserId} 
        onBack={() => setView('feed')} 
        posts={posts}
        onLike={handleLike}
      />
    );
  }

  return (
    <div className="flex h-full bg-[#030303] text-white overflow-hidden" dir="rtl">
      
      {/* Left Sidebar (Navigation & Filters) */}
      <div className="w-64 hidden lg:flex flex-col border-l border-white/5 p-4 gap-6 bg-black/20">
        <div className="space-y-2">
          <button 
            onClick={() => setActiveTab('feed')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeTab === 'feed' ? 'bg-white/10 text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <MessageSquare size={20} />
            الرئيسية
          </button>
          <button 
            onClick={() => setActiveTab('trending')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeTab === 'trending' ? 'bg-white/10 text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <TrendingUp size={20} />
            الأكثر تداولاً
          </button>
          <button 
            onClick={() => setActiveTab('following')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-bold ${activeTab === 'following' ? 'bg-white/10 text-white' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
          >
            <Users size={20} />
            أتابعهم
          </button>
        </div>

        <div className="border-t border-white/5 pt-6">
          <h3 className="text-xs font-bold text-gray-500 uppercase mb-4 px-2">مواضيع شائعة</h3>
          <div className="space-y-3">
            {['#Bitcoin', '#Ethereum', '#Trading_Strategy', '#Altcoins', '#DeFi'].map(tag => (
              <div key={tag} className="flex items-center justify-between px-2 group cursor-pointer">
                <span className="text-sm text-gray-400 group-hover:text-cyan-400 transition-colors">{tag}</span>
                <span className="text-xs text-gray-600">2.4k</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Feed */}
      <div className="flex-1 overflow-y-auto custom-scrollbar border-l border-white/5">
        <div className="max-w-2xl mx-auto py-6 px-4">
          
          {/* Create Post */}
          <div className="bg-[#0e1116] rounded-2xl border border-white/5 p-4 mb-6">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center font-bold text-white flex-shrink-0">
                {user?.name?.charAt(0) || 'G'}
              </div>
              <div className="flex-1">
                <textarea
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder="شارك أفكارك، تحليلاتك، أو استراتيجياتك..."
                  className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-gray-500 resize-none min-h-[100px]"
                />
                <div className="flex items-center justify-between border-t border-white/5 pt-3 mt-2">
                  <div className="flex gap-2 text-cyan-500">
                    <button className="p-2 hover:bg-white/5 rounded-full transition-colors"><ImageIcon size={20} /></button>
                    <button className="p-2 hover:bg-white/5 rounded-full transition-colors"><Hash size={20} /></button>
                    <button className="p-2 hover:bg-white/5 rounded-full transition-colors"><Smile size={20} /></button>
                  </div>
                  <button 
                    onClick={handlePostSubmit}
                    disabled={!newPostContent.trim()}
                    className="px-6 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:bg-gray-700 disabled:cursor-not-allowed text-white font-bold rounded-full transition-all flex items-center gap-2"
                  >
                    <Send size={16} />
                    نشر
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Posts Feed */}
          <div className="space-y-6">
            {posts.map(post => (
              <PostCard 
                key={post.id} 
                post={post} 
                onLike={() => handleLike(post.id)} 
                onUserClick={navigateToProfile}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Right Sidebar (Suggestions) */}
      <div className="w-80 hidden xl:flex flex-col border-r border-white/5 p-6 gap-6 bg-black/20">
        
        {/* Search */}
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
          <input 
            type="text" 
            placeholder="بحث في المجتمع..." 
            className="w-full bg-[#0e1116] border border-white/10 rounded-full py-3 pr-10 pl-4 text-sm text-white focus:outline-none focus:border-cyan-500 transition-all"
          />
        </div>

        {/* Who to follow */}
        <div className="bg-[#0e1116] rounded-2xl border border-white/5 p-4">
          <h3 className="font-bold text-white mb-4">اقتراحات للمتابعة</h3>
          <div className="space-y-4">
            {Object.values(MOCK_USERS).map((user) => (
              <div key={user.id} className="flex items-center justify-between">
                <div 
                  className="flex items-center gap-3 cursor-pointer group"
                  onClick={() => navigateToProfile(user.id)}
                >
                  <div className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center font-bold text-white border border-white/10 group-hover:border-cyan-500/50 transition-colors">
                    {user.avatar ? (
                      <img src={user.avatar} alt={user.name} className="w-full h-full rounded-full object-cover" />
                    ) : (
                      user.name.charAt(0)
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <span className="font-bold text-sm text-white group-hover:underline">{user.name}</span>
                      {user.verified && <BadgeCheck size={12} className="text-cyan-400" fill="currentColor" stroke="black" />}
                    </div>
                    <div className="text-xs text-gray-500">{user.handle}</div>
                  </div>
                </div>
                <button className="bg-white text-black text-xs font-bold px-3 py-1.5 rounded-full hover:bg-gray-200 transition-colors">
                  متابعة
                </button>
              </div>
            ))}
          </div>
          <button className="w-full text-cyan-500 text-xs font-bold mt-4 hover:underline">عرض المزيد</button>
        </div>

        {/* Community Guidelines */}
        <div className="text-xs text-gray-500 leading-relaxed px-2">
          <p className="mb-2">© 2024 Alpha Radar Community</p>
          <div className="flex flex-wrap gap-2">
            <a href="#" className="hover:underline">القوانين</a>
            <a href="#" className="hover:underline">الخصوصية</a>
            <a href="#" className="hover:underline">ملفات الارتباط</a>
            <a href="#" className="hover:underline">حول</a>
          </div>
        </div>
      </div>

    </div>
  );
};
