import React, { createContext, useContext, useState, useEffect } from 'react';

export interface DepositMethod {
  id: string;
  name: string;
  network: string;
  address: string;
  qrCode?: string;
  enabled: boolean;
}

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  primaryColor: string;
  fontFamily: string;
  maintenanceMode: boolean;
}

export interface FinanceSettings {
  minDeposit: number;
  minWithdraw: number;
  withdrawFee: number;
  depositMethods: DepositMethod[];
}

export interface VipPlan {
  id: string;
  name: string;
  price: number;
  durationDays: number;
  features: string[];
  isPopular?: boolean;
}

interface SettingsContextType {
  siteSettings: SiteSettings;
  financeSettings: FinanceSettings;
  vipPlans: VipPlan[];
  updateSiteSettings: (settings: SiteSettings) => void;
  updateFinanceSettings: (settings: FinanceSettings) => void;
  updateVipPlans: (plans: VipPlan[]) => void;
}

const defaultSiteSettings: SiteSettings = {
  siteName: 'Alpha Radar AI',
  siteDescription: 'Professional Crypto Trading Platform',
  primaryColor: '#06b6d4', // cyan-500
  fontFamily: 'Inter',
  maintenanceMode: false,
};

const defaultFinanceSettings: FinanceSettings = {
  minDeposit: 50,
  minWithdraw: 10,
  withdrawFee: 1,
  depositMethods: [
    { id: '1', name: 'USDT', network: 'TRC20', address: 'T9yD14Nj9j7xAB4dbGeiX9h8zzCyrP6t', enabled: true },
    { id: '2', name: 'BTC', network: 'Bitcoin', address: '1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa', enabled: true },
    { id: '3', name: 'ETH', network: 'ERC20', address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44e', enabled: true },
  ],
};

const defaultVipPlans: VipPlan[] = [
  {
    id: '1',
    name: 'Standard VIP',
    price: 20,
    durationDays: 10,
    features: [
      'تحليل فني غير محدود',
      'توصيات الذكاء الاصطناعي',
      'كشف تحركات الحيتان',
      'تنبيهات فورية'
    ],
    isPopular: true
  }
];

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => {
    const saved = localStorage.getItem('siteSettings');
    return saved ? JSON.parse(saved) : defaultSiteSettings;
  });

  const [financeSettings, setFinanceSettings] = useState<FinanceSettings>(() => {
    const saved = localStorage.getItem('financeSettings');
    return saved ? JSON.parse(saved) : defaultFinanceSettings;
  });

  const [vipPlans, setVipPlans] = useState<VipPlan[]>(() => {
    const saved = localStorage.getItem('vipPlans');
    return saved ? JSON.parse(saved) : defaultVipPlans;
  });

  useEffect(() => {
    localStorage.setItem('siteSettings', JSON.stringify(siteSettings));
    // Apply global styles
    document.title = siteSettings.siteName;
    document.documentElement.style.setProperty('--font-body', siteSettings.fontFamily);
    document.documentElement.style.setProperty('--font-sans', siteSettings.fontFamily);
    document.documentElement.style.setProperty('--accent-cyan', siteSettings.primaryColor);
  }, [siteSettings]);

  useEffect(() => {
    localStorage.setItem('financeSettings', JSON.stringify(financeSettings));
  }, [financeSettings]);

  useEffect(() => {
    localStorage.setItem('vipPlans', JSON.stringify(vipPlans));
  }, [vipPlans]);

  const updateSiteSettings = (settings: SiteSettings) => {
    setSiteSettings(settings);
  };

  const updateFinanceSettings = (settings: FinanceSettings) => {
    setFinanceSettings(settings);
  };

  const updateVipPlans = (plans: VipPlan[]) => {
    setVipPlans(plans);
  };

  return (
    <SettingsContext.Provider value={{ siteSettings, financeSettings, vipPlans, updateSiteSettings, updateFinanceSettings, updateVipPlans }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
