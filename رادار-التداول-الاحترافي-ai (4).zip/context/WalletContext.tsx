import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  type: 'deposit' | 'withdraw';
  amount: number;
  method: string;
  status: 'pending' | 'approved' | 'rejected';
  date: string;
  txId?: string;
  address?: string;
}

export interface WalletContextType {
  balance: number;
  assets: { [symbol: string]: number };
  transactions: Transaction[];
  addTransaction: (transaction: Omit<Transaction, 'id' | 'date'>) => void;
  updateTransactionStatus: (id: string, status: 'approved' | 'rejected') => void;
  exchangeAssets: (fromSymbol: string, toSymbol: string, amount: number, rate: number, fee: number) => Promise<{ success: boolean; error?: string }>;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export const WalletProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, updateUser } = useAuth();
  const [balance, setBalance] = useState(0);
  const [assets, setAssets] = useState<{ [symbol: string]: number }>({});
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const stored = localStorage.getItem('transactions');
    return stored ? JSON.parse(stored) : [];
  });

  // Sync balance and assets with user profile
  useEffect(() => {
    if (user) {
      setBalance(user.balance || 0);
      setAssets(user.assets || {});
    } else {
      setBalance(0);
      setAssets({});
    }
  }, [user]);

  // Persist transactions
  useEffect(() => {
    localStorage.setItem('transactions', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (transaction: Omit<Transaction, 'id' | 'date'>) => {
    const newTransaction: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString().split('T')[0],
      status: 'pending',
      ...transaction,
    };
    setTransactions(prev => [newTransaction, ...prev]);
  };

  const updateTransactionStatus = (id: string, status: 'approved' | 'rejected') => {
    setTransactions(prev => prev.map(t => {
      if (t.id === id) {
        // Update balance if approved
        if (status === 'approved' && t.status !== 'approved') {
          let newBalance = balance;
          if (t.type === 'deposit') {
            newBalance = balance + t.amount;
          } else if (t.type === 'withdraw') {
            newBalance = balance - t.amount;
          }
          
          setBalance(newBalance);
          // Persist to user profile
          if (user) {
            updateUser({ balance: newBalance });
          }
        }
        return { ...t, status };
      }
      return t;
    }));
  };

  const exchangeAssets = async (fromSymbol: string, toSymbol: string, amount: number, rate: number, fee: number) => {
    if (!user) return { success: false, error: 'User not logged in' };

    // Check balance
    if (fromSymbol === 'USDT') {
      if (balance < amount) return { success: false, error: 'Insufficient USDT balance' };
    } else {
      if ((assets[fromSymbol] || 0) < amount) return { success: false, error: `Insufficient ${fromSymbol} balance` };
    }

    // Calculate amounts
    const feeAmount = amount * fee;
    const amountAfterFee = amount - feeAmount;
    const receivedAmount = amountAfterFee * rate;

    // Update balances
    let newBalance = balance;
    let newAssets = { ...assets };

    // Deduct from source
    if (fromSymbol === 'USDT') {
      newBalance -= amount;
    } else {
      newAssets[fromSymbol] = (newAssets[fromSymbol] || 0) - amount;
    }

    // Add to destination
    if (toSymbol === 'USDT') {
      newBalance += receivedAmount;
    } else {
      newAssets[toSymbol] = (newAssets[toSymbol] || 0) + receivedAmount;
    }

    // Update state
    setBalance(newBalance);
    setAssets(newAssets);

    // Persist to user profile
    updateUser({ balance: newBalance, assets: newAssets });

    // Record transaction
    addTransaction({
      userId: user.id,
      userName: user.name,
      type: 'withdraw', // Using 'withdraw' type for exchange for now, or could add 'exchange' type
      amount: amount,
      method: `Exchange ${fromSymbol} to ${toSymbol}`,
      status: 'approved'
    });

    // Since addTransaction sets status to pending by default, we might want to auto-approve exchanges
    // But for now let's just leave it as is or modify addTransaction to accept status
    
    return { success: true };
  };

  return (
    <WalletContext.Provider value={{ balance, assets, transactions, addTransaction, updateTransactionStatus, exchangeAssets }}>
      {children}
    </WalletContext.Provider>
  );
};

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};
